# GarmentAudit System - Deployment & Setup Guide

## 🚀 Production Deployment

### Prerequisites
- Node.js 18+ 
- PNPM package manager
- Database (PostgreSQL/MySQL recommended)
- Email service (SendGrid/AWS SES for automated emails)
- GPS/Geolocation API (Google Maps API)
- QR Code generation service (built-in)
- WhatsApp Business API (optional)

### Environment Variables

Create a `.env.production` file with:

```env
# Database
DATABASE_URL=your_database_connection_string
DB_HOST=your_db_host
DB_PORT=5432
DB_NAME=garment_audit
DB_USER=db_user
DB_PASSWORD=db_password

# Email Service
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASSWORD=your_sendgrid_api_key
EMAIL_FROM=noreply@garmentaudit.com

# Admin Settings
ADMIN_NOTIFICATION_EMAIL=admin@company.com

# OAuth
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
OAUTH_CALLBACK_URL=https://your-domain.com/auth/google/callback

# APIs
GOOGLE_MAPS_API_KEY=your_google_maps_api_key
WHATSAPP_API_KEY=your_whatsapp_api_key

# JWT
JWT_SECRET=your_jwt_secret_key

# Domain
APP_URL=https://your-domain.com
API_URL=https://api.your-domain.com
```

### Build & Deploy Steps

```bash
# 1. Install dependencies
pnpm install

# 2. Build application
pnpm build

# 3. Run type checking
pnpm typecheck

# 4. Run tests
pnpm test

# 5. Start production server
pnpm start
```

### Docker Deployment

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package.json pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install --frozen-lockfile
COPY . .
RUN pnpm build
EXPOSE 8080
CMD ["pnpm", "start"]
```

### Deployment Platforms

#### Vercel (Recommended)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

#### Netlify
```bash
# Install Netlify CLI
npm i -g netlify-cli

# Deploy
netlify deploy --prod --dir=dist
```

#### AWS/Azure/DigitalOcean
Use Docker image with your cloud provider's container services.

---

## 📋 Pre-Deployment Checklist

### Database Setup
- [ ] Create database schema
- [ ] Run migrations
- [ ] Create admin user account
- [ ] Test database connections

### Email Configuration
- [ ] Configure SMTP settings
- [ ] Test email delivery
- [ ] Set up email templates
- [ ] Configure from address

### Security
- [ ] Enable HTTPS/SSL
- [ ] Configure CORS settings
- [ ] Set up API rate limiting
- [ ] Enable HSTS headers
- [ ] Configure security headers (CSP, X-Frame-Options, etc.)

### Google OAuth Setup
- [ ] Create Google Cloud project
- [ ] Enable Google+ API
- [ ] Create OAuth 2.0 credentials
- [ ] Configure redirect URIs
- [ ] Set up consent screen

### GPS/Maps Configuration
- [ ] Enable Google Maps JavaScript API
- [ ] Configure API key restrictions
- [ ] Set up geofencing locations in database

### WhatsApp Integration (Optional)
- [ ] Register WhatsApp Business Account
- [ ] Get API credentials
- [ ] Configure webhook for status updates
- [ ] Test message delivery

### Monitoring & Logging
- [ ] Set up application monitoring (DataDog, New Relic)
- [ ] Configure error tracking (Sentry)
- [ ] Set up access logs
- [ ] Create log aggregation

### Backups
- [ ] Configure daily database backups
- [ ] Set up backup retention policy
- [ ] Test backup restoration process

---

## 🔐 Security Considerations

1. **Authentication**
   - All passwords hashed with bcrypt
   - JWT tokens for API authentication
   - OAuth 2.0 for Google Sign-In
   - Session timeout after 30 minutes

2. **Data Protection**
   - All sensitive data encrypted at rest
   - HTTPS/TLS for all connections
   - Database user with minimal permissions
   - Regular security audits

3. **Access Control**
   - Role-based access control (RBAC)
   - Auditor approval workflow before access
   - Admin-only settings panel
   - API key rotation

4. **Audit Trail**
   - All user actions logged
   - GPS coordinates recorded
   - Audit report immutability
   - Compliance tracking

---

## 📊 Database Schema (Overview)

### Key Tables
- `auditors` - Auditor accounts & profiles
- `auditor_approvals` - Registration approval workflow
- `audits` - Audit records
- `audit_checkpoints` - Quality checkpoint data
- `audit_defects` - Defect records
- `audit_images` - Image uploads
- `audit_reports` - Generated reports
- `client_reviews` - Client approval workflow
- `gps_locations` - Factory geofences
- `user_activity_logs` - Activity tracking

---

## 🚨 Post-Deployment

### Monitoring
- Monitor error rates and performance
- Check email delivery success
- Verify GPS accuracy
- Monitor database performance

### Maintenance
- Regular security patches
- Database optimization
- Log cleanup
- Backup verification

### Support
- Set up support email: support@garmentaudit.com
- Create FAQ/documentation
- Set up incident response process

---

## 🎯 Configuration After Deployment

### 1. Admin Panel Setup
```
Navigate to /admin
- Set notification email for new auditors
- Add approved factory locations (geofences)
- Configure quality standards
- Set AQL acceptance criteria
```

### 2. Email Configuration
```
Email Templates Needed:
- New auditor registration notification
- Auditor approval/rejection
- Audit submission confirmation
- Client report ready
- Client approval/rejection
- Performance reports
```

### 3. User Onboarding
```
1. Create admin accounts manually
2. Invite quality managers
3. Bulk import existing auditors (if applicable)
4. Configure email preferences
```

---

## 📞 Support & Documentation

- **API Documentation**: `/api/docs`
- **User Guide**: Available in app help section
- **Admin Guide**: Separate admin documentation
- **Technical Support**: tech-support@garmentaudit.com

---

## 🔄 Rollback Procedure

If deployment fails:

```bash
# Rollback to previous version
git revert <commit-hash>
pnpm build
pnpm start

# Or restore from backup
docker pull garment-audit:last-stable
docker run -d garment-audit:last-stable
```

---

## 📈 Scaling Considerations

For production with high volume:

1. **Database**: Use read replicas
2. **Caching**: Implement Redis for session management
3. **CDN**: Serve static assets from CloudFlare
4. **Load Balancing**: Use multiple app instances
5. **Background Jobs**: Queue email sending with Bull/RabbitMQ

---

## ✅ Final Checklist

- [ ] All environment variables configured
- [ ] Database migrations run successfully
- [ ] SSL/HTTPS enabled
- [ ] Admin account created
- [ ] Email service tested
- [ ] Google OAuth configured
- [ ] GPS locations added to database
- [ ] Backup system configured
- [ ] Monitoring enabled
- [ ] Documentation reviewed
- [ ] Team trained on system
- [ ] Client accounts prepared

---

**System is ready for production deployment!** 🚀
