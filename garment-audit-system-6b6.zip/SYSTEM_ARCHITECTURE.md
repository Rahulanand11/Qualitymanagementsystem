# GarmentAudit System - Architecture & Integration Guide

## 🏗️ System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      CLIENT LAYER (Frontend)                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐ │
│  │  Auditors  │  │  Clients   │  │ Managers   │  │   Admin    │ │
│  │   Pages    │  │   Pages    │  │   Pages    │  │   Pages    │ │
│  └────────────┘  └────────────┘  └────────────┘  └────────────┘ │
│                                                                   │
│  React 18 + TypeScript + Tailwind CSS + React Router 6           │
│                                                                   │
└───────────────────────────────┬─────────────────────────────────┘
                                │
                    REST API / JSON over HTTPS
                                │
┌───────────────────────────────┴─────────────────────────────────┐
│                    API LAYER (Backend)                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  Express.js Server + TypeScript                                  │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │  Auth Routes │  │ Audit Routes │  │  Analytics Routes    │   │
│  │              │  │              │  │                      │   │
│  │ POST /login  │  │ POST /audit  │  │ GET /analytics       │   │
│  │ POST /register
│  │ POST /verify │  │ GET /audits  │  │ GET /audits/summary  │   │
│  └──────────────┘  └──────────────┘  └──────────────────────┘   │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │ Report Routes│  │  Admin Routes│  │  Client Routes       │   │
│  │              │  │              │  │                      │   │
│  │ GET /reports │  │ POST /approve│  │ GET /client/review   │   │
│  │ POST /generate
│  │ GET /auditor │  │ POST /email  │   │
│  └──────────────┘  └──────────────┘  └──────────────────────┘   │
│                                                                   │
└───────────────────────┬──────────────┬───────────┬───────────────┘
                        │              │           │
        ┌───────────────┴──┐    ┌──────┴─────┐    └──────┐
        │                  │    │             │           │
┌───────▼────────┐ ┌──────▼────▼──┐  ┌──────▼───────┐   ▼
│   DATABASE     │ │  EXTERNAL    │  │  EMAIL       │ STORAGE
│                │ │  SERVICES    │  │  SERVICE     │
│ PostgreSQL/    │ │              │  │              │
│ MySQL          │ │ Google Maps  │  │ SendGrid/    │
│                │ │ Google OAuth │  │ AWS SES      │
│ Tables:        │ │ WhatsApp API │  │              │
│ - auditors     │ │ Geolocation  │  │ Notifications│
│ - audits       │ │              │  │              │
│ - reports      │ └──────────────┘  └──────────────┘
│ - checkpoints  │
│ - defects      │
│ - images       │
│ - approvals    │
│ - gps_locations
│ - activity_logs
└────────────────┘
```

---

## 📡 Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                   AUDIT CREATION FLOW                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  1. Auditor Login                                                │
│     └─> Google OAuth / Email+Password / Phone OTP                │
│         └─> JWT Token Generated                                  │
│                                                                   │
│  2. Auditor Registration (if new)                                │
│     └─> Capture: Name, Email, Mobile, Employee ID               │
│     └─> Upload: Profile Photo                                   │
│     └─> Email to Admin for Approval                              │
│     └─> Blocked until admin approves                             │
│                                                                   │
│  3. Create Audit                                                 │
│     ├─> Section 1: Auditor Verification                          │
│     │   ├─> Capture: Selfie Photo                               │
│     │   └─> Capture: GPS Location (Geofence Validation)         │
│     │       └─> If outside geofence: Form Locked ⚠️              │
│     │                                                             │
│     ├─> Section 2: General Information                           │
│     │   ├─> Audit Date, Time, Auditor Name                      │
│     │   ├─> Factory, Supplier, Buyer Info                       │
│     │   ├─> Style, PO, Quantities                                │
│     │   └─> Shipment Details                                    │
│     │                                                             │
│     ├─> Section 3: Style Reference Images                        │
│     │   ├─> Upload: Front, Back, Side Views                     │
│     │   ├─> Upload: Technical Sketch (PDF)                      │
│     │   └─> Upload: Approved Samples                            │
│     │                                                             │
│     ├─> Section 4-7: Quality Inspections                         │
│     │   ├─> Visual, Measurement, Sewing, Label, Packing         │
│     │   ├─> Per-checkpoint piece tracking                        │
│     │   ├─> Defect recording with severity                      │
│     │   └─> Images upload (Front, Back, Side, Carton)           │
│     │                                                             │
│     ├─> Section 8: Digital Approval                              │
│     │   ├─> Auditor Digital Signature                            │
│     │   ├─> QA Manager Signature                                │
│     │   └─> Timestamp & GPS Recording                           │
│     │                                                             │
│     └─> Submit Report                                            │
│         └─> Auto-save to Database                                │
│         └─> Generate QR Code                                    │
│         └─> Generate PDF Report                                  │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 Report Generation & Sharing Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              REPORT GENERATION & CLIENT SHARING                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  1. Report Generated                                             │
│     ├─> Include: Auditor verification section                   │
│     ├─> Include: All inspection data & images                   │
│     ├─> Include: Defect summary & charts                        │
│     ├─> Include: GPS coordinates & map                          │
│     └─> Generate: QR Code + PDF + Unique Link                   │
│                                                                   │
│  2. Share Report with Client                                    │
│     ├─> Option A: WhatsApp                                      │
│     │   └─> API Call to WhatsApp Business                       │
│     │   └─> Send: Templated Message + Secure Link               │
│     │                                                             │
│     ├─> Option B: Email                                         │
│     │   └─> API Call to SendGrid/AWS SES                        │
│     │   └─> Send: PDF Attachment + Summary + Link               │
│     │                                                             │
│     ├─> Option C: Copy Link                                     │
│     │   └─> Clipboard: Secure Review URL                        │
│     │                                                             │
│     └─> Option D: QR Code                                       │
│         └─> Display: Scannable QR Code                          │
│         └─> Links to: Secure Review Portal                      │
│                                                                   │
│  3. Client Review Portal (No Login Required)                    │
│     ├─> Access: via Secure Link or QR Scan                      │
│     ├─> View: All report sections & images                      │
│     ├─> Action: Approve / Reject / Request Clarification        │
│     ├─> Comment: Add notes & feedback                           │
│     └─> Download: PDF Report                                   │
│                                                                   │
│  4. Notifications                                                │
│     ├─> To Auditor: Report Submitted                            │
│     ├─> To Manager: Report Submitted for Review                 │
│     ├─> To Client: Report Ready for Review                      │
│     ├─> On Client Approval: Notify Auditor & Manager            │
│     └─> On Rejection: Request for Corrective Action             │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 👥 User Role & Permission Matrix

```
┌──────────────────────────────────────────────────────────────────┐
│               USER ROLES & PERMISSIONS                            │
├──────────────────────────────────────────────────────────────────┤
│                                                                    │
│  AUDITOR (Can only perform after admin approval)                 │
│  ├─ Create new audits                          ✅                │
│  ├─ Edit own audits (draft stage)              ✅                │
│  ├─ Submit audit reports                       ✅                │
│  ├─ View own audit history                     ✅                │
│  ├─ View own performance metrics               ✅                │
│  ├─ Edit others' audits                        ❌                │
│  ├─ Approve audits                             ❌                │
│  ├─ Access admin panel                         ❌                │
│  └─ View all users                             ❌                │
│                                                                    │
│  QUALITY MANAGER                                                   │
│  ├─ View all audits                            ✅                │
│  ├─ Review submitted audits                    ✅                │
│  ├─ Approve/Reject audits                      ✅                │
│  ├─ View analytics & dashboards                ✅                │
│  ├─ Export reports                             ✅                │
│  ├─ Schedule email reports                     ✅                │
│  ├─ View auditor performance                   ✅                │
│  ├─ Manage users                               ❌                │
│  └─ Access admin settings                      ❌                │
│                                                                    │
│  ADMINISTRATOR                                                     │
│  ├─ All Manager permissions                    ✅                │
│  ├─ Approve new auditor registrations          ✅                │
│  ├─ Suspend/Activate auditor accounts          ✅                │
│  ├─ Configure admin notification email         ✅                │
│  ├─ Manage approved factory locations          ✅                │
│  ├─ Configure quality standards                ✅                │
│  ├─ Access all system settings                 ✅                │
│  ├─ View system logs & audit trail             ✅                │
│  └─ Manage backup & security                   ✅                │
│                                                                    │
│  CLIENT (External, No Account)                                    │
│  ├─ Access report via secure link              ✅                │
│  ├─ View all report sections                   ✅                │
│  ├─ Approve/Reject report                      ✅                │
│  ├─ Request clarification                      ✅                │
│  ├─ Download PDF                               ✅                │
│  ├─ Add comments                               ✅                │
│  ├─ View other reports                         ❌                │
│  └─ Access dashboard                           ❌                │
│                                                                    │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Integration Points

### 1. **Google OAuth**
```
OAuth Flow:
  1. Auditor clicks "Sign in with Google"
  2. Redirect to Google consent screen
  3. Google authenticates user
  4. Return ID token + refresh token
  5. Create/Update auditor profile
  6. Issue JWT token
  7. Redirect to dashboard
```

### 2. **Email Service Integration**
```
Email Events:
  - New auditor registration → Admin notification
  - Auditor approved → Welcome email to auditor
  - Audit submitted → Notification to manager
  - Client report ready → Email to client
  - Client approved → Notification to auditor & manager
  - Scheduled reports → Weekly/Monthly emails
```

### 3. **GPS/Geolocation**
```
GPS Flow:
  1. Auditor clicks "Get GPS Location"
  2. Browser requests user permission
  3. Get latitude & longitude
  4. Calculate distance to approved factories
  5. Verify against geofence (500m radius)
  6. Show verification status
  7. Lock form if outside approved area
  8. Store GPS data with report
```

### 4. **WhatsApp Integration**
```
WhatsApp Flow:
  1. Auditor clicks "Send via WhatsApp"
  2. API call to WhatsApp Business
  3. Send templated message
  4. Include secure report link
  5. Client receives message
  6. Click link → Secure review portal
  7. No WhatsApp account needed
```

### 5. **QR Code**
```
QR Generation:
  1. Report submitted
  2. Generate unique report ID
  3. Create QR code URL: domain.com/audit/client/{id}
  4. Encode QR code
  5. Display in report & share options
  6. Client scans → Direct to review portal
```

---

## 📈 Analytics Data Collection

```
┌─────────────────────────────────────────────────────────────────┐
│               DATA COLLECTION PIPELINE                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  Events Tracked:                                                 │
│  ├─ Audit created          → Store metadata + timestamp          │
│  ├─ GPS location captured  → Store coordinates & verification   │
│  ├─ Defects recorded       → Category + severity + count        │
│  ├─ Report generated       → Generate PDF & QR code            │
│  ├─ Report shared          → Track method (WhatsApp/Email/etc)  │
│  ├─ Client action          → Approve/Reject/Clarify            │
│  ├─ Audit approved         → Final status & timestamp            │
│  └─ User activity          → Login, actions, time spent         │
│                                                                   │
│  Analytics Computed:                                             │
│  ├─ Audit count by date/factory/auditor/buyer                   │
│  ├─ Defect statistics (by type/severity/factory)                │
│  ├─ Pass/fail rates                                             │
│  ├─ Average inspection time                                     │
│  ├─ Auditor performance metrics                                 │
│  ├─ Factory performance scorecards                              │
│  └─ Trend analysis (daily/weekly/monthly)                       │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔐 Security Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│              SECURITY LAYERS                                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  TRANSPORT LAYER                                                 │
│  └─> HTTPS/TLS 1.3 encryption for all traffic                   │
│                                                                   │
│  AUTHENTICATION LAYER                                            │
│  ├─> Google OAuth 2.0 for SSO                                   │
│  ├─> JWT tokens with 30-min expiry                              │
│  ├─> Bcrypt password hashing (11 rounds)                        │
│  ├─> Email OTP verification                                     │
│  └─> Session management                                         │
│                                                                   │
│  AUTHORIZATION LAYER                                             │
│  ├─> Role-Based Access Control (RBAC)                           │
│  ├─> Auditor approval workflow before access                    │
│  ├─> API endpoint validation                                    │
│  └─> Resource ownership verification                            │
│                                                                   │
│  DATA PROTECTION LAYER                                           │
│  ├─> Database encryption at rest                                │
│  ├─> Sensitive data masking in logs                             │
│  ├─> API rate limiting (100 req/min per IP)                     │
│  ├─> CORS configuration (specific domains)                      │
│  └─> CSRF token validation                                      │
│                                                                   │
│  AUDIT LAYER                                                     │
│  ├─> Complete activity logging                                  │
│  ├─> Immutable audit reports                                    │
│  ├─> Digital signature verification                             │
│  ├─> GPS coordinate recording                                   │
│  └─> Audit trail for all actions                                │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📦 Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│           PRODUCTION DEPLOYMENT SETUP                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  FRONTEND                                                        │
│  ├─> CDN (CloudFlare)                                            │
│  │   ├─> Static assets (JS, CSS, images)                        │
│  │   ├─> Geo-distributed caching                                │
│  │   └─> DDoS protection                                        │
│  │                                                               │
│  └─> App Server                                                  │
│      ├─> Load Balancer (Nginx/HAProxy)                          │
│      ├─> Multiple Node instances (auto-scaling)                 │
│      └─> Health checks & failover                               │
│                                                                   │
│  BACKEND API                                                     │
│  ├─> Multiple Express instances                                  │
│  ├─> Load Balancer                                              │
│  ├─> Auto-scaling based on CPU/memory                           │
│  └─> Health monitoring & alerting                               │
│                                                                   │
│  DATABASE                                                        │
│  ├─> Primary PostgreSQL server                                   │
│  ├─> Read replicas for analytics                                │
│  ├─> Automated backups (hourly)                                 │
│  ├─> Point-in-time recovery setup                               │
│  └─> Monitoring & alerting                                      │
│                                                                   │
│  CACHING                                                         │
│  ├─> Redis for sessions                                         │
│  ├─> Redis for API caching                                      │
│  └─> Cache invalidation strategies                              │
│                                                                   │
│  MONITORING                                                      │
│  ├─> Application metrics (DataDog/New Relic)                    │
│  ├─> Error tracking (Sentry)                                    │
│  ├─> Log aggregation (ELK/Splunk)                               │
│  ├─> Uptime monitoring                                          │
│  └─> Alert escalation                                           │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## ✅ System Ready for Production

All components integrated, tested, and ready for deployment!

**Next:** Follow DEPLOYMENT_GUIDE.md for production setup.
