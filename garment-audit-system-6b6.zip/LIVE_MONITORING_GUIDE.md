# Live Inspection Monitoring Module - Complete Guide

## Overview

The **Live Inspection Monitoring** module enables administrators and quality managers to view live inspection activities through connected CCTV and IP cameras in real-time. This module provides a professional, scalable solution for remote quality monitoring with support for multiple camera sources and simultaneous multi-camera viewing.

---

## Module Architecture

### Components

1. **LiveMonitoring.tsx** - Main page component
   - Orchestrates the entire monitoring dashboard
   - Manages camera selection and view modes
   - Handles filtering and search
   - Displays live inspection information
   - Manages access control

2. **LiveVideoViewer.tsx** - Video display component
   - Renders single or multiple camera feeds
   - Supports 1, 2, 4, or 6 camera grid layouts
   - Provides snapshot capture functionality
   - Shows camera status and live indicator
   - Includes hover controls for user interaction

3. **CameraStatusDashboard.tsx** - Status monitoring
   - Displays real-time camera health metrics
   - Shows online/offline status indicators
   - Displays signal strength and resolution
   - Provides at-a-glance system overview

4. **InspectionInfoPanel.tsx** - Live inspection details
   - Displays active inspection information
   - Shows auditor, factory, and product details
   - Provides live timer for inspection duration
   - Shows inspection stage and status

5. **CameraManager.tsx** - Camera configuration
   - Add, edit, and remove cameras
   - Configure camera details and connection settings
   - Enable/disable cameras
   - Manage camera status and properties

---

## Features

### Camera Integration

**Supported Camera Types:**
- IP Camera (RTSP)
- ONVIF-compatible cameras
- USB Cameras
- Network Cameras
- HLS Streams
- WebRTC Streams

The architecture is designed for easy integration of additional camera types in the future.

### Camera Management

Administrators can:
- ✅ Add new cameras with custom names
- ✅ Assign cameras to factories
- ✅ Assign cameras to specific locations/inspection stations
- ✅ Configure camera connection URLs
- ✅ Enable/disable cameras
- ✅ Monitor camera status (online/offline)
- ✅ View signal strength and resolution
- ✅ Track last connection time

### Live Viewing

**View Modes:**
- Single Camera (1x1 grid)
- Dual Camera (2 cameras)
- Quad Camera (2x2 grid)
- Six Camera (2x3 grid)

**Controls:**
- 📹 **Snapshot Capture** - Save timestamped images from live feed
- 🔊 **Mute/Unmute Audio** - Toggle audio (if available)
- ⏸️ **Pause** - Pause live stream (viewer only)
- 🔄 **Refresh** - Reconnect to stream
- 🖥️ **Full Screen** - Expand camera to full view
- ⚡ **Low Latency** - Optimized streaming
- 🎬 **HD Support** - High definition video streams
- 🔁 **Auto Reconnect** - Automatic reconnection on drop

### Inspection Information Panel

When linked to an active inspection, displays:
- 🕒 Auditor Name
- 🏭 Factory Name
- 👥 Buyer Name
- 📦 Supplier Name
- 📄 PO Number
- 👕 Style Number
- 🔍 Inspection Stage
- ✅ Current Inspection Status
- ⏱️ Inspection Start Time
- ⏲️ Live Duration Timer (auto-updating)

### Snapshot Feature

Authorized users can:
- ✅ Capture snapshots from live video
- ✅ Automatically timestamps each snapshot
- ✅ Records capturing user information
- ✅ Save snapshots against inspection record
- ✅ Download captured images

### Camera Status Dashboard

**Health Indicators:**
- 🟢 **Online** - Camera connected and streaming
- 🔴 **Offline** - Camera not connected
- 🟡 **Reconnecting** - Attempting to reconnect
- ⚪ **Disabled** - Camera disabled by admin

**Metrics Displayed:**
- Connection status with live indicator
- Last connected timestamp
- Signal strength percentage
- Stream resolution
- Frame rate

### Search & Filters

Filter cameras by:
- 🔍 **Search** - Camera name or location
- 🏭 **Factory** - Filter by factory
- 🌐 **Status** - Online, offline, reconnecting, disabled
- 📍 **Location** - Inspection area

---

## Usage Guide

### Accessing Live Monitoring

1. Log in to the Quality Management System
2. Go to Dashboard
3. Click the **Live Monitoring** card
4. You'll be redirected to `/monitoring/live`

### Viewing Cameras

1. **Select Cameras:**
   - Check the camera checkboxes in the "Select Cameras" section
   - Multiple cameras can be selected at once

2. **Choose View Mode:**
   - Click 1, 2, 4, or 6 to select grid layout
   - Layout updates automatically

3. **Monitor Status:**
   - View camera status dashboard on the right
   - Watch system health metrics
   - Check signal strength and connection status

### Managing Cameras

1. **Open Camera Manager:**
   - Click "Manage Cameras" button in header

2. **Add New Camera:**
   - Fill in camera name (e.g., "Factory A – Sewing Line 1")
   - Enter factory name
   - Specify location
   - Select camera type (RTSP, ONVIF, etc.)
   - Paste camera URL
   - Check "Enable camera"
   - Click "Add Camera"

3. **Edit/Delete Cameras:**
   - Use edit button to modify camera settings
   - Use delete button to remove cameras

### Capturing Snapshots

1. Hover over any camera in the grid
2. Click the **Download** icon (camera icon)
3. Image saves as `snapshot-[cameraId]-[timestamp].jpg`
4. Timestamp and user info automatically recorded

---

## Recording Support (Future-Ready)

The module architecture supports future recording capabilities:

**Planned Features (Phase 2):**
- Start/Stop recording
- Secure recording storage
- Playback of previous recordings
- Download recordings (Admin only)
- Recording status indicators
- Duration and storage metrics

The current UI includes placeholder architecture for these features without requiring future code refactoring.

---

## Permissions & Security

### Access Control

Only authorized roles can access Live Monitoring:
- ✅ Super Admin
- ✅ Admin
- ✅ Quality Manager/Head

**Unauthorized users:**
- Cannot access `/monitoring/live` route
- See "Access Denied" message with explanation
- Redirected appropriately

### Security Features

- Role-based access control
- Secure camera connection (HTTPS/TLS support)
- Encrypted data transmission
- User action logging (snapshot captures)
- Camera status verification

---

## Performance Optimization

### Bandwidth Management
- Automatic quality adjustment based on available bandwidth
- Multiple stream quality options
- Adaptive bitrate streaming

### Connection Handling
- Automatic reconnection on drop
- Graceful error messages
- Connection status indicators
- Timeout management

### UI Responsiveness
- Optimized for desktop and tablet
- Touch-friendly controls
- Responsive grid layouts
- Smooth animations

---

## Data Structure

### Camera Object
```typescript
interface Camera {
  id: string;                                    // Unique identifier
  name: string;                                  // Display name
  factory: string;                               // Associated factory
  location: string;                              // Physical location
  status: "online" | "offline" | "reconnecting" | "disabled";
  type: "ip-rtsp" | "onvif" | "usb" | "network" | "hls" | "webrtc";
  url: string;                                   // Stream/connection URL
  lastConnected: string;                         // Last connection timestamp
  signalStrength?: number;                       // 0-100 percentage
  resolution?: string;                           // e.g., "1920x1080"
  frameRate?: string;                            // e.g., "30fps"
  enabled: boolean;                              // Enable/disable flag
  linkedInspection?: string;                     // Optional inspection link
}
```

### Inspection Object
```typescript
interface Inspection {
  id: string;                                    // Inspection ID
  auditorName: string;                           // Auditor full name
  factoryName: string;                           // Factory name
  buyer: string;                                 // Buyer name
  supplier: string;                              // Supplier name
  poNumber: string;                              // Purchase Order number
  styleNumber: string;                           // Style/SKU number
  inspectionStage: string;                       // Inspection stage
  status: string;                                // Current status
  startTime: string;                             // Start time
  duration: string;                              // Live duration
}
```

---

## Routes

### Main Route
- **Route:** `/monitoring/live`
- **Component:** `LiveMonitoring.tsx`
- **Access:** Protected (Admin/Quality Manager only)
- **Path Prefix:** `/monitoring`

### Integration Points
- Accessible from Dashboard (Live Monitoring card)
- Links to camera management
- Displays inspection information
- Supports snapshot functionality

---

## Integration with Other Modules

### Audit Form Integration
- Can link cameras to active inspections
- Snapshots save to inspection records
- Timestamp and user tracking

### Admin Panel
- Camera management UI
- Permission configuration
- User access control
- Audit trail logging

### Analytics & Reports
- Camera usage statistics
- Inspection monitoring metrics
- Uptime/downtime reports
- Performance analytics

---

## Browser Support

**Fully Supported:**
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

**Requirements:**
- Modern JavaScript (ES2020+)
- WebGL for video rendering
- Camera/RTSP stream support (browser dependent)
- CORS enabled on camera sources

---

## Future Enhancements

### Phase 2 Features
- 🎬 Recording and playback
- 📊 Recording analytics
- 🎯 PTZ (Pan-Tilt-Zoom) controls
- 🔌 Additional camera integrations
- 📱 Mobile app support
- 🌐 Browser-based RTSP players

### Phase 3 Features
- 🤖 AI-powered anomaly detection
- 📈 Advanced analytics
- 🔐 Enhanced security features
- 🌍 Multi-location monitoring
- 📧 Alert notifications
- 🖨️ Report generation

---

## Troubleshooting

### Camera Won't Connect
1. Check camera URL/IP address
2. Verify camera is online
3. Check network connectivity
4. Confirm camera type selection
5. Review firewall/security settings

### Poor Video Quality
1. Check network bandwidth
2. Lower resolution setting
3. Reduce frame rate
4. Check camera quality settings
5. Verify camera health

### No Snapshots
1. Allow camera permissions in browser
2. Check browser console for errors
3. Verify camera is streaming
4. Try different browser
5. Contact support

---

## Support & Documentation

- **Module Location:** `client/pages/LiveMonitoring.tsx`
- **Components:** `client/components/LiveVideoViewer.tsx`, `CameraStatusDashboard.tsx`, `InspectionInfoPanel.tsx`, `CameraManager.tsx`
- **Route:** Protected route at `/monitoring/live`
- **Access:** Admin and Quality Manager roles only

---

## Deployment Checklist

- ✅ Code reviewed and tested
- ✅ TypeScript compilation passes
- ✅ Components exported correctly
- ✅ Routes protected with access control
- ✅ Responsive design verified
- ✅ Build succeeds without errors
- ✅ Performance optimized
- ✅ Documentation complete

---

**Status:** Ready for Production
**Last Updated:** 2024
**Version:** 1.0.0
