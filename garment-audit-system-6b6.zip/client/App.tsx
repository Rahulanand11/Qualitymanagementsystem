import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ToastProvider } from "@/components/ui/toast";
import { SessionFooter } from "@/components/SessionFooter";
import { RoleBasedRedirect } from "@/components/RoleBasedRedirect";
import { AuthProvider } from "./contexts/AuthContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import AuditorOnboarding from "./pages/AuditorOnboarding";
import AuditForm from "./pages/AuditForm";
import AuditHistory from "./pages/AuditHistory";
import Analytics from "./pages/Analytics";
import AuditReport from "./pages/AuditReport";
import AdvancedAnalytics from "./pages/AdvancedAnalytics";
import ManagementReports from "./pages/ManagementReports";
import ClientReview from "./pages/ClientReview";
import AuditorPerformance from "./pages/AuditorPerformance";
import AdminPanel from "./pages/AdminPanel";
import LiveMonitoring from "./pages/LiveMonitoring";
import AIAssistant from "./pages/AIAssistant";
import BuyerPortal from "./pages/BuyerPortal";
import BuyerReports from "./pages/BuyerReports";
import AuditorEmailManagement from "./pages/AuditorEmailManagement";
import AuditorSignup from "./pages/AuditorSignup";
import BuyerSignup from "./pages/BuyerSignup";
import BuyerApprovalManagement from "./pages/BuyerApprovalManagement";
import AdminSettings from "./pages/AdminSettings";
import { BuyerRoute } from "@/components/BuyerRoute";
import Placeholder from "./pages/Placeholder";

const queryClient = new QueryClient();

const App = () => (
  <AuthProvider>
    <ToastProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <BrowserRouter>
            <RoleBasedRedirect />
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Index />} />
              <Route path="/signup/auditor" element={<AuditorSignup />} />
              <Route path="/signup/buyer" element={<BuyerSignup />} />
              <Route path="/onboarding" element={<ProtectedRoute element={<AuditorOnboarding />} />} />
              <Route path="/audit/new" element={<ProtectedRoute element={<AuditForm />} />} />
              <Route path="/audit/report/:id" element={<ProtectedRoute element={<AuditReport />} />} />
              <Route path="/audit/client/:id" element={<ClientReview />} />
              <Route path="/audits" element={<ProtectedRoute element={<AuditHistory />} />} />
              <Route path="/analytics" element={<ProtectedRoute element={<Analytics />} />} />
              <Route path="/analytics/advanced" element={<ProtectedRoute element={<AdvancedAnalytics />} />} />
              <Route path="/analytics/auditors" element={<ProtectedRoute element={<AuditorPerformance />} />} />
              <Route path="/reports" element={<ProtectedRoute element={<ManagementReports />} />} />
              <Route path="/admin" element={<ProtectedRoute element={<AdminPanel />} />} />
              <Route path="/admin/auditors" element={<ProtectedRoute element={<AuditorEmailManagement />} />} />
              <Route path="/admin/buyer-approvals" element={<ProtectedRoute element={<BuyerApprovalManagement />} />} />
              <Route path="/admin/settings" element={<ProtectedRoute element={<AdminSettings />} />} />
              <Route path="/monitoring/live" element={<ProtectedRoute element={<LiveMonitoring />} />} />
              <Route path="/ai-assistant" element={<ProtectedRoute element={<AIAssistant />} />} />

              {/* Buyer Portal Routes */}
              <Route path="/buyer/dashboard" element={<BuyerRoute element={<BuyerPortal />} />} />
              <Route path="/buyer/reports" element={<BuyerRoute element={<BuyerReports />} />} />
              <Route path="/buyer/shipments" element={<BuyerRoute element={<Placeholder title="Shipment Readiness" description="Track shipment status and readiness across all orders." />} />} />
              <Route path="/buyer/analytics" element={<BuyerRoute element={<Placeholder title="Buyer Analytics" description="View quality trends and performance analytics." />} />} />

              <Route path="/users" element={<ProtectedRoute element={<Placeholder title="User Management" description="Manage auditors, quality managers, and administrators." />} />} />
              <Route path="/settings" element={<ProtectedRoute element={<Placeholder title="Settings" description="Configure quality standards, defect categories, and email recipients." />} />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
            <SessionFooter />
            <Toaster />
            <Sonner />
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </ToastProvider>
  </AuthProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
