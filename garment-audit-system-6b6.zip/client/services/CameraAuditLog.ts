// CP Plus CCTV Audit Trail Logging Service
// Maintains complete audit logs for compliance and security

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: string;
  action: AuditAction;
  category: AuditCategory;
  resource: string; // Camera ID, Device ID, etc.
  details: Record<string, any>;
  status: "success" | "failed";
  errorMessage?: string;
}

export type AuditAction =
  | "DEVICE_CONNECT"
  | "DEVICE_DISCONNECT"
  | "CAMERA_VIEW"
  | "CAMERA_SNAPSHOT"
  | "SNAPSHOT_DOWNLOAD"
  | "MAPPING_CREATE"
  | "MAPPING_UPDATE"
  | "MAPPING_DELETE"
  | "CAMERA_ENABLE"
  | "CAMERA_DISABLE"
  | "CONFIG_CHANGE"
  | "STREAM_QUALITY_CHANGE"
  | "CONNECTION_TEST"
  | "ACCESS_DENIED";

export type AuditCategory =
  | "device_management"
  | "camera_access"
  | "snapshot_capture"
  | "mapping_management"
  | "configuration"
  | "security";

class CameraAuditLogService {
  private logs: AuditLogEntry[] = [];
  private localStorageKey = "cp_plus_audit_logs";

  constructor() {
    this.loadLogs();
  }

  private loadLogs() {
    try {
      const stored = localStorage.getItem(this.localStorageKey);
      if (stored) {
        this.logs = JSON.parse(stored);
      }
    } catch (error) {
      console.error("Failed to load audit logs:", error);
    }
  }

  private saveLogs() {
    try {
      localStorage.setItem(this.localStorageKey, JSON.stringify(this.logs));
    } catch (error) {
      console.error("Failed to save audit logs:", error);
    }
  }

  /**
   * Log a device connection event
   */
  logDeviceConnection(
    userId: string,
    userName: string,
    userRole: string,
    deviceId: string,
    deviceName: string,
    success: boolean,
    error?: string
  ) {
    this.addLog({
      action: "DEVICE_CONNECT",
      category: "device_management",
      resource: deviceId,
      details: { deviceName },
      userId,
      userName,
      userRole,
      status: success ? "success" : "failed",
      errorMessage: error,
    });
  }

  /**
   * Log a device disconnection event
   */
  logDeviceDisconnection(
    userId: string,
    userName: string,
    userRole: string,
    deviceId: string,
    reason: string
  ) {
    this.addLog({
      action: "DEVICE_DISCONNECT",
      category: "device_management",
      resource: deviceId,
      details: { reason },
      userId,
      userName,
      userRole,
      status: "success",
    });
  }

  /**
   * Log camera view/streaming access
   */
  logCameraView(
    userId: string,
    userName: string,
    userRole: string,
    cameraId: string,
    inspectionId?: string,
    durationSeconds?: number
  ) {
    this.addLog({
      action: "CAMERA_VIEW",
      category: "camera_access",
      resource: cameraId,
      details: {
        inspectionId: inspectionId || null,
        durationSeconds: durationSeconds || null,
      },
      userId,
      userName,
      userRole,
      status: "success",
    });
  }

  /**
   * Log snapshot capture
   */
  logSnapshotCapture(
    userId: string,
    userName: string,
    userRole: string,
    cameraId: string,
    inspectionId: string,
    fileName: string
  ) {
    this.addLog({
      action: "CAMERA_SNAPSHOT",
      category: "snapshot_capture",
      resource: cameraId,
      details: {
        inspectionId,
        fileName,
        timestamp: new Date().toISOString(),
      },
      userId,
      userName,
      userRole,
      status: "success",
    });
  }

  /**
   * Log snapshot download
   */
  logSnapshotDownload(
    userId: string,
    userName: string,
    userRole: string,
    snapshotId: string,
    inspectionId: string
  ) {
    this.addLog({
      action: "SNAPSHOT_DOWNLOAD",
      category: "snapshot_capture",
      resource: snapshotId,
      details: { inspectionId },
      userId,
      userName,
      userRole,
      status: "success",
    });
  }

  /**
   * Log camera to inspection mapping changes
   */
  logMappingChange(
    userId: string,
    userName: string,
    userRole: string,
    mappingId: string,
    action: "CREATE" | "UPDATE" | "DELETE",
    details: Record<string, any>
  ) {
    this.addLog({
      action:
        action === "CREATE"
          ? "MAPPING_CREATE"
          : action === "UPDATE"
          ? "MAPPING_UPDATE"
          : "MAPPING_DELETE",
      category: "mapping_management",
      resource: mappingId,
      details,
      userId,
      userName,
      userRole,
      status: "success",
    });
  }

  /**
   * Log configuration changes
   */
  logConfigurationChange(
    userId: string,
    userName: string,
    userRole: string,
    configType: string,
    oldValue: any,
    newValue: any
  ) {
    this.addLog({
      action: "CONFIG_CHANGE",
      category: "configuration",
      resource: configType,
      details: { oldValue, newValue },
      userId,
      userName,
      userRole,
      status: "success",
    });
  }

  /**
   * Log access denied events
   */
  logAccessDenied(
    userId: string,
    userName: string,
    userRole: string,
    resource: string,
    reason: string
  ) {
    this.addLog({
      action: "ACCESS_DENIED",
      category: "security",
      resource,
      details: { reason },
      userId,
      userName,
      userRole,
      status: "failed",
      errorMessage: reason,
    });
  }

  /**
   * Internal method to add a log entry
   */
  private addLog(entry: Omit<AuditLogEntry, "id" | "timestamp">) {
    const logEntry: AuditLogEntry = {
      ...entry,
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
    };

    this.logs.push(logEntry);
    this.saveLogs();

    // Keep only last 10000 logs to prevent storage bloat
    if (this.logs.length > 10000) {
      this.logs = this.logs.slice(-10000);
      this.saveLogs();
    }
  }

  /**
   * Get audit logs with optional filtering
   */
  getLogs(filters?: {
    userId?: string;
    category?: AuditCategory;
    action?: AuditAction;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
  }): AuditLogEntry[] {
    let filtered = [...this.logs];

    if (filters?.userId) {
      filtered = filtered.filter((log) => log.userId === filters.userId);
    }

    if (filters?.category) {
      filtered = filtered.filter((log) => log.category === filters.category);
    }

    if (filters?.action) {
      filtered = filtered.filter((log) => log.action === filters.action);
    }

    if (filters?.startDate) {
      filtered = filtered.filter(
        (log) => new Date(log.timestamp) >= filters.startDate!
      );
    }

    if (filters?.endDate) {
      filtered = filtered.filter(
        (log) => new Date(log.timestamp) <= filters.endDate!
      );
    }

    // Sort by timestamp descending (newest first)
    filtered.sort(
      (a, b) =>
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    if (filters?.limit) {
      filtered = filtered.slice(0, filters.limit);
    }

    return filtered;
  }

  /**
   * Get summary statistics for a time period
   */
  getStatistics(
    startDate?: Date,
    endDate?: Date
  ): {
    totalEvents: number;
    successfulEvents: number;
    failedEvents: number;
    byCategory: Record<string, number>;
    byUser: Record<string, number>;
  } {
    const logs = this.getLogs({ startDate, endDate });

    const stats = {
      totalEvents: logs.length,
      successfulEvents: logs.filter((log) => log.status === "success").length,
      failedEvents: logs.filter((log) => log.status === "failed").length,
      byCategory: {} as Record<string, number>,
      byUser: {} as Record<string, number>,
    };

    logs.forEach((log) => {
      stats.byCategory[log.category] =
        (stats.byCategory[log.category] || 0) + 1;
      stats.byUser[log.userName] = (stats.byUser[log.userName] || 0) + 1;
    });

    return stats;
  }

  /**
   * Clear all logs (Admin only - should be called with strict authorization)
   */
  clearLogs(confirmationRequired: boolean = true) {
    if (confirmationRequired) {
      const confirmed = confirm(
        "This will permanently delete all audit logs. This action cannot be undone. Are you sure?"
      );
      if (!confirmed) return;
    }

    this.logs = [];
    localStorage.removeItem(this.localStorageKey);
  }

  /**
   * Export logs as JSON for compliance/archival
   */
  exportLogs(filters?: Parameters<typeof this.getLogs>[0]): string {
    const logsToExport = this.getLogs(filters);
    return JSON.stringify(logsToExport, null, 2);
  }

  /**
   * Export logs as CSV for spreadsheet analysis
   */
  exportLogsAsCSV(filters?: Parameters<typeof this.getLogs>[0]): string {
    const logsToExport = this.getLogs(filters);

    const headers = [
      "Timestamp",
      "User",
      "Role",
      "Action",
      "Category",
      "Resource",
      "Status",
      "Details",
    ];

    const rows = logsToExport.map((log) => [
      log.timestamp,
      log.userName,
      log.userRole,
      log.action,
      log.category,
      log.resource,
      log.status,
      JSON.stringify(log.details),
    ]);

    const csv = [
      headers.join(","),
      ...rows.map((row) =>
        row.map((cell) => `"${cell}"`).join(",")
      ),
    ].join("\n");

    return csv;
  }
}

// Export singleton instance
export const cameraAuditLog = new CameraAuditLogService();
