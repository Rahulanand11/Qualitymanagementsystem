export interface AuditEmailData {
  id: string;
  result: "pass" | "fail" | "conditional";
  factoryName: string;
  buyerName: string;
  supplierName: string;
  poNumber: string;
  styleNumber: string;
  styleName: string;
  inspectionStage: string;
  inspectionDate: string;
  auditorName: string;
  qualityScore: number;
  totalDefects: number;
  shipmentStatus: "ready" | "requires_action" | "hold";
}

export class EmailService {
  static getEmailSubject(result: "pass" | "fail" | "conditional"): string {
    switch (result) {
      case "pass":
        return "✓ Shipment Passed – Inspection Completed";
      case "fail":
        return "✗ Shipment Failed – Immediate Attention Required";
      case "conditional":
        return "⚠ Shipment Requires Management Decision";
      default:
        return "Inspection Report Notification";
    }
  }

  static getEmailBody(audit: AuditEmailData): string {
    const baseUrl = window.location.origin;
    const reportLink = `${baseUrl}/audit/report/${audit.id}`;

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; background: #fff; }
    .header { background: linear-gradient(135deg, #0066cc 0%, #ff6600 100%); color: white; padding: 40px 20px; text-align: center; }
    .header h1 { margin: 0; font-size: 28px; }
    .header p { margin: 10px 0 0 0; opacity: 0.9; }
    .content { padding: 40px 20px; }
    .status-box { 
      padding: 20px; 
      border-radius: 8px; 
      margin-bottom: 30px; 
      text-align: center;
      font-weight: bold;
    }
    .status-pass { background: #d4edda; color: #155724; border: 2px solid #28a745; }
    .status-fail { background: #f8d7da; color: #721c24; border: 2px solid #dc3545; }
    .status-conditional { background: #fff3cd; color: #856404; border: 2px solid #ffc107; }
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 30px;
    }
    .info-item {
      padding: 15px;
      background: #f8f9fa;
      border-radius: 6px;
    }
    .info-label { font-size: 12px; color: #666; text-transform: uppercase; margin-bottom: 5px; }
    .info-value { font-size: 16px; font-weight: 600; color: #333; }
    .buttons {
      display: flex;
      gap: 10px;
      margin-bottom: 30px;
    }
    .btn {
      flex: 1;
      padding: 12px 20px;
      border-radius: 6px;
      text-align: center;
      text-decoration: none;
      font-weight: 600;
      font-size: 14px;
    }
    .btn-primary { background: #0066cc; color: white; }
    .btn-secondary { background: #e9ecef; color: #333; }
    .btn:hover { opacity: 0.9; }
    .footer {
      padding: 20px;
      border-top: 1px solid #eee;
      font-size: 12px;
      color: #666;
      text-align: center;
    }
    .metrics {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-bottom: 30px;
    }
    .metric {
      padding: 15px;
      border: 2px solid #ddd;
      border-radius: 6px;
      text-align: center;
    }
    .metric-value { font-size: 24px; font-weight: bold; color: #0066cc; }
    .metric-label { font-size: 12px; color: #666; margin-top: 5px; }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      <img src="https://unyxstudio.com/wp-content/uploads/2025/09/UNYX-3-e1757072083992.png" alt="UNYX" style="height: 40px; margin-bottom: 10px;">
      <h1>Inspection Report Notification</h1>
      <p>Quality Management System</p>
    </div>

    <!-- Content -->
    <div class="content">
      <!-- Status -->
      <div class="status-box status-${audit.result}">
        ${audit.result === "pass" ? "✓ PASSED" : audit.result === "fail" ? "✗ FAILED" : "⚠ CONDITIONAL"}
      </div>

      <!-- Key Metrics -->
      <div class="metrics">
        <div class="metric">
          <div class="metric-value">${audit.qualityScore}%</div>
          <div class="metric-label">Quality Score</div>
        </div>
        <div class="metric">
          <div class="metric-value">${audit.totalDefects}</div>
          <div class="metric-label">Defects Found</div>
        </div>
      </div>

      <!-- Inspection Details -->
      <div class="info-grid">
        <div class="info-item">
          <div class="info-label">Factory</div>
          <div class="info-value">${audit.factoryName}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Buyer</div>
          <div class="info-value">${audit.buyerName}</div>
        </div>
        <div class="info-item">
          <div class="info-label">PO Number</div>
          <div class="info-value">${audit.poNumber}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Style Number</div>
          <div class="info-value">${audit.styleNumber}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Style Name</div>
          <div class="info-value">${audit.styleName}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Inspection Stage</div>
          <div class="info-value">${audit.inspectionStage}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Inspection Date</div>
          <div class="info-value">${new Date(audit.inspectionDate).toLocaleDateString()}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Auditor</div>
          <div class="info-value">${audit.auditorName}</div>
        </div>
      </div>

      <!-- Shipment Status -->
      <div class="info-item">
        <div class="info-label">Shipment Readiness</div>
        <div class="info-value">
          ${audit.shipmentStatus === "ready" ? "🟢 Ready to Ship" : audit.shipmentStatus === "requires_action" ? "🟡 Requires Action" : "🔴 On Hold"}
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="buttons">
        <a href="${reportLink}" class="btn btn-primary">View Full Report</a>
        <a href="${reportLink}" class="btn btn-secondary">Download PDF</a>
      </div>

      <!-- Notes -->
      <div style="background: #f0f7ff; padding: 15px; border-radius: 6px; margin-bottom: 30px;">
        <p style="margin: 0; color: #0066cc; font-weight: 600;">Next Steps</p>
        <ul style="margin: 10px 0 0 0; padding-left: 20px; font-size: 14px;">
          <li>Review the complete inspection report</li>
          <li>Take necessary actions based on inspection result</li>
          <li>Coordinate with factory if corrective actions needed</li>
          <li>Notify buyer of shipment status</li>
        </ul>
      </div>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p style="margin: 0;">This is an automated email from UNYX Quality Management System</p>
      <p style="margin: 10px 0 0 0;">© 2024 UNYX Studio. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
    `;

    return html;
  }

  static sendNotificationEmail(audit: AuditEmailData, toEmails: string[]): Promise<void> {
    // Simulate email sending (in production, would call backend API)
    const subject = this.getEmailSubject(audit.result);
    const body = this.getEmailBody(audit);

    // Store in localStorage for demo purposes
    const notifications = JSON.parse(localStorage.getItem("emailNotifications") || "[]");
    notifications.push({
      id: `EMAIL-${Date.now()}`,
      subject,
      to: toEmails,
      body,
      audit,
      sentAt: new Date().toISOString(),
      status: "sent",
    });
    localStorage.setItem("emailNotifications", JSON.stringify(notifications));

    // Log for demo
    console.log("📧 Email notification queued:", {
      subject,
      recipients: toEmails,
      auditId: audit.id,
    });

    return Promise.resolve();
  }

  static getManagementEmails(): string[] {
    // Get from settings or use defaults
    const settings = JSON.parse(localStorage.getItem("emailSettings") || "{}");
    return settings.managementEmails || ["management@unyx.com"];
  }
}
