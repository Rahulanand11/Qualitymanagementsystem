// AI Inspection Summary Service
// Analyzes inspection data and generates intelligent summaries

export interface DefectCount {
  critical: number;
  major: number;
  minor: number;
}

export interface InspectionData {
  auditorName: string;
  factoryName: string;
  buyer: string;
  supplier: string;
  poNumber: string;
  styleNumber: string;
  inspectionStage: string;
  inspectionType: "100" | "aql15" | "aql25";
  defects: Array<{
    category: string;
    severity: "critical" | "major" | "minor";
    description: string;
    quantity: number;
  }>;
  measurements?: Array<{
    name: string;
    value: number;
    tolerance: number;
    status: "pass" | "fail";
  }>;
  checkpointResults?: Record<string, "pass" | "fail">;
  images?: string[];
  remarks?: string;
}

export interface AIInspectionSummary {
  overallResult: "Pass" | "Conditional Pass" | "Fail";
  executiveSummary: string;
  keyFindings: string[];
  defectAnalysis: {
    critical: { count: number; description: string };
    major: { count: number; description: string };
    minor: { count: number; description: string };
  };
  measurementAnalysis: {
    checked: number;
    withinTolerance: number;
    outsideTolerance: number;
    largestDeviation: number;
    averageDeviation: number;
    assessment: string;
  };
  rootCauses: Array<{
    cause: string;
    likelihood: "High" | "Medium" | "Low";
    relevantDefects: string[];
  }>;
  correctiveActions: Array<{
    action: string;
    priority: "Critical" | "High" | "Medium";
    expectedImpact: string;
  }>;
  shipmentRiskAssessment: {
    riskLevel: "Low" | "Medium" | "High";
    reasoning: string;
    recommendedAction: string;
  };
  qualityScore: {
    overall: number;
    breakdown: {
      aqlCompliance: number;
      measurementAccuracy: number;
      defectSeverity: number;
      workmanship: number;
      packingQuality: number;
      completeness: number;
    };
    rating: "Excellent" | "Good" | "Acceptable" | "Needs Improvement" | "Critical";
  };
  generatedAt: string;
}

class AIInspectionSummaryService {
  /**
   * Generate comprehensive AI inspection summary from inspection data
   */
  generateSummary(data: InspectionData): AIInspectionSummary {
    const defectCounts = this.countDefects(data);
    const measurementAnalysis = this.analyzeMeasurements(data);
    const overallResult = this.determineOverallResult(defectCounts, measurementAnalysis);
    const qualityScore = this.calculateQualityScore(defectCounts, measurementAnalysis, data);
    const rootCauses = this.analyzeRootCauses(data, defectCounts);
    const correctiveActions = this.generateCorrectiveActions(data, rootCauses, defectCounts);
    const shipmentRisk = this.assessShipmentRisk(overallResult, defectCounts, qualityScore);

    return {
      overallResult,
      executiveSummary: this.generateExecutiveSummary(data, overallResult, qualityScore, defectCounts),
      keyFindings: this.generateKeyFindings(data, defectCounts, measurementAnalysis),
      defectAnalysis: {
        critical: { count: defectCounts.critical, description: this.describeDefectLevel("critical", data) },
        major: { count: defectCounts.major, description: this.describeDefectLevel("major", data) },
        minor: { count: defectCounts.minor, description: this.describeDefectLevel("minor", data) },
      },
      measurementAnalysis,
      rootCauses,
      correctiveActions,
      shipmentRiskAssessment: shipmentRisk,
      qualityScore,
      generatedAt: new Date().toISOString(),
    };
  }

  private countDefects(data: InspectionData): DefectCount {
    return {
      critical: data.defects.filter((d) => d.severity === "critical").length,
      major: data.defects.filter((d) => d.severity === "major").length,
      minor: data.defects.filter((d) => d.severity === "minor").length,
    };
  }

  private analyzeMeasurements(data: InspectionData) {
    if (!data.measurements || data.measurements.length === 0) {
      return {
        checked: 0,
        withinTolerance: 0,
        outsideTolerance: 0,
        largestDeviation: 0,
        averageDeviation: 0,
        assessment: "No measurement data available",
      };
    }

    const withinTolerance = data.measurements.filter((m) => m.status === "pass").length;
    const outsideTolerance = data.measurements.length - withinTolerance;
    const deviations = data.measurements.map((m) => Math.abs(m.value - m.tolerance));
    const largestDeviation = Math.max(...deviations);
    const averageDeviation = deviations.reduce((a, b) => a + b, 0) / deviations.length;

    let assessment = "All measurements within tolerance.";
    if (outsideTolerance > 0) {
      const percentage = ((outsideTolerance / data.measurements.length) * 100).toFixed(1);
      assessment = `${percentage}% of measurements outside tolerance. Requires corrective action.`;
    }

    return {
      checked: data.measurements.length,
      withinTolerance,
      outsideTolerance,
      largestDeviation: parseFloat(largestDeviation.toFixed(2)),
      averageDeviation: parseFloat(averageDeviation.toFixed(2)),
      assessment,
    };
  }

  private determineOverallResult(
    defects: DefectCount,
    measurements: ReturnType<typeof this.analyzeMeasurements>
  ): "Pass" | "Conditional Pass" | "Fail" {
    if (defects.critical > 0 || measurements.outsideTolerance > measurements.checked * 0.1) {
      return "Fail";
    }

    if (defects.major > 2 || measurements.outsideTolerance > 0) {
      return "Conditional Pass";
    }

    return "Pass";
  }

  private generateExecutiveSummary(
    data: InspectionData,
    result: string,
    qualityScore: any,
    defects: DefectCount
  ): string {
    const summaryTemplates: Record<string, string> = {
      Pass: `The ${data.styleNumber} inspection at ${data.factoryName} has been completed successfully with a quality score of ${qualityScore.overall}/100 (${qualityScore.rating}). The garment meets all specified requirements and is ready for shipment. No critical or major defects were identified. Overall production quality is excellent, and the shipment can proceed without further action.`,

      "Conditional Pass": `The ${data.styleNumber} inspection has passed with conditions. Quality score: ${qualityScore.overall}/100 (${qualityScore.rating}). While the shipment can proceed, ${defects.major} major defect(s) were identified that require corrective action in future batches. Recommended actions include process improvements and enhanced quality monitoring.`,

      Fail: `The ${data.styleNumber} inspection has failed due to critical quality issues. Quality score: ${qualityScore.overall}/100 (${qualityScore.rating}). ${defects.critical} critical defect(s) and ${defects.major} major defect(s) were found. The shipment cannot proceed without comprehensive rework or hold for further inspection. Immediate corrective actions are required.`,
    };

    return summaryTemplates[result] || summaryTemplates["Pass"];
  }

  private generateKeyFindings(
    data: InspectionData,
    defects: DefectCount,
    measurements: ReturnType<typeof this.analyzeMeasurements>
  ): string[] {
    const findings: string[] = [];

    if (defects.critical === 0 && defects.major === 0) {
      findings.push("✓ No critical or major defects identified");
    }

    if (defects.critical > 0) {
      findings.push(`⚠ ${defects.critical} critical defect(s) found - immediate action required`);
    }

    if (defects.major > 0) {
      findings.push(`⚠ ${defects.major} major defect(s) identified - corrective action needed`);
    }

    if (measurements.checked > 0) {
      if (measurements.outsideTolerance === 0) {
        findings.push("✓ All measurements within acceptable tolerance");
      } else {
        findings.push(`⚠ ${measurements.outsideTolerance} measurement(s) outside tolerance`);
      }
    }

    if (data.defects.length === 0 && measurements.checked === 0) {
      findings.push("✓ Overall workmanship and quality appear satisfactory");
    }

    if (data.images && data.images.length > 0) {
      findings.push(`✓ ${data.images.length} supporting image(s) documented`);
    }

    return findings;
  }

  private describeDefectLevel(level: "critical" | "major" | "minor", data: InspectionData): string {
    const levelDefects = data.defects.filter((d) => d.severity === level);
    if (levelDefects.length === 0) {
      return `No ${level} defects found.`;
    }

    const types = [...new Set(levelDefects.map((d) => d.category))];
    return `${levelDefects.length} ${level} defect(s) across ${types.length} category(ies): ${types.join(", ")}`;
  }

  private calculateQualityScore(
    defects: DefectCount,
    measurements: ReturnType<typeof this.analyzeMeasurements>,
    data: InspectionData
  ) {
    const aqlCompliance = Math.max(0, 100 - (defects.critical * 50 + defects.major * 20 + defects.minor * 5));
    const measurementAccuracy = measurements.checked > 0
      ? Math.max(0, 100 - (measurements.outsideTolerance / measurements.checked) * 100)
      : 100;
    const defectSeverity = Math.max(0, 100 - (defects.critical * 30 + defects.major * 10));
    const workmanship = data.remarks ? 90 : 85;
    const packingQuality = 95;
    const completeness = (data.images ? 5 : 0);

    const overall = Math.round(
      aqlCompliance * 0.25 +
      measurementAccuracy * 0.2 +
      defectSeverity * 0.25 +
      workmanship * 0.15 +
      packingQuality * 0.1 +
      completeness * 0.05
    );

    let rating: "Excellent" | "Good" | "Acceptable" | "Needs Improvement" | "Critical";
    if (overall >= 95) rating = "Excellent";
    else if (overall >= 85) rating = "Good";
    else if (overall >= 70) rating = "Acceptable";
    else if (overall >= 50) rating = "Needs Improvement";
    else rating = "Critical";

    return {
      overall,
      breakdown: {
        aqlCompliance: Math.round(aqlCompliance),
        measurementAccuracy: Math.round(measurementAccuracy),
        defectSeverity: Math.round(defectSeverity),
        workmanship,
        packingQuality,
        completeness,
      },
      rating,
    };
  }

  private analyzeRootCauses(data: InspectionData, defects: DefectCount) {
    const causes: Array<{ cause: string; likelihood: "High" | "Medium" | "Low"; relevantDefects: string[] }> = [];

    // Sewing machine settings
    if (defects.major > 0) {
      causes.push({
        cause: "Sewing machine misalignment or dull needles",
        likelihood: "High",
        relevantDefects: ["broken stitches", "uneven stitching"],
      });
    }

    // Operator handling
    if (data.defects.some((d) => d.category.includes("handling"))) {
      causes.push({
        cause: "Operator handling or careless work",
        likelihood: "High",
        relevantDefects: ["wrinkles", "creases", "stains"],
      });
    }

    // Measurement deviations
    if (data.measurements && data.measurements.some((m) => m.status === "fail")) {
      causes.push({
        cause: "Cutting inaccuracy or pattern misalignment",
        likelihood: "Medium",
        relevantDefects: ["measurement deviation"],
      });
    }

    // Fabric quality
    if (data.defects.some((d) => d.category.includes("fabric"))) {
      causes.push({
        cause: "Substandard fabric quality or defective raw material",
        likelihood: "Medium",
        relevantDefects: ["fabric defects", "stains", "holes"],
      });
    }

    if (causes.length === 0) {
      causes.push({
        cause: "No significant root causes identified",
        likelihood: "Low",
        relevantDefects: [],
      });
    }

    return causes;
  }

  private generateCorrectiveActions(
    data: InspectionData,
    rootCauses: any[],
    defects: DefectCount
  ) {
    const actions: Array<{ action: string; priority: "Critical" | "High" | "Medium"; expectedImpact: string }> = [];

    if (defects.critical > 0) {
      actions.push({
        action: "Rework all garments with critical defects",
        priority: "Critical",
        expectedImpact: "Eliminate critical quality issues before shipment",
      });
    }

    if (defects.major > 0) {
      actions.push({
        action: "Inspect and rework major defect items",
        priority: "High",
        expectedImpact: "Reduce major defects and improve overall quality",
      });
    }

    if (rootCauses.some((c) => c.cause.includes("machine"))) {
      actions.push({
        action: "Calibrate sewing machines and replace needles",
        priority: "High",
        expectedImpact: "Prevent recurring sewing defects",
      });
    }

    if (rootCauses.some((c) => c.cause.includes("Operator"))) {
      actions.push({
        action: "Provide operator retraining and supervision",
        priority: "Medium",
        expectedImpact: "Improve workmanship and reduce handling defects",
      });
    }

    if (rootCauses.some((c) => c.cause.includes("Cutting"))) {
      actions.push({
        action: "Review and improve cutting process accuracy",
        priority: "Medium",
        expectedImpact: "Reduce measurement deviations",
      });
    }

    return actions;
  }

  private assessShipmentRisk(
    result: "Pass" | "Conditional Pass" | "Fail",
    defects: DefectCount,
    qualityScore: any
  ) {
    let riskLevel: "Low" | "Medium" | "High";
    let reasoning: string;
    let recommendedAction: string;

    if (result === "Fail") {
      riskLevel = "High";
      reasoning = `Critical quality issues detected. ${defects.critical} critical defect(s) and quality score of ${qualityScore.overall}/100 indicate shipment is not ready.`;
      recommendedAction = "Hold shipment. Conduct rework and re-inspection before release.";
    } else if (result === "Conditional Pass") {
      riskLevel = "Medium";
      reasoning = `Quality score ${qualityScore.overall}/100 with ${defects.major} major defect(s). Shipment can proceed but requires monitoring.`;
      recommendedAction = "Proceed with caution. Implement enhanced quality monitoring for future batches.";
    } else {
      riskLevel = "Low";
      reasoning = `High quality score (${qualityScore.overall}/100) with no critical or major defects. Shipment meets all requirements.`;
      recommendedAction = "Clear for shipment. Document inspection and proceed with distribution.";
    }

    return { riskLevel, reasoning, recommendedAction };
  }
}

export { AIInspectionSummaryService };
export const aiInspectionSummary = new AIInspectionSummaryService();
export default aiInspectionSummary;
