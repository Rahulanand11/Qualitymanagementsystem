import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Download, Filter, MapPin, TrendingUp } from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const factoryData = [
  { id: 1, name: "Factory A - Noida", lat: 28.5355, lng: 77.391, status: "passed", audits: 24, passRate: 95 },
  { id: 2, name: "Factory B - Bangalore", lat: 12.9716, lng: 77.5946, status: "passed", audits: 19, passRate: 89 },
  { id: 3, name: "Factory C - Chennai", lat: 13.0827, lng: 80.2707, status: "pending", audits: 15, passRate: 85 },
  { id: 4, name: "Factory D - Delhi", lat: 28.7041, lng: 77.1025, status: "failed", audits: 12, passRate: 78 },
];

const shipmentData = [
  { name: "Approved", value: 65, color: "#10b981" },
  { name: "Rejected", value: 15, color: "#dc2626" },
  { name: "Under Review", value: 20, color: "#f59e0b" },
];

const timelineData = [
  { date: "Mon", approved: 12, rejected: 3, reviewed: 5 },
  { date: "Tue", approved: 15, rejected: 2, reviewed: 4 },
  { date: "Wed", approved: 18, rejected: 1, reviewed: 3 },
  { date: "Thu", approved: 14, rejected: 4, reviewed: 6 },
  { date: "Fri", approved: 20, rejected: 2, reviewed: 3 },
];

export default function AdvancedAnalytics() {
  const [selectedFactory, setSelectedFactory] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState("week");
  const [filterBuyer, setFilterBuyer] = useState("");

  const getStatusColor = (status: string) => {
    switch (status) {
      case "passed":
        return "text-green-600 bg-green-50";
      case "failed":
        return "text-red-600 bg-red-50";
      case "pending":
        return "text-yellow-600 bg-yellow-50";
      default:
        return "text-slate-600 bg-slate-50";
    }
  };

  const getMapColor = (status: string) => {
    switch (status) {
      case "passed":
        return "#10b981";
      case "failed":
        return "#dc2626";
      case "pending":
        return "#f59e0b";
      default:
        return "#6b7280";
    }
  };

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-orange-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <Link
              to="/analytics"
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">
              Advanced Analytics & Geo-Mapping
            </h1>
            <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              <Download className="w-4 h-4" /> Export
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <div className="bg-white rounded-lg border border-orange-200 p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-semibold text-slate-900">Filters</h2>
          </div>
          <div className="grid md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Date Range
              </label>
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="week">This Week</option>
                <option value="month">This Month</option>
                <option value="quarter">This Quarter</option>
                <option value="year">This Year</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Factory
              </label>
              <select
                value={selectedFactory || ""}
                onChange={(e) => setSelectedFactory(e.target.value || null)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Factories</option>
                {factoryData.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Buyer
              </label>
              <input
                type="text"
                value={filterBuyer}
                onChange={(e) => setFilterBuyer(e.target.value)}
                placeholder="Filter by buyer..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Style
              </label>
              <input
                type="text"
                placeholder="Filter by style..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Geo-Mapping Section */}
        <div className="bg-white rounded-lg border border-orange-200 p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <MapPin className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-semibold text-slate-900">
              Geo-Mapping Dashboard
            </h2>
          </div>

          {/* Map Preview */}
          <div className="border-2 border-dashed border-slate-300 rounded-lg h-80 bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center mb-6">
            <div className="text-center">
              <MapPin className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <p className="text-lg font-semibold text-slate-700">
                Interactive World Map
              </p>
              <p className="text-sm text-slate-600 mt-2">
                Factory locations with audit status indicators
              </p>
              <div className="flex justify-center gap-6 mt-6">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-green-500"></div>
                  <span className="text-sm text-slate-600">Passed</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-red-500"></div>
                  <span className="text-sm text-slate-600">Failed</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-yellow-500"></div>
                  <span className="text-sm text-slate-600">Pending</span>
                </div>
              </div>
            </div>
          </div>

          {/* Factory List */}
          <h3 className="text-lg font-semibold text-slate-900 mb-4">
            Factory Locations
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            {factoryData.map((factory) => (
              <div
                key={factory.id}
                className={`border-2 rounded-lg p-4 cursor-pointer transition ${
                  selectedFactory === factory.id.toString()
                    ? "border-blue-500 bg-blue-50"
                    : `border-slate-300 ${
                        getStatusColor(factory.status).split(" ")[1]
                      }`
                }`}
                onClick={() =>
                  setSelectedFactory(
                    selectedFactory === factory.id.toString() ? null : factory.id.toString()
                  )
                }
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold text-slate-900">{factory.name}</p>
                    <p className="text-xs text-slate-600">
                      📍 {factory.lat}, {factory.lng}
                    </p>
                  </div>
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: getMapColor(factory.status) }}
                  ></div>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-200">
                  <div>
                    <p className="text-xs text-slate-600">Audits</p>
                    <p className="font-bold text-slate-900">{factory.audits}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-600">Pass Rate</p>
                    <p className={`font-bold ${factory.passRate > 85 ? "text-green-600" : "text-orange-600"}`}>
                      {factory.passRate}%
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Shipment Analytics */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Shipment Distribution */}
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Shipment Release Analytics
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={shipmentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {shipmentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Shipment Timeline */}
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Shipment Approval Timeline
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={timelineData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="approved" fill="#10b981" stackId="a" />
                <Bar dataKey="rejected" fill="#dc2626" stackId="a" />
                <Bar dataKey="reviewed" fill="#f59e0b" stackId="a" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Export Section */}
        <div className="bg-gradient-to-r from-blue-600 to-orange-500 rounded-lg p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">Export Reports</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <button className="bg-white/20 hover:bg-white/30 backdrop-blur px-6 py-3 rounded-lg font-semibold transition">
              📊 Export to Excel
            </button>
            <button className="bg-white/20 hover:bg-white/30 backdrop-blur px-6 py-3 rounded-lg font-semibold transition">
              📄 Export to PDF
            </button>
            <button className="bg-white/20 hover:bg-white/30 backdrop-blur px-6 py-3 rounded-lg font-semibold transition">
              📧 Schedule Email Report
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
