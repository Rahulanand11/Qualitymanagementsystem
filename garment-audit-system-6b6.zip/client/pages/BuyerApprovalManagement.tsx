import { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { UserProfile } from "@/components/UserProfile";
import { ArrowLeft, CheckCircle2, XCircle, Clock, Search, Filter, MessageSquare } from "lucide-react";

interface BuyerRequest {
  id: string;
  fullName: string;
  companyName: string;
  email: string;
  mobileNumber: string;
  country: string;
  status: "pending" | "approved" | "rejected";
  requestDate: string;
  notes: string;
}

export default function BuyerApprovalManagement() {
  const [requests, setRequests] = useState<BuyerRequest[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "pending" | "approved" | "rejected">("all");
  const [selectedRequest, setSelectedRequest] = useState<BuyerRequest | null>(null);
  const [adminNotes, setAdminNotes] = useState("");
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("buyerApprovals");
    if (stored) {
      setRequests(JSON.parse(stored));
    }
  }, []);

  const filteredRequests = useMemo(() => {
    return requests.filter((req) => {
      const matchesSearch =
        req.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        req.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        req.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = filterStatus === "all" || req.status === filterStatus;
      return matchesSearch && matchesStatus;
    });
  }, [searchTerm, filterStatus, requests]);

  const handleApprove = (request: BuyerRequest) => {
    const updated = requests.map((r) =>
      r.id === request.id ? { ...r, status: "approved" as const, notes: adminNotes } : r
    );
    setRequests(updated);
    localStorage.setItem("buyerApprovals", JSON.stringify(updated));
    setShowModal(false);
    setAdminNotes("");
    setSelectedRequest(null);
  };

  const handleReject = (request: BuyerRequest) => {
    const updated = requests.map((r) =>
      r.id === request.id ? { ...r, status: "rejected" as const, notes: adminNotes } : r
    );
    setRequests(updated);
    localStorage.setItem("buyerApprovals", JSON.stringify(updated));
    setShowModal(false);
    setAdminNotes("");
    setSelectedRequest(null);
  };

  const openModal = (request: BuyerRequest) => {
    setSelectedRequest(request);
    setAdminNotes(request.notes || "");
    setShowModal(true);
  };

  const stats = {
    pending: requests.filter((r) => r.status === "pending").length,
    approved: requests.filter((r) => r.status === "approved").length,
    rejected: requests.filter((r) => r.status === "rejected").length,
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white pb-20">
      {/* Header */}
      <header className="bg-white border-b border-blue-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link to="/admin" className="flex items-center gap-2 text-slate-600 hover:text-slate-900">
                <ArrowLeft className="w-5 h-5" />
                Admin
              </Link>
              <div className="border-l border-blue-300 pl-4">
                <h1 className="text-2xl font-bold text-slate-900">Buyer Approvals</h1>
                <p className="text-sm text-slate-600">Manage buyer registration requests</p>
              </div>
            </div>
            <UserProfile />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg border border-blue-200 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-slate-600 font-medium">Pending Requests</p>
              <Clock className="w-5 h-5 text-yellow-600" />
            </div>
            <p className="text-4xl font-bold text-yellow-600">{stats.pending}</p>
          </div>
          <div className="bg-white rounded-lg border border-green-200 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-slate-600 font-medium">Approved</p>
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-4xl font-bold text-green-600">{stats.approved}</p>
          </div>
          <div className="bg-white rounded-lg border border-red-200 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-slate-600 font-medium">Rejected</p>
              <XCircle className="w-5 h-5 text-red-600" />
            </div>
            <p className="text-4xl font-bold text-red-600">{stats.rejected}</p>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8 border border-blue-200">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by name, company, or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">
                <Filter className="inline w-4 h-4 mr-2" />
                Filter by Status
              </label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as typeof filterStatus)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Requests</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </div>

        {/* Requests Table */}
        {filteredRequests.length === 0 ? (
          <div className="bg-white rounded-lg border-2 border-dashed border-slate-300 p-12 text-center">
            <Clock className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 mb-2">No requests found</p>
            <p className="text-sm text-slate-500">Try adjusting your search or filters</p>
          </div>
        ) : (
          <div className="bg-white rounded-lg border border-blue-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Buyer Information
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Company
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Contact
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Request Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredRequests.map((request) => (
                    <tr key={request.id} className="hover:bg-slate-50 transition">
                      <td className="px-6 py-4">
                        <div className="font-medium text-slate-900">{request.fullName}</div>
                        <div className="text-xs text-slate-600">{request.email}</div>
                      </td>
                      <td className="px-6 py-4 text-slate-700">{request.companyName}</td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-slate-700">{request.mobileNumber}</div>
                        <div className="text-xs text-slate-600">{request.country}</div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-700">
                        {new Date(request.requestDate).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            request.status === "pending"
                              ? "bg-yellow-100 text-yellow-800"
                              : request.status === "approved"
                                ? "bg-green-100 text-green-800"
                                : "bg-red-100 text-red-800"
                          }`}
                        >
                          {request.status === "pending"
                            ? "⏳ Pending"
                            : request.status === "approved"
                              ? "✓ Approved"
                              : "✗ Rejected"}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => openModal(request)}
                          className={`px-3 py-1 rounded text-sm font-medium transition ${
                            request.status === "pending"
                              ? "bg-blue-100 text-blue-700 hover:bg-blue-200"
                              : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                          }`}
                        >
                          {request.status === "pending" ? "Review" : "View"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Modal */}
      {showModal && selectedRequest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-md w-full max-h-96 overflow-y-auto">
            <div className="p-6 border-b border-slate-200">
              <h2 className="text-xl font-bold text-slate-900">Review Buyer Request</h2>
              <p className="text-sm text-slate-600">{selectedRequest.fullName}</p>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <p className="text-xs text-slate-600 uppercase font-semibold mb-1">Full Name</p>
                <p className="text-slate-900 font-medium">{selectedRequest.fullName}</p>
              </div>
              <div>
                <p className="text-xs text-slate-600 uppercase font-semibold mb-1">Company</p>
                <p className="text-slate-900 font-medium">{selectedRequest.companyName}</p>
              </div>
              <div>
                <p className="text-xs text-slate-600 uppercase font-semibold mb-1">Email</p>
                <p className="text-slate-900 font-medium">{selectedRequest.email}</p>
              </div>
              <div>
                <p className="text-xs text-slate-600 uppercase font-semibold mb-1">Mobile</p>
                <p className="text-slate-900 font-medium">{selectedRequest.mobileNumber}</p>
              </div>
              <div>
                <p className="text-xs text-slate-600 uppercase font-semibold mb-1">Country</p>
                <p className="text-slate-900 font-medium">{selectedRequest.country}</p>
              </div>

              {selectedRequest.status === "pending" && (
                <div>
                  <label className="block text-xs text-slate-600 uppercase font-semibold mb-2">
                    <MessageSquare className="inline w-4 h-4 mr-1" />
                    Admin Notes
                  </label>
                  <textarea
                    value={adminNotes}
                    onChange={(e) => setAdminNotes(e.target.value)}
                    placeholder="Add any notes about this request..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    rows={3}
                  />
                </div>
              )}
            </div>

            <div className="p-6 border-t border-slate-200 flex gap-3">
              {selectedRequest.status === "pending" ? (
                <>
                  <button
                    onClick={() => handleApprove(selectedRequest)}
                    className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Approve
                  </button>
                  <button
                    onClick={() => handleReject(selectedRequest)}
                    className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold transition flex items-center justify-center gap-2"
                  >
                    <XCircle className="w-4 h-4" />
                    Reject
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setShowModal(false)}
                  className="w-full px-4 py-2 bg-slate-600 hover:bg-slate-700 text-white rounded-lg font-semibold transition"
                >
                  Close
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
