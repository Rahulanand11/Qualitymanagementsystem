import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { UserProfile } from "@/components/UserProfile";
import {
  ArrowLeft,
  Plus,
  Search,
  Trash2,
  Mail,
  CheckCircle2,
  AlertCircle,
  Copy,
  Eye,
  EyeOff,
  Filter,
} from "lucide-react";

interface AuditorAccount {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  empId: string;
  status: "active" | "inactive" | "pending";
  createdDate: string;
  lastLogin?: string;
  assignedRegion?: string;
}

export default function AuditorEmailManagement() {
  const { user } = useAuth();
  const [auditors, setAuditors] = useState<AuditorAccount[]>([
    {
      id: "AUD-001",
      fullName: "John Smith",
      email: "john.smith@auditors.com",
      phone: "+91 98765-43210",
      empId: "EMP-2024-001",
      status: "active",
      createdDate: "2024-01-10",
      lastLogin: "2024-01-15 10:30",
      assignedRegion: "North",
    },
    {
      id: "AUD-002",
      fullName: "Sarah Johnson",
      email: "sarah.johnson@auditors.com",
      phone: "+91 98765-43211",
      empId: "EMP-2024-002",
      status: "active",
      createdDate: "2024-01-12",
      lastLogin: "2024-01-14 14:45",
      assignedRegion: "South",
    },
    {
      id: "AUD-003",
      fullName: "Mike Chen",
      email: "mike.chen@auditors.com",
      phone: "+91 98765-43212",
      empId: "EMP-2024-003",
      status: "pending",
      createdDate: "2024-01-15",
      assignedRegion: "East",
    },
  ]);

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    empId: "",
    assignedRegion: "",
  });

  // Filter logic
  const filteredAuditors = useMemo(() => {
    return auditors.filter((auditor) => {
      const matchesSearch =
        auditor.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        auditor.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        auditor.empId.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesFilter =
        statusFilter === "all" || auditor.status === statusFilter;

      return matchesSearch && matchesFilter;
    });
  }, [auditors, searchTerm, statusFilter]);

  const handleAddAuditor = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.fullName || !formData.email || !formData.phone) {
      alert("Please fill in all required fields");
      return;
    }

    const newAuditor: AuditorAccount = {
      id: `AUD-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      fullName: formData.fullName,
      email: formData.email,
      phone: formData.phone,
      empId: formData.empId || `EMP-${Date.now()}`,
      status: "pending",
      createdDate: new Date().toISOString().split("T")[0],
      assignedRegion: formData.assignedRegion,
    };

    setAuditors([...auditors, newAuditor]);
    setFormData({
      fullName: "",
      email: "",
      phone: "",
      empId: "",
      assignedRegion: "",
    });
    setShowForm(false);
  };

  const handleDeleteAuditor = (id: string) => {
    if (confirm("Are you sure you want to delete this auditor account?")) {
      setAuditors(auditors.filter((a) => a.id !== id));
    }
  };

  const handleCopyEmail = (email: string) => {
    navigator.clipboard.writeText(email);
    setCopiedEmail(email);
    setTimeout(() => setCopiedEmail(null), 2000);
  };

  const handleActivateAuditor = (id: string) => {
    setAuditors(
      auditors.map((a) =>
        a.id === id ? { ...a, status: "active" as const } : a
      )
    );
  };

  const stats = {
    total: auditors.length,
    active: auditors.filter((a) => a.status === "active").length,
    pending: auditors.filter((a) => a.status === "pending").length,
    inactive: auditors.filter((a) => a.status === "inactive").length,
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white pb-20">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link
                to="/admin"
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900"
              >
                <ArrowLeft className="w-5 h-5" />
                Back
              </Link>
              <div className="border-l border-slate-300 pl-4">
                <h1 className="text-2xl font-bold text-slate-900">
                  Auditor Email Management
                </h1>
                <p className="text-sm text-slate-600">
                  Create and manage auditor accounts
                </p>
              </div>
            </div>
            <UserProfile />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg border border-blue-200 p-4 shadow-sm">
            <p className="text-sm text-slate-600 mb-1">Total Auditors</p>
            <p className="text-3xl font-bold text-blue-600">{stats.total}</p>
          </div>
          <div className="bg-white rounded-lg border border-green-200 p-4 shadow-sm">
            <p className="text-sm text-slate-600 mb-1">Active</p>
            <p className="text-3xl font-bold text-green-600">{stats.active}</p>
          </div>
          <div className="bg-white rounded-lg border border-yellow-200 p-4 shadow-sm">
            <p className="text-sm text-slate-600 mb-1">Pending Activation</p>
            <p className="text-3xl font-bold text-yellow-600">{stats.pending}</p>
          </div>
          <div className="bg-white rounded-lg border border-red-200 p-4 shadow-sm">
            <p className="text-sm text-slate-600 mb-1">Inactive</p>
            <p className="text-3xl font-bold text-red-600">{stats.inactive}</p>
          </div>
        </div>

        {/* Add Auditor Button */}
        <div className="mb-6">
          <button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
          >
            <Plus className="w-5 h-5" />
            Add New Auditor
          </button>
        </div>

        {/* Add Auditor Form */}
        {showForm && (
          <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-6 mb-8">
            <h2 className="text-xl font-bold text-slate-900 mb-6">
              Create New Auditor Account
            </h2>
            <form onSubmit={handleAddAuditor} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) =>
                    setFormData({ ...formData, fullName: e.target.value })
                  }
                  placeholder="John Doe"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  placeholder="john.doe@auditors.com"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) =>
                    setFormData({ ...formData, phone: e.target.value })
                  }
                  placeholder="+91 98765-43210"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Employee ID (Optional)
                </label>
                <input
                  type="text"
                  value={formData.empId}
                  onChange={(e) =>
                    setFormData({ ...formData, empId: e.target.value })
                  }
                  placeholder="EMP-2024-001"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Assigned Region
                </label>
                <select
                  value={formData.assignedRegion}
                  onChange={(e) =>
                    setFormData({ ...formData, assignedRegion: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Region</option>
                  <option value="North">North</option>
                  <option value="South">South</option>
                  <option value="East">East</option>
                  <option value="West">West</option>
                  <option value="Central">Central</option>
                </select>
              </div>

              <div className="sm:col-span-2 flex gap-3">
                <button
                  type="submit"
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
                >
                  Create Account
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-6 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg font-medium transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Search and Filter */}
        <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Search
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by name, email, or employee ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Filter by Status
              </label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="pending">Pending</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>
        </div>

        {/* Auditors Table */}
        <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Phone
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Region
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Last Login
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredAuditors.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-8 text-center text-slate-500">
                      No auditors found
                    </td>
                  </tr>
                ) : (
                  filteredAuditors.map((auditor) => (
                    <tr key={auditor.id} className="hover:bg-slate-50 transition">
                      <td className="px-6 py-4">
                        <div className="font-medium text-slate-900">
                          {auditor.fullName}
                        </div>
                        <div className="text-xs text-slate-600">
                          {auditor.empId}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <span className="text-slate-900">{auditor.email}</span>
                          <button
                            onClick={() => handleCopyEmail(auditor.email)}
                            className="p-1 hover:bg-slate-100 rounded transition"
                            title="Copy email"
                          >
                            <Copy
                              className={`w-4 h-4 ${
                                copiedEmail === auditor.email
                                  ? "text-green-600"
                                  : "text-slate-600"
                              }`}
                            />
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-700">{auditor.phone}</td>
                      <td className="px-6 py-4">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            auditor.status === "active"
                              ? "bg-green-100 text-green-800"
                              : auditor.status === "pending"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-slate-100 text-slate-800"
                          }`}
                        >
                          {auditor.status === "active"
                            ? "✓ Active"
                            : auditor.status === "pending"
                              ? "⏳ Pending"
                              : "✗ Inactive"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-700">
                        {auditor.assignedRegion || "-"}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {auditor.lastLogin || "Never"}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          {auditor.status === "pending" && (
                            <button
                              onClick={() => handleActivateAuditor(auditor.id)}
                              title="Activate account"
                              className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteAuditor(auditor.id)}
                            title="Delete account"
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
