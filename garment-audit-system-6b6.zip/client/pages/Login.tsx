import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Mail, Lock, Phone, Chrome, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [authMode, setAuthMode] = useState<"email" | "phone" | "google">("email");
  const [userRole, setUserRole] = useState<"auditor" | "buyer">("auditor");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showOTP, setShowOTP] = useState(false);
  const [otpSent, setOtpSent] = useState(false);

  const handleGoogleSignIn = () => {
    // Simulate Google Sign-In
    navigate("/onboarding");
  };

  const handleEmailLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      const fullName = email.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, c => c.toUpperCase());
      login(email, password, fullName, userRole);
      // Route based on role
      if (userRole === "buyer") {
        navigate("/buyer/dashboard");
      } else {
        navigate("/");
      }
    }
  };

  const handlePhoneOTPRequest = () => {
    if (phone) {
      setOtpSent(true);
    }
  };

  const handlePhoneOTPVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone && otp) {
      login(phone, otp, "Phone User", userRole);
      if (userRole === "buyer") {
        navigate("/buyer/dashboard");
      } else {
        navigate("/");
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-orange-500 to-blue-600 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Logo & Header */}
        <div className="text-center mb-8">
          <div className="inline-block bg-white rounded-lg p-3 mb-4">
            <img
              src="https://unyxstudio.com/wp-content/uploads/2025/09/UNYX-3-e1757072083992.png"
              alt="UNYX Studio"
              className="h-12"
            />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">GarmentAudit</h1>
          <p className="text-blue-100">Professional Quality Inspection System</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-lg shadow-2xl p-8 backdrop-blur-md">
          {/* Auth Mode Tabs */}
          <div className="flex gap-2 mb-6 border-b border-slate-200">
            <button
              onClick={() => setAuthMode("email")}
              className={`flex-1 pb-3 font-medium transition ${
                authMode === "email"
                  ? "border-b-2 border-blue-600 text-blue-600"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Mail className="w-4 h-4 inline mr-2" /> Email
            </button>
            <button
              onClick={() => setAuthMode("phone")}
              className={`flex-1 pb-3 font-medium transition ${
                authMode === "phone"
                  ? "border-b-2 border-blue-600 text-blue-600"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Phone className="w-4 h-4 inline mr-2" /> Phone OTP
            </button>
            <button
              onClick={() => setAuthMode("google")}
              className={`flex-1 pb-3 font-medium transition ${
                authMode === "google"
                  ? "border-b-2 border-blue-600 text-blue-600"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Chrome className="w-4 h-4 inline mr-2" /> Google
            </button>
          </div>

          {/* Email Login */}
          {authMode === "email" && (
            <form onSubmit={handleEmailLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Login as
                </label>
                <div className="flex gap-3 mb-4">
                  <button
                    type="button"
                    onClick={() => setUserRole("auditor")}
                    className={`flex-1 px-4 py-2 rounded-lg font-medium transition ${
                      userRole === "auditor"
                        ? "bg-blue-600 text-white"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    Auditor
                  </button>
                  <button
                    type="button"
                    onClick={() => setUserRole("buyer")}
                    className={`flex-1 px-4 py-2 rounded-lg font-medium transition ${
                      userRole === "buyer"
                        ? "bg-blue-600 text-white"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    Buyer
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="auditor@company.com"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-600"
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full px-4 py-2 bg-gradient-to-r from-blue-600 to-orange-500 text-white rounded-lg font-semibold hover:shadow-lg transition"
              >
                Sign In with Email
              </button>

              <p className="text-center text-sm text-slate-600">
                Don't have an account?{" "}
                <a href="#" className="text-blue-600 hover:text-blue-700 font-medium">
                  Register here
                </a>
              </p>
            </form>
          )}

          {/* Phone OTP Login */}
          {authMode === "phone" && (
            <form onSubmit={otpSent ? handlePhoneOTPVerify : (e) => { e.preventDefault(); handlePhoneOTPRequest(); }} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98765-43210"
                  disabled={otpSent}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-100"
                  required
                />
              </div>

              {otpSent && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Enter OTP
                  </label>
                  <div className="relative">
                    <input
                      type={showOTP ? "text" : "password"}
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      placeholder="000000"
                      maxLength={6}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowOTP(!showOTP)}
                      className="absolute right-3 top-2.5 text-slate-600"
                    >
                      {showOTP ? (
                        <EyeOff className="w-5 h-5" />
                      ) : (
                        <Eye className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    OTP sent to {phone}
                  </p>
                </div>
              )}

              <button
                type="submit"
                className="w-full px-4 py-2 bg-gradient-to-r from-blue-600 to-orange-500 text-white rounded-lg font-semibold hover:shadow-lg transition"
              >
                {otpSent ? "Verify OTP" : "Send OTP"}
              </button>

              {otpSent && (
                <button
                  type="button"
                  onClick={() => {
                    setOtpSent(false);
                    setOtp("");
                  }}
                  className="w-full px-4 py-2 border border-slate-300 text-slate-700 rounded-lg font-semibold hover:bg-slate-50 transition"
                >
                  Change Phone Number
                </button>
              )}
            </form>
          )}

          {/* Google Sign-In */}
          {authMode === "google" && (
            <div className="space-y-4">
              <button
                onClick={handleGoogleSignIn}
                className="w-full px-4 py-3 bg-white border-2 border-blue-600 text-blue-600 rounded-lg font-semibold hover:bg-blue-50 transition flex items-center justify-center gap-2"
              >
                <Chrome className="w-5 h-5" /> Sign In with Google
              </button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-slate-600">or</span>
                </div>
              </div>

              <p className="text-sm text-slate-600 text-center">
                Securely sign in with your Google account. Your profile information
                will be used to create or link your auditor account.
              </p>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-700">
                <p className="font-semibold mb-2">ℹ️ First time signing in?</p>
                <p>
                  You'll be guided through a quick profile setup to complete your
                  auditor registration.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <p className="text-center text-blue-100 text-sm mt-6">
          © 2024 UNYX Studio. All rights reserved.
        </p>
      </div>
    </div>
  );
}
