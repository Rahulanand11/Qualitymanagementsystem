import { useState } from "react";
import {
  Download,
  Share2,
  MessageCircle,
  Mail,
  Copy,
  QrCode,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ThumbsUp,
  ThumbsDown,
  MessageSquare,
} from "lucide-react";

export default function ClientReview() {
  const [approvalStatus, setApprovalStatus] = useState<
    "pending" | "approved" | "rejected" | "clarification"
  >("pending");
  const [clientComment, setClientComment] = useState("");
  const [showQRModal, setShowQRModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [copied, setCopied] = useState(false);

  const reportData = {
    reportId: "AUDIT-2024-001",
    referenceNumber: "REF-20240115-5847",
    styleNumber: "ST-2024-001",
    poNumber: "PO-123456",
    factoryName: "Factory A - Noida",
    supplierName: "ABC Suppliers",
    auditDate: "2024-01-15",
    auditorName: "John Smith",
    passStatus: "PASSED",
    secureLink: "https://secure.garmentaudit.com/review/AUDIT-2024-001",
    qrCodeUrl: "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=https://secure.garmentaudit.com/review/AUDIT-2024-001",
  };

  const handleApprove = () => {
    setApprovalStatus("approved");
  };

  const handleReject = () => {
    setApprovalStatus("rejected");
  };

  const handleRequestClarification = () => {
    setApprovalStatus("clarification");
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(reportData.secureLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendWhatsApp = () => {
    const message = `Dear Client,\n\nYour Garment Final Audit Report for Style ${reportData.styleNumber} and PO ${reportData.poNumber} has been completed.\n\nPlease review the report using the secure link below:\n\n${reportData.secureLink}\n\nRegards,\nQuality Assurance Team`;
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/?text=${encodedMessage}`, "_blank");
  };

  const handleSendEmail = () => {
    const subject = `Garment Final Audit Report – ${reportData.styleNumber} – ${reportData.poNumber} – ${reportData.passStatus}`;
    const body = `Dear Client,\n\nYour Garment Final Audit Report for Style ${reportData.styleNumber} and PO ${reportData.poNumber} has been completed.\n\nPass/Fail Status: ${reportData.passStatus}\nInspection Date: ${reportData.auditDate}\nAuditor: ${reportData.auditorName}\n\nPlease review the report using the secure link below:\n\n${reportData.secureLink}\n\nRegards,\nQuality Assurance Team`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-orange-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">
                Garment Final Audit Report
              </h1>
              <p className="text-slate-600 mt-1">
                Report ID: {reportData.reportId} | Ref: {reportData.referenceNumber}
              </p>
            </div>
            <div className="text-right">
              <div className="inline-block bg-green-50 border border-green-300 px-4 py-2 rounded-lg">
                <p className="text-sm text-green-700">Status</p>
                <p className="text-2xl font-bold text-green-600">✓ PASSED</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Report Overview */}
        <div className="bg-white rounded-lg border border-orange-200 p-6 mb-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Report Details</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-slate-600 mb-1">Style Number</p>
              <p className="font-semibold text-slate-900">{reportData.styleNumber}</p>
            </div>
            <div>
              <p className="text-sm text-slate-600 mb-1">PO Number</p>
              <p className="font-semibold text-slate-900">{reportData.poNumber}</p>
            </div>
            <div>
              <p className="text-sm text-slate-600 mb-1">Factory</p>
              <p className="font-semibold text-slate-900">{reportData.factoryName}</p>
            </div>
            <div>
              <p className="text-sm text-slate-600 mb-1">Audit Date</p>
              <p className="font-semibold text-slate-900">{reportData.auditDate}</p>
            </div>
            <div>
              <p className="text-sm text-slate-600 mb-1">Auditor</p>
              <p className="font-semibold text-slate-900">{reportData.auditorName}</p>
            </div>
            <div>
              <p className="text-sm text-slate-600 mb-1">Supplier</p>
              <p className="font-semibold text-slate-900">{reportData.supplierName}</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg border border-orange-200 p-6 mb-6">
          <h2 className="text-lg font-bold text-slate-900 mb-4">
            Share & Download
          </h2>
          <div className="grid md:grid-cols-4 gap-4">
            <button
              onClick={handleSendWhatsApp}
              className="flex flex-col items-center gap-2 p-4 border border-green-300 rounded-lg hover:bg-green-50 transition"
            >
              <MessageCircle className="w-6 h-6 text-green-600" />
              <span className="text-sm font-medium text-slate-700">WhatsApp</span>
            </button>

            <button
              onClick={handleSendEmail}
              className="flex flex-col items-center gap-2 p-4 border border-blue-300 rounded-lg hover:bg-blue-50 transition"
            >
              <Mail className="w-6 h-6 text-blue-600" />
              <span className="text-sm font-medium text-slate-700">Email</span>
            </button>

            <button
              onClick={handleCopyLink}
              className="flex flex-col items-center gap-2 p-4 border border-slate-300 rounded-lg hover:bg-slate-50 transition"
            >
              <Copy className="w-6 h-6 text-slate-600" />
              <span className="text-sm font-medium text-slate-700">
                {copied ? "Copied!" : "Copy Link"}
              </span>
            </button>

            <button
              onClick={() => setShowQRModal(true)}
              className="flex flex-col items-center gap-2 p-4 border border-purple-300 rounded-lg hover:bg-purple-50 transition"
            >
              <QrCode className="w-6 h-6 text-purple-600" />
              <span className="text-sm font-medium text-slate-700">QR Code</span>
            </button>
          </div>
        </div>

        {/* Report Sections Placeholder */}
        <div className="bg-white rounded-lg border border-orange-200 p-6 mb-6">
          <h2 className="text-lg font-bold text-slate-900 mb-4">
            Report Contents
          </h2>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 border border-slate-200 rounded">
              <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <p className="font-medium text-slate-900">Auditor Verification Details</p>
                <p className="text-sm text-slate-600">Auditor photo, GPS coordinates, factory location confirmation</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 border border-slate-200 rounded">
              <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <p className="font-medium text-slate-900">Inspection Details</p>
                <p className="text-sm text-slate-600">General information, inspection type, quality checkpoints</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 border border-slate-200 rounded">
              <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <p className="font-medium text-slate-900">Garment Images</p>
                <p className="text-sm text-slate-600">Front, back, side views and defect images</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 border border-slate-200 rounded">
              <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <p className="font-medium text-slate-900">Carton & Packing Images</p>
                <p className="text-sm text-slate-600">Carton views, packing instruction sheets</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 border border-slate-200 rounded">
              <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <p className="font-medium text-slate-900">Defect Summary</p>
                <p className="text-sm text-slate-600">Total defects, major, minor, critical breakdown</p>
              </div>
            </div>
          </div>

          <button className="w-full mt-6 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 transition">
            <Download className="w-5 h-5" /> Download PDF Report
          </button>
        </div>

        {/* Client Approval Section */}
        <div className="bg-white rounded-lg border-2 border-blue-300 p-6 mb-6">
          <h2 className="text-lg font-bold text-slate-900 mb-4">
            Your Approval
          </h2>

          {approvalStatus === "pending" && (
            <div className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-800">
                    Please review the report above and provide your approval status.
                  </p>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <button
                  onClick={handleApprove}
                  className="px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 transition"
                >
                  <ThumbsUp className="w-5 h-5" /> Approve Report
                </button>

                <button
                  onClick={handleReject}
                  className="px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 transition"
                >
                  <ThumbsDown className="w-5 h-5" /> Reject Report
                </button>

                <button
                  onClick={handleRequestClarification}
                  className="px-4 py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 transition"
                >
                  <MessageSquare className="w-5 h-5" /> Request Clarification
                </button>
              </div>
            </div>
          )}

          {approvalStatus === "approved" && (
            <div className="bg-green-50 border border-green-300 rounded-lg p-4">
              <div className="flex gap-3 items-start">
                <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-green-900">Report Approved</p>
                  <p className="text-sm text-green-800 mt-1">
                    Thank you! Your approval has been recorded and the auditor has been notified.
                  </p>
                </div>
              </div>
            </div>
          )}

          {approvalStatus === "rejected" && (
            <div>
              <div className="bg-red-50 border border-red-300 rounded-lg p-4 mb-4">
                <div className="flex gap-3 items-start">
                  <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-red-900">Report Rejected</p>
                    <p className="text-sm text-red-800 mt-1">
                      Please provide details below for why the report is being rejected.
                    </p>
                  </div>
                </div>
              </div>
              <textarea
                placeholder="Please explain the reason for rejection..."
                rows={4}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              />
              <button className="mt-4 w-full px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold transition">
                Submit Rejection
              </button>
            </div>
          )}

          {approvalStatus === "clarification" && (
            <div>
              <div className="bg-orange-50 border border-orange-300 rounded-lg p-4 mb-4">
                <div className="flex gap-3 items-start">
                  <AlertCircle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-orange-900">Clarification Requested</p>
                    <p className="text-sm text-orange-800 mt-1">
                      Please provide details on what clarification is needed.
                    </p>
                  </div>
                </div>
              </div>
              <textarea
                placeholder="Please describe the clarification needed..."
                rows={4}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <button className="mt-4 w-full px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-semibold transition">
                Submit Clarification Request
              </button>
            </div>
          )}
        </div>

        {/* Comments Section */}
        <div className="bg-white rounded-lg border border-orange-200 p-6">
          <h2 className="text-lg font-bold text-slate-900 mb-4">Comments</h2>
          <textarea
            value={clientComment}
            onChange={(e) => setClientComment(e.target.value)}
            placeholder="Add any comments or notes..."
            rows={4}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
          />
          <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition">
            Post Comment
          </button>
        </div>
      </main>

      {/* QR Code Modal */}
      {showQRModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-sm w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-slate-900">Report QR Code</h3>
              <button
                onClick={() => setShowQRModal(false)}
                className="text-slate-600 hover:text-slate-900"
              >
                ✕
              </button>
            </div>
            <img
              src={reportData.qrCodeUrl}
              alt="QR Code"
              className="w-full border border-slate-300 rounded-lg mb-4"
            />
            <p className="text-sm text-slate-600 text-center mb-4">
              Scan this QR code to view the report
            </p>
            <button
              onClick={() => {
                setShowQRModal(false);
              }}
              className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
