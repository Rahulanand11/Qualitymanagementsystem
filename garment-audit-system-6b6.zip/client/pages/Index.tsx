import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { UserProfile } from "@/components/UserProfile";
import { AIAssistantDashboardCard } from "@/components/AIAssistantDashboardCard";
import {
  CheckCircle2,
  Zap,
  BarChart3,
  Lock,
  ArrowRight,
  Menu,
  X,
  Camera,
} from "lucide-react";

export default function Index() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignup, setIsSignup] = useState(false);
  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupRole, setSignupRole] = useState("auditor");
  const { isLoggedIn, login, logout, userRole } = useAuth();

  // Redirect on successful login
  useEffect(() => {
    if (isLoggedIn) {
      if (userRole === "buyer") {
        navigate("/buyer/dashboard", { replace: true });
      }
      // For auditor/admin/manager - stay on dashboard (don't redirect)
      // Dashboard component will be shown below
    }
  }, [isLoggedIn, userRole, navigate]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      const fullName = email.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, c => c.toUpperCase());
      login(email, password, fullName);
      setEmail("");
      setPassword("");
    }
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (signupName && signupEmail && signupPassword) {
      login(signupEmail, signupPassword, signupName, signupRole);
      setSignupName("");
      setSignupEmail("");
      setSignupPassword("");
      setSignupRole("auditor");
      setIsSignup(false);
    }
  };

  if (isLoggedIn) {
    return <Dashboard onLogout={logout} />;
  }

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-orange-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <img
                src="https://unyxstudio.com/wp-content/uploads/2025/09/UNYX-3-e1757072083992.png"
                alt="UNYX Studio"
                className="h-10"
              />
              <span className="text-lg font-bold text-slate-900">
                Quality Audit System
              </span>
            </div>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-slate-300 hover:text-white"
            >
              {isMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>

            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-slate-300 hover:text-white">
                Features
              </a>
              <a href="#benefits" className="text-slate-300 hover:text-white">
                Benefits
              </a>
              <button
              onClick={() =>
                document.getElementById("login")?.scrollIntoView()
              }
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
            >
              Sign In
            </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-slate-900 mb-6">
            Professional Garment Quality{" "}
            <span className="bg-gradient-to-r from-blue-600 to-orange-500 bg-clip-text text-transparent">
              Inspection Management
            </span>
          </h1>
          <p className="text-xl text-slate-700 mb-8 max-w-2xl mx-auto">
            Digitize your final audit reports with intelligent AQL sampling,
            real-time analytics, and automated PDF generation. Replace manual
            inspections with a modern, mobile-first platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() =>
                document.getElementById("login")?.scrollIntoView()
              }
              className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition flex items-center justify-center gap-2"
            >
              Get Started <ArrowRight className="w-5 h-5" />
            </button>
            <a
              href="#features"
              className="px-8 py-3 border-2 border-blue-600 hover:border-orange-500 text-blue-600 hover:text-orange-500 rounded-lg font-semibold transition"
            >
              Learn More
            </a>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-t border-orange-200">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-slate-900 text-center mb-16">
            Powerful Features
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: CheckCircle2,
                title: "AQL Sampling",
                desc: "Automatic calculations for 100%, AQL 1.5, and AQL 2.5 inspections",
              },
              {
                icon: Zap,
                title: "Instant Reports",
                desc: "Generate professional PDF reports with all inspection data and images",
              },
              {
                icon: BarChart3,
                title: "Real Analytics",
                desc: "Track defect trends, pass rates, and auditor performance",
              },
              {
                icon: Lock,
                title: "Secure Access",
                desc: "Role-based permissions for auditors, managers, and admins",
              },
              {
                icon: CheckCircle2,
                title: "Mobile Ready",
                desc: "Fully responsive design for factory floor tablets and phones",
              },
              {
                icon: Zap,
                title: "Auto Email",
                desc: "Reports automatically sent to designated stakeholders",
              },
            ].map((feature, i) => (
              <div
                key={i}
                className="bg-white border border-orange-200 p-6 rounded-lg hover:border-blue-600 hover:shadow-lg transition"
              >
                <feature.icon className="w-10 h-10 text-blue-600 mb-4" />
                <h3 className="text-lg font-semibold text-slate-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-slate-700">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div id="benefits" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-orange-50 border-t border-orange-200">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-slate-900 text-center mb-16">
            Why Choose Our System?
          </h2>
          <div className="space-y-6">
            {[
              "Reduce inspection time by 60% with digital workflows",
              "100% compliance with international AQL standards",
              "Centralized database for audit history and compliance",
              "Real-time dashboards for management visibility",
              "Mobile-first design for factory floor use",
              "Automated PDF generation and email delivery",
            ].map((benefit, i) => (
              <div key={i} className="flex gap-4 items-start">
                <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                <p className="text-lg text-slate-700">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Signup Options Section */}
      <div className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-slate-50 to-white border-t border-orange-200">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Join UNYX Quality Management System</h2>
            <p className="text-lg text-slate-600">Select your role to get started</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Auditor Signup */}
            <Link
              to="/signup/auditor"
              className="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-300 rounded-xl p-8 hover:shadow-xl hover:scale-105 transition-all duration-300 block"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
                <ArrowRight className="w-6 h-6 text-blue-600 group-hover:translate-x-1 transition-transform" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Auditor Sign Up</h3>
              <p className="text-slate-700 mb-4">Join as a quality auditor and start inspecting garments</p>
              <ul className="text-sm text-slate-700 space-y-2">
                <li>✓ Create & submit inspections</li>
                <li>✓ Access audit dashboard</li>
                <li>✓ Real-time session tracking</li>
                <li>✓ AI-powered summaries</li>
              </ul>
            </Link>

            {/* Buyer Signup */}
            <Link
              to="/signup/buyer"
              className="group bg-gradient-to-br from-purple-50 to-pink-100 border-2 border-purple-300 rounded-xl p-8 hover:shadow-xl hover:scale-105 transition-all duration-300 block"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <ArrowRight className="w-6 h-6 text-purple-600 group-hover:translate-x-1 transition-transform" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Buyer Sign Up</h3>
              <p className="text-slate-700 mb-4">Join as a buyer and monitor quality inspections</p>
              <ul className="text-sm text-slate-700 space-y-2">
                <li>✓ View inspection reports</li>
                <li>✓ Monitor shipment readiness</li>
                <li>✓ Track quality metrics</li>
                <li>✓ Admin approval required</li>
              </ul>
            </Link>
          </div>
        </div>
      </div>

      {/* Login/Signup Section */}
      <div
        id="login"
        className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-t border-orange-200"
        style={{
          backgroundImage: "url(https://cdn.builder.io/api/v1/image/assets%2F1c13ce3db0d645af9eee2782547067b4%2F9c32b98bff8a4ac8b2027fa96bcc67bc)",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center",
          backgroundSize: "cover"
        }}
      >
        <div className="max-w-md mx-auto">
          <div className="bg-white border border-white rounded-lg shadow-lg overflow-hidden">
            {/* Tabs */}
            <div className="flex border-b border-orange-300">
              <button
                onClick={() => setIsSignup(false)}
                className={`flex-1 py-3 px-4 font-semibold text-sm transition ${
                  !isSignup
                    ? "bg-blue-600 text-white"
                    : "bg-white text-slate-700 hover:bg-slate-50"
                }`}
              >
                Sign In
              </button>
              <button
                onClick={() => setIsSignup(true)}
                className={`flex-1 py-3 px-4 font-semibold text-sm transition ${
                  isSignup
                    ? "bg-blue-600 text-white"
                    : "bg-white text-slate-700 hover:bg-slate-50"
                }`}
              >
                Sign Up
              </button>
            </div>

            <div className="p-8">
              {!isSignup ? (
                /* Sign In Form */
                <form onSubmit={handleLogin} className="space-y-4">
                  <h2 className="text-2xl font-bold text-slate-900 mb-6">Sign In</h2>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="auditor@garment.com"
                      className="w-full px-4 py-2 bg-white border border-orange-300 rounded-lg text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Password
                    </label>
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-4 py-2 bg-white border border-orange-300 rounded-lg text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition"
                  >
                    Sign In
                  </button>
                </form>
              ) : (
                /* Sign Up Form */
                <form onSubmit={handleSignup} className="space-y-4">
                  <h2 className="text-2xl font-bold text-slate-900 mb-6">Create Account</h2>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={signupName}
                      onChange={(e) => setSignupName(e.target.value)}
                      placeholder="John Doe"
                      className="w-full px-4 py-2 bg-white border border-orange-300 rounded-lg text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      value={signupEmail}
                      onChange={(e) => setSignupEmail(e.target.value)}
                      placeholder="john@garment.com"
                      className="w-full px-4 py-2 bg-white border border-orange-300 rounded-lg text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Password
                    </label>
                    <input
                      type="password"
                      value={signupPassword}
                      onChange={(e) => setSignupPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-4 py-2 bg-white border border-orange-300 rounded-lg text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Role
                    </label>
                    <select
                      value={signupRole}
                      onChange={(e) => setSignupRole(e.target.value)}
                      className="w-full px-4 py-2 bg-white border border-orange-300 rounded-lg text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                    >
                      <option value="auditor">Auditor</option>
                      <option value="buyer">Buyer</option>
                    </select>
                  </div>
                  <button
                    type="submit"
                    className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition"
                  >
                    Create Account
                  </button>
                </form>
              )}
              <p className="text-center text-slate-600 mt-4 text-sm">
                Demo: any email & password works
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-blue-600 border-t border-slate-800 py-8 px-4">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <img
              src="https://unyxstudio.com/wp-content/uploads/2025/09/UNYX-2-e1757079195812.png"
              alt="UNYX Studio"
              className="h-8"
            />
          </div>
          <p className="text-center text-slate-400 text-sm">
            &copy; 2026 Quality Audit System by UNYX Studio. Professional
            Garment Inspection Made Simple.
          </p>
        </div>
      </footer>
    </div>
  );
}

function Dashboard({ onLogout }: { onLogout: () => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-orange-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <img
                src="https://unyxstudio.com/wp-content/uploads/2025/09/UNYX-3-e1757072083992.png"
                alt="UNYX Studio"
                className="h-10"
              />
              <div className="border-l border-orange-300 pl-3">
                <p className="text-sm text-slate-600">Quality Audit System</p>
              </div>
            </div>
            <UserProfile />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-32">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Dashboard</h1>
          <p className="text-slate-600">
            Welcome back! Manage your garment inspections and quality audits.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <Link
            to="/audit/new"
            className="group bg-gradient-to-br from-blue-600 via-blue-500 to-orange-500 text-white p-6 rounded-xl shadow-lg hover:shadow-2xl hover:scale-105 transition-all duration-300 block overflow-hidden relative"
          >
            <div className="absolute inset-0 bg-black/10 group-hover:bg-black/20 transition-all"></div>
            <div className="relative z-10">
              <CheckCircle2 className="w-10 h-10 mb-2 text-blue-100" />
              <h2 className="text-xl font-bold mb-2">Create New Audit</h2>
              <p className="text-blue-50 mb-3 text-xs">
                Start a new garment inspection
              </p>
              <div className="flex items-center gap-2 font-semibold text-sm">
                Start <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </Link>

          <Link
            to="/audits"
            className="group bg-white border-2 border-orange-300 hover:border-blue-600 p-6 rounded-xl shadow-md hover:shadow-xl hover:scale-105 transition-all duration-300 block"
          >
            <Zap className="w-10 h-10 mb-2 text-orange-600 group-hover:text-blue-600 transition-colors" />
            <h2 className="text-xl font-bold text-slate-900 mb-2">
              View Audits
            </h2>
            <p className="text-slate-600 mb-3 text-xs">
              Check inspections and reports
            </p>
            <div className="flex items-center gap-2 text-blue-600 font-semibold text-sm">
              View <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>

          <Link
            to="/analytics"
            className="group bg-white border-2 border-blue-300 hover:border-blue-600 p-6 rounded-xl shadow-md hover:shadow-xl hover:scale-105 transition-all duration-300 block"
          >
            <BarChart3 className="w-10 h-10 mb-2 text-blue-600 group-hover:scale-110 transition-transform" />
            <h2 className="text-xl font-bold text-slate-900 mb-2">
              Analytics
            </h2>
            <p className="text-slate-600 mb-3 text-xs">
              Quality metrics and trends
            </p>
            <div className="flex items-center gap-2 text-blue-600 font-semibold text-sm">
              View <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>

          <AIAssistantDashboardCard
            stats={{
              inspectionsAnalyzed: 12,
              averageQualityScore: 92,
              timeLastAnalysis: "2 hours ago",
            }}
          />
        </div>

        {/* Stats Overview */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Quick Stats</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-blue-100 text-sm font-medium mb-2">Total Audits</p>
                  <p className="text-3xl font-bold">24</p>
                </div>
                <CheckCircle2 className="w-12 h-12 text-blue-200/50" />
              </div>
            </div>
            <div className="bg-gradient-to-br from-green-500 to-green-600 text-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-green-100 text-sm font-medium mb-2">Pass Rate</p>
                  <p className="text-3xl font-bold">96%</p>
                </div>
                <CheckCircle2 className="w-12 h-12 text-green-200/50" />
              </div>
            </div>
            <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-orange-100 text-sm font-medium mb-2">Pending Review</p>
                  <p className="text-3xl font-bold">3</p>
                </div>
                <Lock className="w-12 h-12 text-orange-200/50" />
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
