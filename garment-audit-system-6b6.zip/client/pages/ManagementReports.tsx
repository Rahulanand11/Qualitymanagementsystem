import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Download, Calendar, Send, Settings } from "lucide-react";

interface Report {
  id: string;
  name: string;
  description: string;
  type: "summary" | "detailed" | "trend";
  icon: string;
}

const reports: Report[] = [
  {
    id: "1",
    name: "Quality Performance Summary",
    description:
      "Executive overview of quality metrics, pass rates, and defect trends",
    type: "summary",
    icon: "📊",
  },
  {
    id: "2",
    name: "Defect Analysis Report",
    description:
      "Detailed breakdown of defects by category, severity, and factory",
    type: "detailed",
    icon: "🔍",
  },
  {
    id: "3",
    name: "Factory Rankings",
    description: "Ranked performance comparison across all audited factories",
    type: "summary",
    icon: "🏆",
  },
  {
    id: "4",
    name: "Auditor Performance",
    description: "Individual auditor statistics and productivity metrics",
    type: "detailed",
    icon: "👤",
  },
  {
    id: "5",
    name: "Shipment Approval Trends",
    description:
      "Timeline analysis of shipment approvals, rejections, and pending reviews",
    type: "trend",
    icon: "📈",
  },
  {
    id: "6",
    name: "Geo-Location Verification Summary",
    description:
      "Auditor location compliance and geofencing validation results",
    type: "summary",
    icon: "🗺️",
  },
];

export default function ManagementReports() {
  const [selectedReports, setSelectedReports] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState("month");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [scheduleFrequency, setScheduleFrequency] = useState("weekly");

  const toggleReport = (reportId: string) => {
    setSelectedReports((prev) =>
      prev.includes(reportId)
        ? prev.filter((id) => id !== reportId)
        : [...prev, reportId]
    );
  };

  const handleGenerateReports = () => {
    alert(`Generating ${selectedReports.length} report(s) in PDF and Excel formats...`);
  };

  const handleScheduleEmail = () => {
    if (!recipientEmail) {
      alert("Please enter an email address");
      return;
    }
    alert(`Reports scheduled to be emailed to ${recipientEmail} ${scheduleFrequency}`);
  };

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-orange-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <Link
              to="/"
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">
              Management Reporting Module
            </h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Overview */}
        <div className="bg-gradient-to-r from-blue-600 to-orange-500 rounded-lg p-8 text-white mb-8">
          <h2 className="text-3xl font-bold mb-2">Automated Report Generation</h2>
          <p className="text-blue-100 max-w-2xl">
            Generate professional reports in PDF and Excel formats. Schedule
            automatic email delivery to stakeholders at your preferred frequency.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Report Selection */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg border border-orange-200 p-6 mb-8">
              <h2 className="text-xl font-bold text-slate-900 mb-6">
                Select Reports to Generate
              </h2>

              <div className="space-y-4">
                {reports.map((report) => (
                  <label
                    key={report.id}
                    className="flex items-start gap-4 p-4 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer transition"
                  >
                    <input
                      type="checkbox"
                      checked={selectedReports.includes(report.id)}
                      onChange={() => toggleReport(report.id)}
                      className="w-5 h-5 text-blue-600 rounded mt-1 cursor-pointer"
                    />
                    <div className="flex-1">
                      <div className="flex items-start gap-3">
                        <span className="text-2xl">{report.icon}</span>
                        <div>
                          <p className="font-semibold text-slate-900">
                            {report.name}
                          </p>
                          <p className="text-sm text-slate-600">
                            {report.description}
                          </p>
                          <div className="flex gap-2 mt-2">
                            <span className="inline-block px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded font-medium">
                              {report.type}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </label>
                ))}
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerateReports}
                disabled={selectedReports.length === 0}
                className="w-full mt-6 px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white rounded-lg font-semibold transition flex items-center justify-center gap-2"
              >
                <Download className="w-5 h-5" /> Generate {selectedReports.length}{" "}
                Report{selectedReports.length !== 1 ? "s" : ""}
              </button>

              <p className="text-xs text-slate-600 mt-3 text-center">
                Reports will be generated in both PDF and Excel formats
              </p>
            </div>

            {/* Date Range Selection */}
            <div className="bg-white rounded-lg border border-orange-200 p-6">
              <h2 className="text-lg font-bold text-slate-900 mb-4">
                Date Range
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { value: "week", label: "This Week" },
                  { value: "month", label: "This Month" },
                  { value: "quarter", label: "This Quarter" },
                  { value: "year", label: "This Year" },
                  { value: "custom", label: "Custom Range" },
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setDateRange(option.value)}
                    className={`px-4 py-2 rounded-lg font-medium transition ${
                      dateRange === option.value
                        ? "bg-blue-600 text-white"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>

              {dateRange === "custom" && (
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      From Date
                    </label>
                    <input
                      type="date"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      To Date
                    </label>
                    <input
                      type="date"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Schedule Delivery */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg border border-orange-200 p-6 sticky top-20">
              <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Send className="w-5 h-5" /> Schedule Email Delivery
              </h2>

              <div className="space-y-4">
                {/* Email Input */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Recipient Email
                  </label>
                  <input
                    type="email"
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    placeholder="manager@company.com"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Frequency Selection */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Frequency
                  </label>
                  <div className="space-y-2">
                    {[
                      { value: "daily", label: "Daily" },
                      { value: "weekly", label: "Weekly" },
                      { value: "biweekly", label: "Bi-Weekly" },
                      { value: "monthly", label: "Monthly" },
                    ].map((freq) => (
                      <label key={freq.value} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="frequency"
                          value={freq.value}
                          checked={scheduleFrequency === freq.value}
                          onChange={(e) => setScheduleFrequency(e.target.value)}
                          className="w-4 h-4 text-blue-600"
                        />
                        <span className="text-sm text-slate-700">{freq.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Multiple Recipients */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Add More Recipients
                  </label>
                  <button className="w-full px-3 py-2 border-2 border-dashed border-slate-300 rounded-lg text-slate-700 hover:border-blue-400 transition text-sm font-medium">
                    + Add Email
                  </button>
                </div>

                {/* Schedule Button */}
                <button
                  onClick={handleScheduleEmail}
                  className="w-full mt-6 px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition flex items-center justify-center gap-2"
                >
                  <Calendar className="w-4 h-4" /> Schedule Reports
                </button>

                <p className="text-xs text-slate-600 text-center">
                  Reports will be automatically generated and emailed on schedule
                </p>
              </div>

              {/* Recent Schedules */}
              <div className="mt-8 pt-6 border-t border-slate-200">
                <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                  <Settings className="w-4 h-4" /> Active Schedules
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="p-2 bg-green-50 border border-green-200 rounded">
                    <p className="font-medium text-green-900">
                      Quality Summary (Weekly)
                    </p>
                    <p className="text-xs text-green-700">
                      → director@company.com
                    </p>
                  </div>
                  <div className="p-2 bg-blue-50 border border-blue-200 rounded">
                    <p className="font-medium text-blue-900">
                      Factory Rankings (Monthly)
                    </p>
                    <p className="text-xs text-blue-700">
                      → manager@company.com
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Report Samples */}
        <div className="bg-white rounded-lg border border-orange-200 p-8 mt-8">
          <h2 className="text-xl font-bold text-slate-900 mb-6">
            Recently Generated Reports
          </h2>
          <div className="space-y-3">
            {[
              { name: "Quality Performance Summary - Jan 2024", date: "Jan 15, 2024", size: "2.4 MB" },
              { name: "Defect Analysis Report - Dec 2023", date: "Dec 28, 2023", size: "3.1 MB" },
              { name: "Factory Rankings Report - Dec 2023", date: "Dec 15, 2023", size: "1.8 MB" },
            ].map((report, idx) => (
              <div
                key={idx}
                className="flex justify-between items-center p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition"
              >
                <div>
                  <p className="font-medium text-slate-900">{report.name}</p>
                  <p className="text-xs text-slate-600">{report.date}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-slate-600">{report.size}</span>
                  <button className="px-3 py-1 bg-blue-100 text-blue-600 rounded hover:bg-blue-200 transition text-sm font-medium">
                    Download
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
