import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { UserProfile } from "@/components/UserProfile";
import { useAuth } from "@/contexts/AuthContext";
import { InspectionSummary } from "@/components/InspectionSummary";
import { AIInspectionSummaryDisplay } from "@/components/AIInspectionSummaryDisplay";
import { aiInspectionSummary, type AIInspectionSummary } from "@/services/AIInspectionSummary";
import { EmailService } from "@/services/EmailService";
import {
  ChevronDown,
  Upload,
  Camera,
  Plus,
  Trash2,
  Save,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  X,
  Info,
  MapPin,
  User,
} from "lucide-react";

interface DefectRecord {
  id: string;
  category: string;
  description: string;
  severity: "critical" | "major" | "minor";
  quantity: number;
  image?: string;
}

interface ImageUpload {
  id: string;
  type: string;
  file?: File;
  preview?: string;
}

interface CheckpointDefect {
  id: string;
  checkpointName: string;
  pcsChecked: number;
  defectsFound: number;
  piecesWithDefects: { pieceId: string; defectType: string }[];
  severity: "critical" | "major" | "minor";
  remarks: string;
}

interface FactoryLocation {
  name: string;
  latitude: number;
  longitude: number;
  radius: number; // in meters
}

const APPROVED_FACTORIES: FactoryLocation[] = [
  { name: "Factory A - Noida", latitude: 28.5355, longitude: 77.3910, radius: 500 },
  { name: "Factory B - Bangalore", latitude: 12.9716, longitude: 77.5946, radius: 500 },
  { name: "Factory C - Chennai", latitude: 13.0827, longitude: 80.2707, radius: 500 },
];

function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000; // Earth's radius in meters
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export default function AuditForm() {
  const navigate = useNavigate();
  const { sessionDuration } = useAuth();
  const [progress, setProgress] = useState(0);
  const [expandedSection, setExpandedSection] = useState("auditor");
  const [defects, setDefects] = useState<DefectRecord[]>([]);
  const [checkpointDefects, setCheckpointDefects] = useState<CheckpointDefect[]>([]);
  const [images, setImages] = useState<ImageUpload[]>([]);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [auditId, setAuditId] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState<string>("");
  const [closestFactory, setClosestFactory] = useState<FactoryLocation | null>(null);
  const [aiSummary, setAiSummary] = useState<AIInspectionSummary | null>(null);
  const [showAiSummary, setShowAiSummary] = useState(false);

  const calculateProgress = () => {
    const sections = 9; // Total sections
    let completedSections = 0;

    // Check auditor info
    if (formData.auditorName && formData.gpsLatitude) completedSections++;

    // Check general info (mandatory fields)
    if (
      formData.factoryName &&
      formData.supplierName &&
      formData.buyerName &&
      formData.poNumber &&
      formData.styleNumber &&
      formData.inspectionQuantity &&
      formData.shipmentDate
    )
      completedSections++;

    // Check inspection type
    if (formData.inspectionType) completedSections++;

    // Check if has checkpoint data
    const hasCheckpointData = Object.values(checkpoints).some((category: any) =>
      Object.values(category).some((item: any) => item.status !== null)
    );
    if (hasCheckpointData) completedSections++;

    // Check if has defects
    if (defects.length > 0) completedSections++;

    // Check images
    if (images.length > 0) completedSections++;

    // Check carton info (optional but count if filled)
    if (formData.cartonNumbers) completedSections++;

    // Check remarks
    if (formData.remarks) completedSections++;

    // Check approval (will be set on submission)
    completedSections++; // Always count

    return Math.round((completedSections / sections) * 100);
  };

  const [formData, setFormData] = useState({
    auditDate: "",
    inspectionTime: "",
    auditorName: "",
    auditorEmail: "",
    auditorPhone: "",
    gpsLatitude: "",
    gpsLongitude: "",
    auditorImageUrl: "",
    factoryName: "",
    supplierName: "",
    buyerName: "",
    styleNumber: "",
    poNumber: "",
    orderQuantity: "",
    inspectionQuantity: "",
    color: "",
    sizeRange: "",
    destination: "",
    productionLine: "",
    cartonNumbers: "",
    shipmentDate: "",
    inspectionType: "100",
    inspectionStage: "",
    remarks: "",
    measurementSheetUrl: "",
    // Time tracking
    loginTime: new Date().toLocaleTimeString(),
    inspectionStartTime: new Date().toLocaleTimeString(),
    inspectionEndTime: "",
    logoutTime: "",
    totalInspectionDuration: "",
  });

  const [checkpoints, setCheckpoints] = useState({
    visual: {
      shadeVariation: { status: null as string | null, pcsChecked: 0 },
      fabricDefects: { status: null as string | null, pcsChecked: 0 },
      stains: { status: null as string | null, pcsChecked: 0 },
      holes: { status: null as string | null, pcsChecked: 0 },
      oilMarks: { status: null as string | null, pcsChecked: 0 },
      colorConsistency: { status: null as string | null, pcsChecked: 0 },
      printingQuality: { status: null as string | null, pcsChecked: 0 },
      embroideryQuality: { status: null as string | null, pcsChecked: 0 },
      washingQuality: { status: null as string | null, pcsChecked: 0 },
    },
    measurement: {
      chest: { status: null as string | null, pcsChecked: 0 },
      waist: { status: null as string | null, pcsChecked: 0 },
      hip: { status: null as string | null, pcsChecked: 0 },
      length: { status: null as string | null, pcsChecked: 0 },
      sleeveLength: { status: null as string | null, pcsChecked: 0 },
      neckOpening: { status: null as string | null, pcsChecked: 0 },
      bottomOpening: { status: null as string | null, pcsChecked: 0 },
    },
    sewing: {
      seamQuality: { status: null as string | null, pcsChecked: 0 },
      spiCheck: { status: null as string | null, pcsChecked: 0 },
      openSeams: { status: null as string | null, pcsChecked: 0 },
      brokenStitches: { status: null as string | null, pcsChecked: 0 },
      unevenStitching: { status: null as string | null, pcsChecked: 0 },
      threadTrimming: { status: null as string | null, pcsChecked: 0 },
      barTackQuality: { status: null as string | null, pcsChecked: 0 },
    },
    label: {
      mainLabel: { status: null as string | null, pcsChecked: 0 },
      sizeLabel: { status: null as string | null, pcsChecked: 0 },
      careLabel: { status: null as string | null, pcsChecked: 0 },
      barcode: { status: null as string | null, pcsChecked: 0 },
      hangtag: { status: null as string | null, pcsChecked: 0 },
    },
    packing: {
      polybagQuality: { status: null as string | null, pcsChecked: 0 },
      cartonMarking: { status: null as string | null, pcsChecked: 0 },
      cartonLabel: { status: null as string | null, pcsChecked: 0 },
      assortmentAccuracy: { status: null as string | null, pcsChecked: 0 },
      quantityVerification: { status: null as string | null, pcsChecked: 0 },
    },
  });

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Update progress whenever form data changes
  useEffect(() => {
    setProgress(calculateProgress());
  }, [formData, checkpoints, defects, images]);

  // Generate AI summary when defects or form data changes
  useEffect(() => {
    if (defects.length > 0 || images.length > 0) {
      const summary = aiInspectionSummary.generateSummary({
        auditorName: formData.auditorName,
        factoryName: formData.factoryName,
        buyer: formData.buyerName,
        supplier: formData.supplierName,
        poNumber: formData.poNumber,
        styleNumber: formData.styleNumber,
        inspectionStage: formData.inspectionStage,
        inspectionType: (formData.inspectionType as "100" | "aql15" | "aql25") || "100",
        defects: defects.map((d) => ({
          category: d.category,
          severity: d.severity,
          description: d.description,
          quantity: d.quantity,
        })),
        images: images.map((img) => img.preview || ""),
        remarks: formData.remarks,
      });
      setAiSummary(summary);
    }
  }, [defects, images, formData.auditorName, formData.factoryName]);

  const handleGetGPSLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const latitude = position.coords.latitude;
          const longitude = position.coords.longitude;

          setFormData((prev) => ({
            ...prev,
            gpsLatitude: latitude.toFixed(6),
            gpsLongitude: longitude.toFixed(6),
          }));

          // Check if within any approved factory location
          let isWithinApprovedZone = false;
          let nearest: FactoryLocation | null = null;
          let minDistance = Infinity;

          APPROVED_FACTORIES.forEach((factory) => {
            const distance = calculateDistance(
              latitude,
              longitude,
              factory.latitude,
              factory.longitude
            );

            if (distance < minDistance) {
              minDistance = distance;
              nearest = factory;
            }

            if (distance <= factory.radius) {
              isWithinApprovedZone = true;
            }
          });

          setClosestFactory(nearest);

          if (isWithinApprovedZone) {
            setVerificationStatus("Verified");
            setIsVerified(true);
          } else {
            setVerificationStatus(
              `Outside Approved Location (Closest: ${nearest?.name} - ${Math.round(minDistance)}m away)`
            );
            setIsVerified(false);
          }
        },
        (error) => {
          setVerificationStatus(`Error: ${error.message}`);
          setIsVerified(false);
        }
      );
    } else {
      setVerificationStatus("Geolocation not supported by this device");
      setIsVerified(false);
    }
  };

  const handleCheckpointChange = (
    section: string,
    checkpoint: string,
    field: "status" | "pcsChecked",
    value: string | number | null
  ) => {
    setCheckpoints((prev) => ({
      ...prev,
      [section]: {
        ...prev[section as keyof typeof checkpoints],
        [checkpoint]: {
          ...prev[section as keyof typeof checkpoints][checkpoint as any],
          [field]: value,
        },
      },
    }));
  };

  const addCheckpointDefect = (checkpointName: string) => {
    setCheckpointDefects([
      ...checkpointDefects,
      {
        id: Date.now().toString(),
        checkpointName,
        pcsChecked: 0,
        defectsFound: 0,
        piecesWithDefects: [],
        severity: "major",
        remarks: "",
      },
    ]);
  };

  const updateCheckpointDefect = (id: string, field: string, value: any) => {
    setCheckpointDefects(
      checkpointDefects.map((d) => (d.id === id ? { ...d, [field]: value } : d))
    );
  };

  const removeCheckpointDefect = (id: string) => {
    setCheckpointDefects(checkpointDefects.filter((d) => d.id !== id));
  };

  const addPieceToDefect = (defectId: string) => {
    setCheckpointDefects(
      checkpointDefects.map((d) => {
        if (d.id === defectId) {
          return {
            ...d,
            piecesWithDefects: [
              ...d.piecesWithDefects,
              { pieceId: `P${d.piecesWithDefects.length + 1}`, defectType: "" },
            ],
          };
        }
        return d;
      })
    );
  };

  const updatePieceDefect = (
    defectId: string,
    pieceIndex: number,
    field: "pieceId" | "defectType",
    value: string
  ) => {
    setCheckpointDefects(
      checkpointDefects.map((d) => {
        if (d.id === defectId) {
          const updatedPieces = [...d.piecesWithDefects];
          updatedPieces[pieceIndex] = {
            ...updatedPieces[pieceIndex],
            [field]: value,
          };
          return {
            ...d,
            piecesWithDefects: updatedPieces,
          };
        }
        return d;
      })
    );
  };

  const removePieceDefect = (defectId: string, pieceIndex: number) => {
    setCheckpointDefects(
      checkpointDefects.map((d) => {
        if (d.id === defectId) {
          return {
            ...d,
            piecesWithDefects: d.piecesWithDefects.filter(
              (_, i) => i !== pieceIndex
            ),
          };
        }
        return d;
      })
    );
  };

  const addDefect = () => {
    setDefects([
      ...defects,
      {
        id: Date.now().toString(),
        category: "",
        description: "",
        severity: "major",
        quantity: 1,
      },
    ]);
  };

  const removeDefect = (id: string) => {
    setDefects(defects.filter((d) => d.id !== id));
  };

  const updateDefect = (id: string, field: string, value: any) => {
    setDefects(
      defects.map((d) => (d.id === id ? { ...d, [field]: value } : d))
    );
  };

  const addImageUpload = (type: string) => {
    setImages([...images, { id: Date.now().toString(), type }]);
  };

  const removeImage = (id: string) => {
    setImages(images.filter((img) => img.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate mandatory fields
    const mandatoryFields = [
      { key: "auditorName", label: "Auditor Name" },
      { key: "factoryName", label: "Factory Name" },
      { key: "buyerName", label: "Buyer Name" },
      { key: "supplierName", label: "Supplier Name" },
      { key: "poNumber", label: "PO Number" },
      { key: "styleNumber", label: "Style Number" },
      { key: "inspectionQuantity", label: "Inspection Quantity" },
      { key: "shipmentDate", label: "Shipment Date" },
    ];

    const missingFields = mandatoryFields.filter(
      field => !formData[field.key as keyof typeof formData]
    );

    if (missingFields.length > 0) {
      alert(`Please fill in all mandatory fields:\n\n${missingFields.map(f => `• ${f.label}`).join("\n")}`);
      return;
    }

    // Record inspection end time and calculate duration
    const startTime = new Date(formData.inspectionStartTime);
    const endTime = new Date();
    const durationMs = endTime.getTime() - startTime.getTime();
    const durationMinutes = Math.floor(durationMs / 60000);
    const durationHours = Math.floor(durationMinutes / 60);
    const remainingMinutes = durationMinutes % 60;

    // Generate audit ID
    const newAuditId = `AUD-${Date.now()}`;

    // Prepare complete audit record with session duration
    const auditRecord = {
      id: newAuditId,
      ...formData,
      inspectionEndTime: endTime.toLocaleTimeString(),
      totalInspectionDuration: `${durationHours}h ${remainingMinutes}m`,
      sessionDuration: sessionDuration, // Add session duration from auth context
      defects: defects,
      images: images,
      aiSummary: aiSummary,
      submittedAt: new Date().toISOString(),
    };

    // Store in localStorage
    const existingAudits = localStorage.getItem("audits");
    const audits = existingAudits ? JSON.parse(existingAudits) : [];
    audits.push(auditRecord);
    localStorage.setItem("audits", JSON.stringify(audits));

    // Send email notification to management
    const managementEmails = EmailService.getManagementEmails();
    EmailService.sendNotificationEmail({
      id: newAuditId,
      result: auditRecord.result,
      factoryName: formData.factoryName,
      buyerName: formData.buyerName,
      supplierName: formData.supplierName,
      poNumber: formData.poNumber,
      styleNumber: formData.styleNumber,
      styleName: formData.styleName,
      inspectionStage: formData.inspectionStage,
      inspectionDate: formData.auditDate,
      auditorName: user?.fullName || "Unknown Auditor",
      qualityScore: auditRecord.qualityScore || 0,
      totalDefects: defects.length,
      shipmentStatus: auditRecord.result === "pass" ? "ready" : auditRecord.result === "fail" ? "hold" : "requires_action",
    }, managementEmails).catch(err => console.error("Email notification failed:", err));

    setAuditId(newAuditId);
    setFormData(prev => ({
      ...prev,
      inspectionEndTime: endTime.toLocaleTimeString(),
      totalInspectionDuration: `${durationHours}h ${remainingMinutes}m`,
    }));

    setShowSuccessModal(true);
    setTimeout(() => {
      setShowSuccessModal(false);
      navigate(`/audit/report/${newAuditId}`);
    }, 3000);
  };

  const sections = [
    { id: "auditor", title: "Auditor Information & Verification" },
    { id: "general", title: "General Information" },
    { id: "inspection", title: "Inspection Type" },
    { id: "checkpoints", title: "Quality Checkpoints" },
    { id: "defects", title: "Defect Recording" },
    { id: "images", title: "Image Upload" },
    { id: "carton", title: "Carton Inspection" },
    { id: "remarks", title: "Remarks & Summary" },
    { id: "approval", title: "Digital Approval" },
  ];

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-3">
              <img
                src="https://unyxstudio.com/wp-content/uploads/2025/09/UNYX-3-e1757072083992.png"
                alt="UNYX Studio"
                className="h-10"
              />
              <div className="border-l border-slate-300 pl-3">
                <p className="text-sm text-slate-600">Quality Audit System</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <UserProfile />
              <Link
                to="/"
                className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
              >
                <ArrowLeft className="w-5 h-5" />
                Back
              </Link>
            </div>
          </div>
          {/* Progress Bar */}
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-blue-600 to-orange-500 h-2 rounded-full transition-all"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          <p className="text-sm text-slate-600 mt-2">{progress}% Complete</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form onSubmit={handleSubmit} className={`space-y-6 ${!isVerified && verificationStatus ? "opacity-50 pointer-events-none" : ""}`}>
          {/* Section: Auditor Information & Verification */}
          <Section
            id="auditor"
            title="Auditor Information & Verification"
            expanded={expandedSection === "auditor"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "auditor" ? "" : "auditor"
              )
            }
          >
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
                <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-blue-700">
                  Capture auditor identity and location for verification and traceability.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Auditor Photo */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-3">
                    <User className="w-4 h-4 inline mr-2" />
                    Auditor Photo
                  </label>
                  <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-blue-400 transition cursor-pointer bg-slate-50">
                    <Camera className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-slate-700">Capture Selfie</p>
                    <p className="text-xs text-slate-500 mt-1">or upload from device</p>
                  </div>
                </div>

                {/* GPS Location */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-3">
                    <MapPin className="w-4 h-4 inline mr-2" />
                    GPS Location Verification
                  </label>
                  <button
                    type="button"
                    onClick={handleGetGPSLocation}
                    className="w-full border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-blue-400 transition bg-slate-50"
                  >
                    <MapPin className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-slate-700">Get GPS Location</p>
                    <p className="text-xs text-slate-500 mt-1">Click to capture coordinates & verify</p>
                  </button>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Auditor Name
                  </label>
                  <input
                    type="text"
                    name="auditorName"
                    value={formData.auditorName}
                    onChange={handleInputChange}
                    placeholder="Full name"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    name="auditorEmail"
                    value={formData.auditorEmail}
                    onChange={handleInputChange}
                    placeholder="auditor@company.com"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Phone
                  </label>
                  <input
                    type="tel"
                    name="auditorPhone"
                    value={formData.auditorPhone}
                    onChange={handleInputChange}
                    placeholder="+91 98765-43210"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* GPS Coordinates */}
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <p className="text-sm font-medium text-slate-700 mb-3">
                  GPS Coordinates (Captured Automatically)
                </p>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Latitude
                    </label>
                    <input
                      type="text"
                      name="gpsLatitude"
                      value={formData.gpsLatitude}
                      readOnly
                      placeholder="Click 'Get GPS Location' button above"
                      className="w-full px-3 py-2 border border-orange-300 rounded-lg bg-white text-slate-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Longitude
                    </label>
                    <input
                      type="text"
                      name="gpsLongitude"
                      value={formData.gpsLongitude}
                      readOnly
                      placeholder="Click 'Get GPS Location' button above"
                      className="w-full px-3 py-2 border border-orange-300 rounded-lg bg-white text-slate-600"
                    />
                  </div>
                </div>
              </div>

              {/* Verification Status */}
              {verificationStatus && (
                <div
                  className={`rounded-lg p-4 ${
                    isVerified
                      ? "bg-green-50 border border-green-200"
                      : "bg-red-50 border border-red-200"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <CheckCircle2
                      className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                        isVerified ? "text-green-600" : "text-red-600"
                      }`}
                    />
                    <div>
                      <p
                        className={`font-semibold ${
                          isVerified ? "text-green-900" : "text-red-900"
                        }`}
                      >
                        {isVerified ? "✓ Verification Successful" : "✗ Verification Failed"}
                      </p>
                      <p
                        className={`text-sm mt-1 ${
                          isVerified ? "text-green-800" : "text-red-800"
                        }`}
                      >
                        {verificationStatus}
                      </p>
                      {closestFactory && (
                        <p className="text-xs text-slate-600 mt-2">
                          Closest Factory: {closestFactory.name}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Embedded Map Preview */}
              <div className="border border-slate-300 rounded-lg overflow-hidden h-64 bg-slate-100 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-slate-400 mx-auto mb-2" />
                  <p className="text-slate-600 font-medium">Map Preview</p>
                  {formData.gpsLatitude && formData.gpsLongitude ? (
                    <p className="text-xs text-slate-500 mt-1">
                      Location: {formData.gpsLatitude}, {formData.gpsLongitude}
                    </p>
                  ) : (
                    <p className="text-xs text-slate-500 mt-1">Click "Get GPS Location" button to capture</p>
                  )}
                </div>
              </div>

              {/* Verification Block Warning */}
              {!isVerified && verificationStatus && (
                <div className="bg-orange-50 border border-orange-300 rounded-lg p-4">
                  <p className="text-sm text-orange-900 font-medium">
                    ⚠️ Audit Form is Locked
                  </p>
                  <p className="text-sm text-orange-800 mt-1">
                    Complete auditor verification above before proceeding with the inspection.
                  </p>
                </div>
              )}
            </div>
          </Section>

          {/* Section: Style Image Upload */}
          <Section
            id="style"
            title="Style Reference Images"
            expanded={expandedSection === "style"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "style" ? "" : "style"
              )
            }
          >
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
                <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-blue-700">
                  Upload style reference images for auditors to compare with actual garments during inspection.
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                {["Front View", "Back View", "Side View"].map((type) => (
                  <div key={type} className="border border-slate-300 rounded-lg p-4">
                    <h4 className="font-medium text-slate-900 mb-3">{type}</h4>
                    <div className="flex gap-2 flex-col">
                      <button
                        type="button"
                        className="flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition text-sm"
                      >
                        <Upload className="w-4 h-4" /> Upload
                      </button>
                      <button
                        type="button"
                        className="flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition text-sm"
                      >
                        <Camera className="w-4 h-4" /> Capture
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="border border-slate-300 rounded-lg p-4">
                  <h4 className="font-medium text-slate-900 mb-3">Technical Sketch</h4>
                  <button
                    type="button"
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition"
                  >
                    <Upload className="w-4 h-4" /> Upload PDF
                  </button>
                </div>

                <div className="border border-slate-300 rounded-lg p-4">
                  <h4 className="font-medium text-slate-900 mb-3">Approved Sample Images</h4>
                  <button
                    type="button"
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition"
                  >
                    <Upload className="w-4 h-4" /> Multiple Upload
                  </button>
                </div>
              </div>

              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <p className="text-sm text-orange-800">
                  <strong>Comparison Feature:</strong> Auditors can use side-by-side comparison mode to compare approved style images with actual production garments during inspection.
                </p>
              </div>
            </div>
          </Section>

          {/* Section: General Information */}
          <Section
            id="general"
            title="General Information"
            expanded={expandedSection === "general"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "general" ? "" : "general"
              )
            }
          >
            <div className="grid md:grid-cols-2 gap-4">
              {[
                { label: "Audit Date", name: "auditDate", type: "date", mandatory: false },
                { label: "Inspection Time", name: "inspectionTime", type: "time", mandatory: false },
                { label: "Auditor Name", name: "auditorName", type: "text", mandatory: true },
                { label: "Factory Name", name: "factoryName", type: "text", mandatory: true },
                { label: "Supplier Name", name: "supplierName", type: "text", mandatory: true },
                { label: "Buyer Name", name: "buyerName", type: "text", mandatory: true },
                { label: "Style Number", name: "styleNumber", type: "text", mandatory: true },
                { label: "PO Number", name: "poNumber", type: "text", mandatory: true },
                { label: "Order Quantity", name: "orderQuantity", type: "number", mandatory: false },
                {
                  label: "Inspection Quantity",
                  name: "inspectionQuantity",
                  type: "number",
                  mandatory: true,
                },
                { label: "Color", name: "color", type: "text", mandatory: false },
                { label: "Size Range", name: "sizeRange", type: "text", mandatory: false },
                { label: "Country of Destination", name: "destination", type: "text", mandatory: false },
                { label: "Production Line", name: "productionLine", type: "text", mandatory: false },
                { label: "Carton Numbers", name: "cartonNumbers", type: "text", mandatory: false },
                { label: "Shipment Date", name: "shipmentDate", type: "date", mandatory: true },
              ].map((field: any) => {
                const isEmpty = !formData[field.name as keyof typeof formData];
                return (
                  <div key={field.name}>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      {field.label}
                      {field.mandatory && <span className="text-red-600 ml-1">*</span>}
                    </label>
                    <input
                      type={field.type}
                      name={field.name}
                      value={formData[field.name as keyof typeof formData]}
                      onChange={handleInputChange}
                      className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        field.mandatory && isEmpty ? "border-red-500 bg-red-50" : "border-slate-300"
                      }`}
                      required={field.mandatory}
                    />
                  </div>
                );
              })}
            </div>
          </Section>

          {/* Section: Inspection Type */}
          <Section
            id="inspection"
            title="Inspection Type Selection"
            expanded={expandedSection === "inspection"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "inspection" ? "" : "inspection"
              )
            }
          >
            <div className="space-y-3">
              {[
                { value: "100", label: "100% Inspection" },
                { value: "aql15", label: "AQL 1.5" },
                { value: "aql25", label: "AQL 2.5" },
              ].map((option) => (
                <label key={option.value} className="flex items-center gap-3 p-3 border border-slate-300 rounded-lg hover:bg-orange-50 cursor-pointer">
                  <input
                    type="radio"
                    name="inspectionType"
                    value={option.value}
                    checked={formData.inspectionType === option.value}
                    onChange={handleInputChange}
                    className="w-4 h-4 text-blue-600"
                  />
                  <span className="text-slate-700 font-medium">{option.label}</span>
                </label>
              ))}
            </div>
          </Section>

          {/* Section: Inspection Stage */}
          <Section
            id="stage"
            title="Inspection Stage Selection"
            expanded={expandedSection === "stage"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "stage" ? "" : "stage"
              )
            }
          >
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">
                  Select Inspection Stage <span className="text-red-600">*</span>
                </label>
                <select
                  name="inspectionStage"
                  value={formData.inspectionStage}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    !formData.inspectionStage ? "border-red-500 bg-red-50" : "border-slate-300"
                  }`}
                  required
                >
                  <option value="">-- Choose Inspection Stage --</option>
                  <option value="inline">Inline Inspection</option>
                  <option value="midline">Midline Inspection</option>
                  <option value="final">Final Inspection</option>
                  <option value="pre-production">Pre-Production Inspection</option>
                  <option value="during-production">During Production Inspection</option>
                  <option value="pre-shipment">Pre-Shipment Inspection</option>
                  <option value="loading">Loading Inspection</option>
                </select>
                <p className="text-xs text-slate-500 mt-2">Choose the stage at which this inspection is being conducted.</p>
              </div>
            </div>
          </Section>

          {/* Section: Quality Checkpoints with Per-Piece Defect Tracking */}
          <Section
            id="checkpoints"
            title="Quality Checkpoints - Per Piece Defect Tracking"
            expanded={expandedSection === "checkpoints"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "checkpoints" ? "" : "checkpoints"
              )
            }
          >
            <div className="space-y-8">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
                <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-blue-700">
                  For each checkpoint, record the number of pieces checked and details of individual pieces with defects.
                </p>
              </div>

              <CheckpointGroup
                title="Visual Inspection"
                items={[
                  "shadeVariation",
                  "fabricDefects",
                  "stains",
                  "holes",
                  "oilMarks",
                  "colorConsistency",
                  "printingQuality",
                  "embroideryQuality",
                  "washingQuality",
                ]}
                values={checkpoints.visual}
                onChange={handleCheckpointChange}
                labels={{
                  shadeVariation: "Shade Variation",
                  fabricDefects: "Fabric Defects",
                  stains: "Stains",
                  holes: "Holes",
                  oilMarks: "Oil Marks",
                  colorConsistency: "Color Consistency",
                  printingQuality: "Printing Quality",
                  embroideryQuality: "Embroidery Quality",
                  washingQuality: "Washing Quality",
                }}
              />

              {/* Measurement Inspection - Sheet Upload */}
              <div>
                <h4 className="font-medium text-slate-900 mb-3">Measurement Inspection</h4>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <p className="text-sm text-blue-700">
                    Upload measurement sheets or capture images. No per-piece entry required.
                  </p>
                </div>
                <div className="space-y-4">
                  <div className="border border-slate-300 rounded-lg p-4">
                    <h5 className="text-sm font-medium text-slate-700 mb-3">Measurement Sheet</h5>
                    <div className="flex gap-3">
                      <button
                        type="button"
                        className="flex items-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition"
                      >
                        <Upload className="w-5 h-5" /> Upload Sheet
                      </button>
                      <button
                        type="button"
                        className="flex items-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition"
                      >
                        <Camera className="w-5 h-5" /> Capture Image
                      </button>
                    </div>
                    <p className="text-xs text-slate-500 mt-2">
                      Supported: PDF, Excel, JPG, PNG
                    </p>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        Overall Status
                      </label>
                      <select className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option>Pass</option>
                        <option>Fail</option>
                        <option>Not Applicable</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        Pcs Checked
                      </label>
                      <input
                        type="number"
                        min="0"
                        placeholder="0"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <CheckpointGroup
                title="Sewing Inspection"
                items={[
                  "seamQuality",
                  "spiCheck",
                  "openSeams",
                  "brokenStitches",
                  "unevenStitching",
                  "threadTrimming",
                  "barTackQuality",
                ]}
                values={checkpoints.sewing}
                onChange={handleCheckpointChange}
                labels={{
                  seamQuality: "Seam Quality",
                  spiCheck: "SPI Check",
                  openSeams: "Open Seams",
                  brokenStitches: "Broken Stitches",
                  unevenStitching: "Uneven Stitching",
                  threadTrimming: "Thread Trimming",
                  barTackQuality: "Bar Tack Quality",
                }}
              />

              <CheckpointGroup
                title="Label Inspection"
                items={["mainLabel", "sizeLabel", "careLabel", "barcode", "hangtag"]}
                values={checkpoints.label}
                onChange={handleCheckpointChange}
                labels={{
                  mainLabel: "Main Label",
                  sizeLabel: "Size Label",
                  careLabel: "Care Label",
                  barcode: "Barcode",
                  hangtag: "Hangtag",
                }}
              />

              <CheckpointGroup
                title="Packing Inspection"
                items={[
                  "polybagQuality",
                  "cartonMarking",
                  "cartonLabel",
                  "assortmentAccuracy",
                  "quantityVerification",
                ]}
                values={checkpoints.packing}
                onChange={handleCheckpointChange}
                labels={{
                  polybagQuality: "Polybag Quality",
                  cartonMarking: "Carton Marking",
                  cartonLabel: "Carton Label",
                  assortmentAccuracy: "Assortment Accuracy",
                  quantityVerification: "Quantity Verification",
                }}
              />

              {/* Checkpoint Defect Details */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">
                  Checkpoint Defect Details
                </h3>
                {checkpointDefects.length === 0 ? (
                  <p className="text-slate-600 py-4">No checkpoint defects recorded</p>
                ) : (
                  <div className="space-y-6">
                    {checkpointDefects.map((defect) => (
                      <div
                        key={defect.id}
                        className="border border-slate-300 rounded-lg p-4 bg-slate-50"
                      >
                        <div className="flex justify-between items-start mb-4">
                          <h4 className="font-semibold text-slate-900">
                            {defect.checkpointName}
                          </h4>
                          <button
                            type="button"
                            onClick={() => removeCheckpointDefect(defect.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="grid md:grid-cols-3 gap-4 mb-4">
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">
                              Pcs Checked
                            </label>
                            <input
                              type="number"
                              min="0"
                              value={defect.pcsChecked}
                              onChange={(e) =>
                                updateCheckpointDefect(
                                  defect.id,
                                  "pcsChecked",
                                  parseInt(e.target.value)
                                )
                              }
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">
                              Defects Found
                            </label>
                            <input
                              type="number"
                              min="0"
                              value={defect.defectsFound}
                              onChange={(e) =>
                                updateCheckpointDefect(
                                  defect.id,
                                  "defectsFound",
                                  parseInt(e.target.value)
                                )
                              }
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">
                              Severity
                            </label>
                            <select
                              value={defect.severity}
                              onChange={(e) =>
                                updateCheckpointDefect(
                                  defect.id,
                                  "severity",
                                  e.target.value
                                )
                              }
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                            >
                              <option value="critical">Critical</option>
                              <option value="major">Major</option>
                              <option value="minor">Minor</option>
                            </select>
                          </div>
                        </div>

                        {/* Individual Pieces with Defects */}
                        <div className="mb-4">
                          <h5 className="text-sm font-medium text-slate-700 mb-2">
                            Pieces with Defects
                          </h5>
                          {defect.piecesWithDefects.length === 0 ? (
                            <p className="text-xs text-slate-500">No pieces recorded</p>
                          ) : (
                            <div className="space-y-2">
                              {defect.piecesWithDefects.map((piece, idx) => (
                                <div key={idx} className="flex gap-2 items-start">
                                  <input
                                    type="text"
                                    value={piece.pieceId}
                                    onChange={(e) =>
                                      updatePieceDefect(
                                        defect.id,
                                        idx,
                                        "pieceId",
                                        e.target.value
                                      )
                                    }
                                    placeholder="Piece ID"
                                    className="flex-1 px-2 py-1 border border-slate-300 rounded text-sm"
                                  />
                                  <input
                                    type="text"
                                    value={piece.defectType}
                                    onChange={(e) =>
                                      updatePieceDefect(
                                        defect.id,
                                        idx,
                                        "defectType",
                                        e.target.value
                                      )
                                    }
                                    placeholder="Defect Type"
                                    className="flex-1 px-2 py-1 border border-slate-300 rounded text-sm"
                                  />
                                  <button
                                    type="button"
                                    onClick={() =>
                                      removePieceDefect(defect.id, idx)
                                    }
                                    className="text-red-600 hover:text-red-700"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                          <button
                            type="button"
                            onClick={() => addPieceToDefect(defect.id)}
                            className="mt-2 text-sm text-blue-600 hover:text-blue-700 font-medium"
                          >
                            + Add Piece
                          </button>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">
                            Remarks
                          </label>
                          <input
                            type="text"
                            value={defect.remarks}
                            onChange={(e) =>
                              updateCheckpointDefect(
                                defect.id,
                                "remarks",
                                e.target.value
                              )
                            }
                            placeholder="Additional remarks..."
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </Section>

          {/* Section: Defect Recording */}
          <Section
            id="defects"
            title="Defect Recording"
            expanded={expandedSection === "defects"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "defects" ? "" : "defects"
              )
            }
          >
            <div className="space-y-4">
              {defects.length === 0 ? (
                <p className="text-slate-600 py-6 text-center">
                  No defects recorded yet
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-slate-200">
                        <th className="border border-slate-300 px-4 py-2 text-left">Category</th>
                        <th className="border border-slate-300 px-4 py-2 text-left">Description</th>
                        <th className="border border-slate-300 px-4 py-2 text-left">Severity</th>
                        <th className="border border-slate-300 px-4 py-2 text-center">Qty</th>
                        <th className="border border-slate-300 px-4 py-2 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {defects.map((defect) => (
                        <tr key={defect.id} className="hover:bg-slate-50">
                          <td className="border border-slate-300 px-4 py-2">
                            <input
                              type="text"
                              value={defect.category}
                              onChange={(e) =>
                                updateDefect(defect.id, "category", e.target.value)
                              }
                              placeholder="e.g., Stain"
                              className="w-full px-2 py-1 border border-slate-300 rounded"
                            />
                          </td>
                          <td className="border border-slate-300 px-4 py-2">
                            <input
                              type="text"
                              value={defect.description}
                              onChange={(e) =>
                                updateDefect(
                                  defect.id,
                                  "description",
                                  e.target.value
                                )
                              }
                              placeholder="Description"
                              className="w-full px-2 py-1 border border-slate-300 rounded"
                            />
                          </td>
                          <td className="border border-slate-300 px-4 py-2">
                            <select
                              value={defect.severity}
                              onChange={(e) =>
                                updateDefect(
                                  defect.id,
                                  "severity",
                                  e.target.value
                                )
                              }
                              className="w-full px-2 py-1 border border-slate-300 rounded"
                            >
                              <option value="critical">Critical</option>
                              <option value="major">Major</option>
                              <option value="minor">Minor</option>
                            </select>
                          </td>
                          <td className="border border-slate-300 px-4 py-2 text-center">
                            <input
                              type="number"
                              min="1"
                              value={defect.quantity}
                              onChange={(e) =>
                                updateDefect(
                                  defect.id,
                                  "quantity",
                                  parseInt(e.target.value)
                                )
                              }
                              className="w-12 px-2 py-1 border border-slate-300 rounded text-center"
                            />
                          </td>
                          <td className="border border-slate-300 px-4 py-2 text-center">
                            <button
                              type="button"
                              onClick={() => removeDefect(defect.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <button
                type="button"
                onClick={addDefect}
                className="flex items-center gap-2 px-4 py-2 bg-slate-200 hover:bg-slate-300 rounded-lg text-slate-700 font-medium transition"
              >
                <Plus className="w-4 h-4" /> Add Defect
              </button>
            </div>
          </Section>

          {/* Section: Image Upload */}
          <Section
            id="images"
            title="Image Upload"
            expanded={expandedSection === "images"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "images" ? "" : "images"
              )
            }
          >
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
                <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-blue-700">
                  Upload up to 100 images per section. Images will be automatically compressed while maintaining quality.
                </p>
              </div>
              <p className="text-sm text-slate-600">
                Total images uploaded: <strong>{images.length}/100</strong>
              </p>

              {[
                { type: "Measurement", desc: "Measurement sheet or ruler reference images" },
                { type: "Sewing", desc: "Stitch quality, seam alignment images" },
                { type: "Defects", desc: "Close-up images of identified defects" },
                { type: "General", desc: "General garment views and details" },
              ].map((category) => (
                <div key={category.type} className="border border-slate-300 rounded-lg p-4">
                  <div className="mb-4">
                    <h4 className="font-medium text-slate-900">{category.type} Images</h4>
                    <p className="text-xs text-slate-600 mt-1">{category.desc}</p>
                  </div>

                  <div className="flex gap-3 mb-4">
                    <button
                      type="button"
                      onClick={() => document.getElementById(`upload-${category.type}`).click()}
                      className="flex items-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition flex-1"
                    >
                      <Upload className="w-5 h-5" /> Upload from Device
                    </button>
                    <input
                      id={`upload-${category.type}`}
                      type="file"
                      multiple
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const files = Array.from(e.target.files || []);
                        files.forEach(file => {
                          if (images.length < 100) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                              setImages(prev => [...prev, {
                                id: `img-${Date.now()}-${Math.random()}`,
                                type: category.type,
                                file: file,
                                preview: event.target?.result as string
                              }]);
                            };
                            reader.readAsDataURL(file);
                          }
                        });
                      }}
                    />
                    <button
                      type="button"
                      className="flex items-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition flex-1"
                    >
                      <Camera className="w-5 h-5" /> Capture Image
                    </button>
                  </div>

                  {/* Image Thumbnails */}
                  {images.filter(img => img.type === category.type).length > 0 && (
                    <div className="mt-4">
                      <p className="text-xs font-medium text-slate-700 mb-2">
                        Uploaded: {images.filter(img => img.type === category.type).length}
                      </p>
                      <div className="grid grid-cols-4 gap-2">
                        {images.filter(img => img.type === category.type).map((image) => (
                          <div key={image.id} className="relative group">
                            <img
                              src={image.preview}
                              alt={image.type}
                              className="w-full h-20 object-cover rounded border border-slate-300"
                            />
                            <button
                              type="button"
                              onClick={() => setImages(prev => prev.filter(img => img.id !== image.id))}
                              className="absolute top-1 right-1 bg-red-600 text-white p-1 rounded opacity-0 group-hover:opacity-100 transition"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Section>

          {/* Section: Carton Inspection */}
          <Section
            id="carton"
            title="Carton Inspection"
            expanded={expandedSection === "carton"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "carton" ? "" : "carton"
              )
            }
          >
            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Number of Cartons Checked
                </label>
                <input
                  type="number"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Carton Condition Status
                </label>
                <select className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option>Good</option>
                  <option>Fair</option>
                  <option>Damaged</option>
                </select>
              </div>
            </div>

            <div className="space-y-4">
              {["Carton Front", "Carton Side", "Carton Label", "Carton Stacking"].map(
                (type) => (
                  <div key={type} className="border border-slate-300 rounded-lg p-4">
                    <h4 className="font-medium text-slate-900 mb-3">{type} Image</h4>
                    <div className="flex gap-3">
                      <button
                        type="button"
                        className="flex items-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition"
                      >
                        <Upload className="w-5 h-5" /> Upload
                      </button>
                      <button
                        type="button"
                        className="flex items-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg text-slate-700 transition"
                      >
                        <Camera className="w-5 h-5" /> Capture
                      </button>
                    </div>
                  </div>
                )
              )}
            </div>
          </Section>

          {/* Section: Remarks */}
          <Section
            id="remarks"
            title="Remarks & Summary"
            expanded={expandedSection === "remarks"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "remarks" ? "" : "remarks"
              )
            }
          >
            <div className="space-y-6">
              {/* AI-Powered Inspection Summary */}
              {aiSummary && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                      <span className="bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">
                        ✨ AI Analysis
                      </span>
                    </h3>
                    <button
                      onClick={() => setShowAiSummary(!showAiSummary)}
                      className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                    >
                      {showAiSummary ? "Hide" : "Show"} Details
                    </button>
                  </div>
                  {showAiSummary && (
                    <AIInspectionSummaryDisplay
                      summary={aiSummary}
                      onExport={(format) => {
                        if (format === "pdf") {
                          alert("PDF export will be generated with the final report");
                        } else {
                          const json = JSON.stringify(aiSummary, null, 2);
                          const blob = new Blob([json], { type: "application/json" });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement("a");
                          a.href = url;
                          a.download = `ai-summary-${formData.styleNumber}.json`;
                          a.click();
                        }
                      }}
                    />
                  )}
                </div>
              )}

              {/* Legacy Inspection Summary (for backward compatibility) */}
              {!aiSummary && (defects.length > 0 || images.length > 0) ? (
                <InspectionSummary
                  defects={defects}
                  checkpoints={checkpoints}
                  inspectionType={formData.inspectionType}
                  inspectionStage={formData.inspectionStage}
                  formData={formData}
                />
              ) : null}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Auditor Remarks
                </label>
                <textarea
                  name="remarks"
                  value={formData.remarks}
                  onChange={handleInputChange}
                  placeholder="Enter findings, recommendations, and corrective actions..."
                  rows={6}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Summary Dashboard */}
              <div className="mt-6 bg-orange-50 rounded-lg p-6">
                <h3 className="font-semibold text-slate-900 mb-4">Audit Summary</h3>
                <div className="grid md:grid-cols-4 gap-4">
                  <SummaryCard label="Total Pieces Inspected" value={formData.inspectionQuantity || "0"} />
                  <SummaryCard label="Total Defects" value={defects.length.toString()} />
                  <SummaryCard label="Critical Defects" value={defects.filter(d => d.severity === "critical").length.toString()} color="text-red-600" />
                  <SummaryCard label="Major Defects" value={defects.filter(d => d.severity === "major").length.toString()} color="text-orange-600" />
                </div>
              </div>
            </div>
          </Section>

          {/* Section: Approval */}
          <Section
            id="approval"
            title="Digital Approval"
            expanded={expandedSection === "approval"}
            onToggle={() =>
              setExpandedSection(
                expandedSection === "approval" ? "" : "approval"
              )
            }
          >
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Auditor Signature
                </label>
                <div className="w-full h-32 border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center text-slate-600">
                  Signature Pad (Click to Sign)
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  QA Manager Signature
                </label>
                <div className="w-full h-32 border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center text-slate-600">
                  Signature Pad (Click to Sign)
                </div>
              </div>
              <p className="text-sm text-slate-600">
                Date & Time: {new Date().toLocaleString()}
              </p>
            </div>
          </Section>

          {/* Submit Button */}
          <div className="flex gap-4 justify-end">
            <Link
              to="/"
              className="px-6 py-2 border border-slate-300 rounded-lg text-slate-700 font-medium hover:bg-slate-100 transition"
            >
              Save as Draft
            </Link>
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-blue-600 to-orange-500 text-white rounded-lg font-semibold hover:shadow-lg transition"
            >
              <Save className="w-5 h-5" /> Submit Report
            </button>
          </div>
        </form>
      </main>

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full overflow-hidden">
            {/* Success Header */}
            <div className="bg-gradient-to-r from-green-600 to-emerald-500 px-8 py-12 text-center">
              <CheckCircle2 className="w-20 h-20 text-white mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-white mb-2">
                ✓ Inspection Successfully Submitted
              </h2>
            </div>

            {/* Content */}
            <div className="px-8 py-6 space-y-4">
              <p className="text-slate-700 text-center">
                Thank you for completing the inspection. Your contribution helps
                maintain the highest quality standards and ensures customer
                satisfaction.
              </p>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
                <p className="text-sm text-blue-900">
                  <strong>Report ID:</strong> {auditId || `AUD-${Date.now()}`}
                </p>
                <p className="text-sm text-blue-900">
                  <strong>Session Duration:</strong> {sessionDuration}
                </p>
                <p className="text-sm text-blue-900">
                  <strong>Submitted:</strong> {new Date().toLocaleString()}
                </p>
              </div>

              <p className="text-center text-slate-600 text-sm italic">
                Thank you for your dedication.
                <br />
                — UNYX STUDIO Quality Management Team
              </p>
            </div>

            {/* Action Buttons */}
            <div className="border-t border-slate-200 px-8 py-4 space-y-3">
              <button
                onClick={() => window.location.href = "/"}
                className="w-full px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
              >
                Return to Dashboard
              </button>
              <button
                onClick={() => window.location.href = "/audit/new"}
                className="w-full px-4 py-3 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg font-medium transition"
              >
                Start New Inspection
              </button>
            </div>

            {/* Footer */}
            <div className="bg-slate-50 px-8 py-3 text-center text-xs text-slate-500">
              Redirecting to dashboard in 5 seconds...
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Section({
  id,
  title,
  expanded,
  onToggle,
  children,
}: {
  id: string;
  title: string;
  expanded: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all overflow-hidden">
      <button
        type="button"
        onClick={onToggle}
        className="w-full px-6 py-4 flex justify-between items-center hover:bg-gradient-to-r hover:from-blue-50 hover:to-orange-50 transition-colors group"
      >
        <h2 className="text-lg font-semibold text-slate-900 group-hover:text-blue-700 transition-colors">{title}</h2>
        <ChevronDown
          className={`w-5 h-5 text-slate-600 transition-all group-hover:text-blue-600 ${
            expanded ? "rotate-180" : ""
          }`}
        />
      </button>
      {expanded && (
        <div className="px-6 py-4 border-t border-slate-100 bg-gradient-to-b from-slate-50/30 to-white">
          {children}
        </div>
      )}
    </div>
  );
}

function CheckpointGroup({
  title,
  items,
  values,
  onChange,
  labels,
}: {
  title: string;
  items: string[];
  values: Record<string, { status: string | null; pcsChecked: number }>;
  onChange: (
    section: string,
    checkpoint: string,
    field: "status" | "pcsChecked",
    value: string | number | null
  ) => void;
  labels: Record<string, string>;
}) {
  const section = title.toLowerCase().replace(/\s+/g, "");
  return (
    <div>
      <h4 className="font-medium text-slate-900 mb-3">{title}</h4>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((item) => (
          <div key={item} className="border border-slate-300 rounded-lg p-3 bg-white">
            <p className="text-sm font-medium text-slate-700 mb-3">
              {labels[item]}
            </p>
            <div className="space-y-2">
              <div>
                <label className="block text-xs text-slate-600 mb-1">
                  Pcs Checked
                </label>
                <input
                  type="number"
                  min="0"
                  value={values[item]?.pcsChecked || 0}
                  onChange={(e) =>
                    onChange(
                      section,
                      item,
                      "pcsChecked",
                      parseInt(e.target.value)
                    )
                  }
                  className="w-full px-2 py-1 border border-slate-300 rounded text-sm"
                />
              </div>
              <div className="flex gap-1">
                {["pass", "fail", "na"].map((status) => (
                  <button
                    key={status}
                    type="button"
                    onClick={() =>
                      onChange(
                        section,
                        item,
                        "status",
                        values[item]?.status === status ? null : status
                      )
                    }
                    className={`flex-1 px-2 py-1 text-xs font-medium rounded transition ${
                      values[item]?.status === status
                        ? status === "pass"
                          ? "bg-green-100 text-green-700 border border-green-300"
                          : status === "fail"
                          ? "bg-red-100 text-red-700 border border-red-300"
                          : "bg-gray-100 text-gray-700 border border-gray-300"
                        : "bg-slate-100 text-slate-600 border border-slate-300"
                    }`}
                  >
                    {status.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SummaryCard({
  label,
  value,
  color = "text-slate-900",
}: {
  label: string;
  value: string;
  color?: string;
}) {
  return (
    <div className="bg-white rounded-lg p-4 border border-slate-200">
      <p className="text-sm text-slate-600 mb-1">{label}</p>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
    </div>
  );
}
