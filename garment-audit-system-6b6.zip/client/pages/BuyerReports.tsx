import React, { useState, useMemo, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { UserProfile } from "@/components/UserProfile";
import {
  ArrowLeft,
  Search,
  Filter,
  Download,
  Eye,
  CheckCircle2,
  AlertCircle,
  Zap,
  ChevronDown,
  Calendar,
} from "lucide-react";

interface InspectionReport {
  id: string;
  reportNumber: string;
  poNumber: string;
  styleNumber: string;
  styleName: string;
  factoryName: string;
  supplierName: string;
  inspectionDate: string;
  inspectionStage: "inline" | "midline" | "final" | "pre-shipment";
  result: "pass" | "conditional" | "fail";
  qualityScore: number;
  shipmentStatus: "ready" | "requires_action" | "hold";
  defectCount: number;
  aiSummaryGenerated: boolean;
  approvalStatus: "approved" | "rejected" | "pending";
}

export default function BuyerReports() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterFactory, setFilterFactory] = useState("");
  const [filterResult, setFilterResult] = useState("all");
  const [filterStage, setFilterStage] = useState("all");
  const [filterShipment, setFilterShipment] = useState("all");
  const [expandedFilters, setExpandedFilters] = useState(false);
  const [reports, setReports] = useState<InspectionReport[]>([]);

  // Load reports from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem("audits");
      if (stored) {
        const audits = JSON.parse(stored);
        const formattedReports: InspectionReport[] = audits.map((audit: any, index: number) => ({
          id: `REP-${index + 1}`,
          reportNumber: `RPT-${audit.id || index + 1}`,
          poNumber: audit.poNumber || "N/A",
          styleNumber: audit.styleNumber || "N/A",
          styleName: audit.styleName || "N/A",
          factoryName: audit.factoryName || "N/A",
          supplierName: audit.buyerName || "N/A",
          inspectionDate: audit.auditDate || new Date().toISOString().split('T')[0],
          inspectionStage: (audit.inspectionStage || "final").toLowerCase() as any,
          result: (audit.result || "conditional") as "pass" | "conditional" | "fail",
          qualityScore: audit.qualityScore || 80,
          shipmentStatus: "ready" as const,
          defectCount: audit.totalDefects || 0,
          aiSummaryGenerated: !!audit.aiSummary,
          approvalStatus: "approved" as const,
        }));
        setReports(formattedReports);
      }
    } catch (error) {
      console.error("Failed to load reports from localStorage:", error);
      setReports([]);
    }
  }, []);

  // Filter logic
  const filteredReports = useMemo(() => {
    return reports.filter((report) => {
      const matchesSearch =
        report.poNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        report.styleNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        report.styleName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        report.reportNumber.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesFactory = !filterFactory || report.factoryName === filterFactory;
      const matchesResult = filterResult === "all" || report.result === filterResult;
      const matchesStage = filterStage === "all" || report.inspectionStage === filterStage;
      const matchesShipment =
        filterShipment === "all" || report.shipmentStatus === filterShipment;

      return matchesSearch && matchesFactory && matchesResult && matchesStage && matchesShipment;
    });
  }, [searchTerm, filterFactory, filterResult, filterStage, filterShipment, reports]);

  const factories = [...new Set(reports.map((r) => r.factoryName))];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white pb-20">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link
                to="/buyer/dashboard"
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900"
              >
                <ArrowLeft className="w-5 h-5" />
                Back
              </Link>
              <div className="border-l border-slate-300 pl-4">
                <h1 className="text-2xl font-bold text-slate-900">
                  Inspection Reports
                </h1>
                <p className="text-sm text-slate-600">
                  {filteredReports.length} of {reports.length} reports
                </p>
              </div>
            </div>
            <UserProfile />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Bar */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 mb-6 shadow-sm">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by PO number, style number, or report ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Filter Toggle */}
          <button
            onClick={() => setExpandedFilters(!expandedFilters)}
            className="flex items-center gap-2 text-slate-700 hover:text-slate-900 font-medium text-sm"
          >
            <Filter className="w-4 h-4" />
            Advanced Filters
            <ChevronDown
              className={`w-4 h-4 transition ${
                expandedFilters ? "rotate-180" : ""
              }`}
            />
          </button>

          {/* Filters */}
          {expandedFilters && (
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t border-slate-200">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2 uppercase">
                  Factory
                </label>
                <select
                  value={filterFactory}
                  onChange={(e) => setFilterFactory(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Factories</option>
                  {factories.map((factory) => (
                    <option key={factory} value={factory}>
                      {factory}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2 uppercase">
                  Result
                </label>
                <select
                  value={filterResult}
                  onChange={(e) => setFilterResult(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Results</option>
                  <option value="pass">✓ Pass</option>
                  <option value="conditional">⚠ Conditional</option>
                  <option value="fail">✗ Fail</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2 uppercase">
                  Stage
                </label>
                <select
                  value={filterStage}
                  onChange={(e) => setFilterStage(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Stages</option>
                  <option value="inline">Inline</option>
                  <option value="midline">Midline</option>
                  <option value="final">Final</option>
                  <option value="pre-shipment">Pre-Shipment</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2 uppercase">
                  Shipment Status
                </label>
                <select
                  value={filterShipment}
                  onChange={(e) => setFilterShipment(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Status</option>
                  <option value="ready">🟢 Ready to Ship</option>
                  <option value="requires_action">🟡 Requires Action</option>
                  <option value="hold">🔴 Hold</option>
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Reports Table */}
        {filteredReports.length === 0 ? (
          <div className="bg-white rounded-lg border-2 border-dashed border-slate-300 p-12 text-center">
            <Search className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 mb-2">
              {reports.length === 0 ? "No reports yet" : "No reports found"}
            </p>
            <p className="text-sm text-slate-500">
              {reports.length === 0
                ? "Reports will appear here as they are created"
                : "Try adjusting your search or filters"}
            </p>
          </div>
        ) : (
          <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Report
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      PO Number
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Factory
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Quality
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Shipment
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredReports.map((report) => (
                    <tr key={report.id} className="hover:bg-slate-50 transition">
                      <td className="px-6 py-4">
                        <div className="font-medium text-slate-900">
                          {report.reportNumber}
                        </div>
                        <div className="text-xs text-slate-600">
                          {report.styleName}
                        </div>
                      </td>
                      <td className="px-6 py-4 font-medium text-slate-900">
                        {report.poNumber}
                      </td>
                      <td className="px-6 py-4 text-slate-700">
                        {report.factoryName}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-700">
                        {new Date(report.inspectionDate).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-12 bg-slate-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${
                                report.qualityScore >= 90
                                  ? "bg-green-500"
                                  : report.qualityScore >= 80
                                    ? "bg-yellow-500"
                                    : "bg-red-500"
                              }`}
                              style={{ width: `${report.qualityScore}%` }}
                            />
                          </div>
                          <span className="font-semibold text-sm">
                            {report.qualityScore}%
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`px-2 py-1 rounded text-xs font-semibold ${
                            report.shipmentStatus === "ready"
                              ? "bg-green-100 text-green-800"
                              : report.shipmentStatus === "requires_action"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }`}
                        >
                          {report.shipmentStatus === "ready"
                            ? "🟢 Ready"
                            : report.shipmentStatus === "requires_action"
                              ? "🟡 Action"
                              : "🔴 Hold"}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`px-2 py-1 rounded text-xs font-semibold ${
                            report.approvalStatus === "approved"
                              ? "bg-green-100 text-green-800"
                              : report.approvalStatus === "pending"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-red-100 text-red-800"
                          }`}
                        >
                          {report.approvalStatus === "approved"
                            ? "Approved"
                            : report.approvalStatus === "pending"
                              ? "Pending"
                              : "Rejected"}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button
                            title="View Report"
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            title="Download PDF"
                            className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
