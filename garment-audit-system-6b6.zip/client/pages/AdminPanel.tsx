import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, CheckCircle2, XCircle, Clock, Mail, Settings } from "lucide-react";

interface PendingAuditor {
  id: string;
  name: string;
  email: string;
  mobile: string;
  employeeId: string;
  company: string;
  designation: string;
  registeredAt: string;
  verificationStatus: "google" | "email" | "phone";
}

const pendingAuditors: PendingAuditor[] = [
  {
    id: "1",
    name: "John Smith",
    email: "john.smith@company.com",
    mobile: "+91 98765-43210",
    employeeId: "EMP-2024-001",
    company: "ABC Quality Services",
    designation: "Senior QA Auditor",
    registeredAt: "2024-01-15 10:30 AM",
    verificationStatus: "google",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    email: "sarah.j@quality.com",
    mobile: "+91 87654-32109",
    employeeId: "EMP-2024-002",
    company: "XYZ Auditors",
    designation: "QA Inspector",
    registeredAt: "2024-01-14 02:15 PM",
    verificationStatus: "google",
  },
  {
    id: "3",
    name: "Rajesh Kumar",
    email: "rajesh.k@audits.com",
    mobile: "+91 76543-21098",
    employeeId: "EMP-2024-003",
    company: "Quality First Ltd",
    designation: "Auditor",
    registeredAt: "2024-01-13 09:45 AM",
    verificationStatus: "email",
  },
];

export default function AdminPanel() {
  const [auditors, setAuditors] = useState(pendingAuditors);
  const [selectedAuditor, setSelectedAuditor] = useState<PendingAuditor | null>(null);
  const [adminEmail, setAdminEmail] = useState("admin@company.com");
  const [showSettings, setShowSettings] = useState(false);

  const handleApprove = (id: string) => {
    setAuditors(auditors.filter((a) => a.id !== id));
    alert("Auditor approved! Notification email sent.");
  };

  const handleReject = (id: string) => {
    setAuditors(auditors.filter((a) => a.id !== id));
    alert("Auditor rejected! Email notification sent.");
  };

  const handleSuspend = (id: string) => {
    alert("Auditor suspended!");
  };

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-orange-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <Link
              to="/"
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">Admin Panel</h1>
            <div className="flex gap-2">
              <Link
                to="/admin/auditors"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Mail className="w-5 h-5" /> Manage Auditors
              </Link>
              <button
                onClick={() => setShowSettings(true)}
                className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-100"
              >
                <Settings className="w-5 h-5" /> Settings
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Settings Modal */}
        {showSettings && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-md w-full p-6">
              <h2 className="text-xl font-bold text-slate-900 mb-4">Admin Settings</h2>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Auditor Registration Notification Email
                </label>
                <input
                  type="email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                />
                <p className="text-sm text-slate-600 mb-4">
                  New auditor registrations will be sent to this email address for approval.
                </p>
                <div className="flex gap-4">
                  <button
                    onClick={() => setShowSettings(false)}
                    className="flex-1 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-100"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      alert("Settings saved!");
                      setShowSettings(false);
                    }}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Overview Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <p className="text-sm text-slate-600 mb-2">Pending Approvals</p>
            <p className="text-4xl font-bold text-orange-600">{auditors.length}</p>
          </div>
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <p className="text-sm text-slate-600 mb-2">Admin Notification Email</p>
            <p className="font-mono text-sm text-slate-900">{adminEmail}</p>
          </div>
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <p className="text-sm text-slate-600 mb-2">Total Auditors (Approved)</p>
            <p className="text-4xl font-bold text-green-600">42</p>
          </div>
        </div>

        {/* Pending Auditor Approvals */}
        <div className="bg-white rounded-lg border border-orange-200 p-6 mb-8">
          <h2 className="text-xl font-bold text-slate-900 mb-6">
            Pending Auditor Registrations
          </h2>

          {auditors.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <p className="text-lg font-semibold text-slate-900">All Caught Up!</p>
              <p className="text-slate-600 mt-2">No pending auditor approvals</p>
            </div>
          ) : (
            <div className="space-y-4">
              {auditors.map((auditor) => (
                <div
                  key={auditor.id}
                  className="border border-slate-200 rounded-lg p-6 hover:bg-slate-50 transition"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900">
                        {auditor.name}
                      </h3>
                      <p className="text-sm text-slate-600">
                        {auditor.designation} at {auditor.company}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-medium">
                        {auditor.verificationStatus === "google"
                          ? "✓ Google Verified"
                          : "✓ Email Verified"}
                      </span>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4 mb-4 text-sm">
                    <div>
                      <p className="text-slate-600">Email</p>
                      <p className="font-medium text-slate-900">{auditor.email}</p>
                    </div>
                    <div>
                      <p className="text-slate-600">Employee ID</p>
                      <p className="font-medium text-slate-900">{auditor.employeeId}</p>
                    </div>
                    <div>
                      <p className="text-slate-600">Registered</p>
                      <p className="font-medium text-slate-900">{auditor.registeredAt}</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => handleApprove(auditor.id)}
                      className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 transition"
                    >
                      <CheckCircle2 className="w-4 h-4" /> Approve
                    </button>
                    <button
                      onClick={() => handleReject(auditor.id)}
                      className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 transition"
                    >
                      <XCircle className="w-4 h-4" /> Reject
                    </button>
                    <button
                      onClick={() => handleSuspend(auditor.id)}
                      className="flex-1 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 transition"
                    >
                      <Clock className="w-4 h-4" /> Suspend
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Notification System Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h2 className="text-lg font-bold text-blue-900 mb-4">
            Notification System
          </h2>
          <div className="space-y-3">
            <div className="flex gap-3">
              <Mail className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-blue-900">Email Notifications</p>
                <p className="text-sm text-blue-800">
                  New auditor registrations are automatically sent to <strong>{adminEmail}</strong>
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-blue-900">Approval Workflow</p>
                <p className="text-sm text-blue-800">
                  Auditors cannot perform inspections until account is approved by admin
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <Mail className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-blue-900">Auditor Notifications</p>
                <p className="text-sm text-blue-800">
                  Auditors are notified via email when their account is approved or rejected
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
