import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { UserProfile } from "@/components/UserProfile";
import { ArrowLeft, Mail, Plus, Trash2, Save } from "lucide-react";

export default function AdminSettings() {
  const [managementEmails, setManagementEmails] = useState<string[]>([]);
  const [newEmail, setNewEmail] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const settings = JSON.parse(localStorage.getItem("emailSettings") || "{}");
    setManagementEmails(settings.managementEmails || ["management@unyx.com"]);
  }, []);

  const handleAddEmail = () => {
    if (newEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail) && !managementEmails.includes(newEmail)) {
      setManagementEmails([...managementEmails, newEmail]);
      setNewEmail("");
      setSaved(false);
    }
  };

  const handleRemoveEmail = (email: string) => {
    setManagementEmails(managementEmails.filter((e) => e !== email));
    setSaved(false);
  };

  const handleSave = () => {
    const settings = JSON.parse(localStorage.getItem("emailSettings") || "{}");
    settings.managementEmails = managementEmails;
    localStorage.setItem("emailSettings", JSON.stringify(settings));
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white pb-20">
      {/* Header */}
      <header className="bg-white border-b border-blue-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link to="/admin" className="flex items-center gap-2 text-slate-600 hover:text-slate-900">
                <ArrowLeft className="w-5 h-5" />
                Admin
              </Link>
              <div className="border-l border-blue-300 pl-4">
                <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
                <p className="text-sm text-slate-600">Configure system settings and notifications</p>
              </div>
            </div>
            <UserProfile />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Email Settings Card */}
        <div className="bg-white rounded-lg border border-blue-200 shadow-sm p-8">
          <div className="flex items-center gap-3 mb-6">
            <Mail className="w-6 h-6 text-blue-600" />
            <h2 className="text-2xl font-bold text-slate-900">Email Notifications</h2>
          </div>

          <p className="text-slate-600 mb-6">
            Configure which email addresses receive inspection report notifications. When auditors submit inspection reports, emails will be sent to all configured management addresses.
          </p>

          {/* Current Emails */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Management Email Recipients</h3>
            <div className="space-y-2 mb-6">
              {managementEmails.length === 0 ? (
                <p className="text-slate-600 text-sm italic">No email addresses configured</p>
              ) : (
                managementEmails.map((email) => (
                  <div key={email} className="flex items-center justify-between bg-slate-50 p-4 rounded-lg border border-slate-200">
                    <span className="text-slate-900 font-medium">{email}</span>
                    <button
                      onClick={() => handleRemoveEmail(email)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                      title="Remove email"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Add New Email */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Add New Email</h3>
            <div className="flex gap-3">
              <input
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleAddEmail()}
                placeholder="Enter management email address"
                className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={handleAddEmail}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add
              </button>
            </div>
            <p className="text-xs text-slate-500 mt-2">Enter a valid email address and click Add or press Enter</p>
          </div>

          {/* Save Button */}
          <div className="flex gap-3">
            <button
              onClick={handleSave}
              className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Settings
            </button>
            {saved && (
              <div className="px-4 py-2 bg-green-100 text-green-800 rounded-lg text-sm font-medium flex items-center">
                ✓ Settings saved successfully
              </div>
            )}
          </div>

          {/* Info Box */}
          <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-900 font-semibold mb-2">💡 How it works:</p>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>✓ When an auditor submits an inspection report, an email is automatically sent to all configured addresses</li>
              <li>✓ The email includes inspection summary, quality score, and defect details</li>
              <li>✓ Email subject changes based on inspection result (Passed/Failed/Conditional)</li>
              <li>✓ Recipients can view the full report and download PDF from the email</li>
            </ul>
          </div>
        </div>
      </main>
    </div>
  );
}
