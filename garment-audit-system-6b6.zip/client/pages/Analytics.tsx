import { Link } from "react-router-dom";
import { ArrowLeft, ArrowRight, TrendingUp, Users, Zap, AlertCircle } from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";

// Sample data for charts
const auditTrendData = [
  { date: "Mon", audits: 12, passed: 10, failed: 2 },
  { date: "Tue", audits: 19, passed: 16, failed: 3 },
  { date: "Wed", audits: 15, passed: 12, failed: 3 },
  { date: "Thu", audits: 22, passed: 19, failed: 3 },
  { date: "Fri", audits: 18, passed: 15, failed: 3 },
  { date: "Sat", audits: 14, passed: 12, failed: 2 },
  { date: "Sun", audits: 10, passed: 9, failed: 1 },
];

const passFailData = [
  { name: "Passed", value: 65, color: "#16a34a" },
  { name: "Failed", value: 20, color: "#dc2626" },
  { name: "Conditional", value: 15, color: "#f59e0b" },
];

const defectData = [
  { name: "Major", value: 45 },
  { name: "Minor", value: 32 },
  { name: "Critical", value: 18 },
];

const defectCategoryData = [
  { category: "Sewing", defects: 45 },
  { category: "Fabric", defects: 38 },
  { category: "Measurement", defects: 32 },
  { category: "Printing", defects: 28 },
  { category: "Packing", defects: 22 },
  { category: "Labeling", defects: 15 },
];

const factoryPerformanceData = [
  { factory: "Factory A", passRate: 95, defectRate: 2.5 },
  { factory: "Factory B", passRate: 88, defectRate: 4.2 },
  { factory: "Factory C", passRate: 92, defectRate: 3.1 },
  { factory: "Factory D", passRate: 85, defectRate: 5.5 },
  { factory: "Factory E", passRate: 90, defectRate: 3.8 },
];

const auditorPerformanceData = [
  { name: "Auditor 1", audits: 24, passRate: 94 },
  { name: "Auditor 2", audits: 19, passRate: 89 },
  { name: "Auditor 3", audits: 22, passRate: 91 },
  { name: "Auditor 4", audits: 18, passRate: 86 },
  { name: "Auditor 5", audits: 21, passRate: 93 },
];

const COLORS = ["#16a34a", "#dc2626", "#f59e0b"];

export default function Analytics() {
  return (
    <div className="min-h-screen bg-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-orange-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <Link
              to="/"
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">
              Executive Analytics Dashboard
            </h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <KPICard
            title="Total Audits"
            value="324"
            change="+12%"
            icon={Zap}
            color="blue"
          />
          <KPICard
            title="Pass Rate"
            value="89.5%"
            change="+2.3%"
            icon={TrendingUp}
            color="green"
          />
          <KPICard
            title="Total Defects"
            value="1,245"
            change="-8%"
            icon={AlertCircle}
            color="orange"
          />
          <KPICard
            title="Active Auditors"
            value="12"
            change="+1"
            icon={Users}
            color="purple"
          />
        </div>

        {/* Inspection Details KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <SmallKPI label="Total Orders" value="156" />
          <SmallKPI label="Pieces Inspected" value="45.2K" />
          <SmallKPI label="Factories Audited" value="28" />
          <SmallKPI label="AQL 1.5" value="45" />
          <SmallKPI label="AQL 2.5" value="62" />
          <SmallKPI label="100% Inspections" value="78" />
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Audit Trend */}
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Audit Performance Trend
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={auditTrendData}>
                <defs>
                  <linearGradient id="colorAudits" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="audits"
                  stroke="#2563eb"
                  fillOpacity={1}
                  fill="url(#colorAudits)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Pass vs Fail */}
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Pass vs Fail Distribution
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={passFailData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {passFailData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Defect Analysis */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Defect Severity */}
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Defect Severity Distribution
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={defectData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#f97316" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Top Defect Categories */}
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Top Defect Categories
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={defectCategoryData}
                layout="vertical"
                margin={{ left: 100 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="category" type="category" width={90} />
                <Tooltip />
                <Bar dataKey="defects" fill="#3b82f6" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Performance Scorecards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Factory Performance */}
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Factory Performance Scorecard
            </h2>
            <div className="space-y-4">
              {factoryPerformanceData.map((factory, idx) => (
                <div key={idx} className="border border-orange-100 rounded-lg p-3">
                  <div className="flex justify-between items-center mb-2">
                    <p className="font-medium text-slate-700">{factory.factory}</p>
                    <span className="text-sm font-bold text-blue-600">
                      {factory.passRate}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-blue-600 to-green-500 h-2 rounded-full"
                      style={{ width: `${factory.passRate}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Defect Rate: {factory.defectRate}%
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Auditor Performance */}
          <div className="bg-white rounded-lg border border-orange-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Auditor Performance Leaderboard
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={auditorPerformanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="audits" fill="#3b82f6" />
                <Bar dataKey="passRate" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Summary Section */}
        <div className="bg-gradient-to-r from-blue-600 to-orange-500 rounded-lg p-8 text-white mb-8">
          <h2 className="text-2xl font-bold mb-4">Quality Performance Summary</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-blue-100 mb-2">Weekly Audits Completed</p>
              <p className="text-4xl font-bold">89</p>
            </div>
            <div>
              <p className="text-blue-100 mb-2">Current Pass Rate</p>
              <p className="text-4xl font-bold">89.5%</p>
            </div>
            <div>
              <p className="text-blue-100 mb-2">Avg Defects per Audit</p>
              <p className="text-4xl font-bold">3.8</p>
            </div>
          </div>
        </div>

        {/* Advanced Features */}
        <div className="grid md:grid-cols-3 gap-6">
          <Link
            to="/analytics/advanced"
            className="bg-white border-2 border-blue-600 rounded-lg p-6 hover:shadow-lg transition"
          >
            <h3 className="text-xl font-bold text-slate-900 mb-2">
              Advanced Analytics
            </h3>
            <p className="text-slate-600 mb-4 text-sm">
              Geo-mapping dashboard, advanced filters, and export
            </p>
            <div className="flex items-center gap-2 text-blue-600 font-semibold">
              View <ArrowRight className="w-4 h-4" />
            </div>
          </Link>

          <Link
            to="/analytics/auditors"
            className="bg-white border-2 border-green-600 rounded-lg p-6 hover:shadow-lg transition"
          >
            <h3 className="text-xl font-bold text-slate-900 mb-2">
              Auditor Performance
            </h3>
            <p className="text-slate-600 mb-4 text-sm">
              Individual auditor metrics, rankings, and productivity
            </p>
            <div className="flex items-center gap-2 text-green-600 font-semibold">
              View <ArrowRight className="w-4 h-4" />
            </div>
          </Link>

          <Link
            to="/reports"
            className="bg-white border-2 border-orange-600 rounded-lg p-6 hover:shadow-lg transition"
          >
            <h3 className="text-xl font-bold text-slate-900 mb-2">
              Management Reports
            </h3>
            <p className="text-slate-600 mb-4 text-sm">
              Professional reports and automated email scheduling
            </p>
            <div className="flex items-center gap-2 text-orange-600 font-semibold">
              View <ArrowRight className="w-4 h-4" />
            </div>
          </Link>
        </div>
      </main>
    </div>
  );
}

function KPICard({
  title,
  value,
  change,
  icon: Icon,
  color,
}: {
  title: string;
  value: string;
  change: string;
  icon: any;
  color: string;
}) {
  const colorClasses = {
    blue: "bg-blue-50 border-blue-200 text-blue-600",
    green: "bg-green-50 border-green-200 text-green-600",
    orange: "bg-orange-50 border-orange-200 text-orange-600",
    purple: "bg-purple-50 border-purple-200 text-purple-600",
  };

  return (
    <div className={`${colorClasses[color as keyof typeof colorClasses]} rounded-lg border p-6`}>
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-sm font-medium text-slate-700">{title}</h3>
        <Icon className="w-5 h-5" />
      </div>
      <p className="text-3xl font-bold text-slate-900 mb-2">{value}</p>
      <p className="text-sm font-medium text-green-600">{change} from last week</p>
    </div>
  );
}

function SmallKPI({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-white rounded-lg border border-orange-200 p-4 text-center">
      <p className="text-xs text-slate-600 mb-1">{label}</p>
      <p className="text-2xl font-bold text-slate-900">{value}</p>
    </div>
  );
}
