import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Upload, Camera, CheckCircle2, AlertCircle } from "lucide-react";

export default function AuditorOnboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: "John Smith",
    email: "john.smith@company.com",
    mobileNumber: "+91 98765-43210",
    employeeId: "EMP-2024-001",
    companyName: "ABC Quality Services",
    designation: "Senior QA Auditor",
    region: "North India",
    profilePhoto: null as File | null,
  });

  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFormData((prev) => ({ ...prev, profilePhoto: e.target.files![0] }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      setStep(2);
    } else {
      setSubmitted(true);
      // Simulate submission
      setTimeout(() => {
        navigate("/");
      }, 3000);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-600 to-orange-500 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-2xl p-8 text-center">
          <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-slate-900 mb-2">
            Registration Submitted!
          </h1>
          <p className="text-slate-600 mb-4">
            Your profile has been submitted for admin approval. You'll be notified
            at {formData.email} once your account is activated.
          </p>
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-sm text-yellow-800">
            <AlertCircle className="w-4 h-4 inline mr-2" />
            You cannot perform inspections until your account is approved.
          </div>
          <p className="text-sm text-slate-500 mt-4">Redirecting to dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-orange-500 to-blue-600 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            Auditor Profile Setup
          </h1>
          <p className="text-blue-100">Complete your profile to get started</p>
        </div>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex gap-2 mb-4">
            <div
              className={`flex-1 h-2 rounded-full ${
                step >= 1 ? "bg-white" : "bg-white/30"
              }`}
            ></div>
            <div
              className={`flex-1 h-2 rounded-full ${
                step >= 2 ? "bg-white" : "bg-white/30"
              }`}
            ></div>
          </div>
          <p className="text-white text-sm">
            Step {step} of 2 - {step === 1 ? "Personal Information" : "Photo Upload"}
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-lg shadow-2xl p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {step === 1 && (
              <>
                <h2 className="text-2xl font-bold text-slate-900 mb-6">
                  Personal Information
                </h2>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Mobile Number *
                    </label>
                    <input
                      type="tel"
                      name="mobileNumber"
                      value={formData.mobileNumber}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Employee ID *
                    </label>
                    <input
                      type="text"
                      name="employeeId"
                      value={formData.employeeId}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Company Name *
                    </label>
                    <input
                      type="text"
                      name="companyName"
                      value={formData.companyName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Designation *
                    </label>
                    <input
                      type="text"
                      name="designation"
                      value={formData.designation}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Region *
                    </label>
                    <select
                      name="region"
                      value={formData.region}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Select Region</option>
                      <option value="North India">North India</option>
                      <option value="South India">South India</option>
                      <option value="East India">East India</option>
                      <option value="West India">West India</option>
                      <option value="Central India">Central India</option>
                    </select>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-700">
                  <p className="font-semibold mb-1">ℹ️ Account Verification</p>
                  <p>
                    Your account is verified via Google Sign-In. An admin will review
                    your profile and approve your access to start inspections.
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition"
                >
                  Continue to Photo Upload
                </button>
              </>
            )}

            {step === 2 && (
              <>
                <h2 className="text-2xl font-bold text-slate-900 mb-6">
                  Profile Photo
                </h2>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-3">
                    Profile Photograph *
                  </label>
                  <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-blue-400 transition cursor-pointer">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoCapture}
                      className="hidden"
                      id="photo-input"
                      required
                    />
                    <label htmlFor="photo-input" className="cursor-pointer">
                      <Camera className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                      <p className="font-medium text-slate-700">
                        Upload or Capture Photo
                      </p>
                      <p className="text-sm text-slate-600 mt-1">
                        Drag & drop or click to select
                      </p>
                    </label>
                  </div>
                  {formData.profilePhoto && (
                    <p className="text-green-600 text-sm mt-2 flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" />
                      {formData.profilePhoto.name} uploaded
                    </p>
                  )}
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-sm text-yellow-800">
                  <AlertCircle className="w-4 h-4 inline mr-2" />
                  <p>
                    Please ensure the photo is clear, well-lit, and shows your face
                    directly.
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="px-6 py-3 border border-slate-300 text-slate-700 rounded-lg font-semibold hover:bg-slate-50 transition"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={!formData.profilePhoto}
                    className="px-6 py-3 bg-gradient-to-r from-blue-600 to-orange-500 text-white rounded-lg font-semibold hover:shadow-lg disabled:opacity-50 transition"
                  >
                    Submit Registration
                  </button>
                </div>
              </>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}
