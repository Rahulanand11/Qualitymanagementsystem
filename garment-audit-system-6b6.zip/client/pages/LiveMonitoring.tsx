import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import {
  Camera,
  Settings,
  Grid3x3,
  Maximize2,
  X,
  Plus,
  Search,
  Filter,
  AlertCircle,
  Zap,
  Eye,
} from "lucide-react";
import { CameraManager } from "@/components/CameraManager";
import { LiveVideoViewer } from "@/components/LiveVideoViewer";
import { CameraStatusDashboard } from "@/components/CameraStatusDashboard";
import { InspectionInfoPanel } from "@/components/InspectionInfoPanel";

interface Camera {
  id: string;
  name: string;
  factory: string;
  location: string;
  status: "online" | "offline" | "reconnecting" | "disabled";
  type: "ip-rtsp" | "onvif" | "usb" | "network" | "hls" | "webrtc";
  url: string;
  lastConnected: string;
  signalStrength?: number;
  resolution?: string;
  frameRate?: string;
  enabled: boolean;
  linkedInspection?: string;
}

interface InspectionInfo {
  id: string;
  auditorName: string;
  factoryName: string;
  buyer: string;
  supplier: string;
  poNumber: string;
  styleNumber: string;
  inspectionStage: string;
  status: string;
  startTime: string;
  duration: string;
}

export default function LiveMonitoring() {
  const { user } = useAuth();
  const [cameras, setCameras] = useState<Camera[]>([
    {
      id: "cam-001",
      name: "Factory A – Sewing Line 1",
      factory: "ABC Garments",
      location: "Final Inspection Area",
      status: "online",
      type: "ip-rtsp",
      url: "rtsp://example.com/stream1",
      lastConnected: new Date().toLocaleString(),
      signalStrength: 85,
      resolution: "1920x1080",
      frameRate: "30fps",
      enabled: true,
    },
    {
      id: "cam-002",
      name: "Factory A – Sewing Line 2",
      factory: "ABC Garments",
      location: "Quality Check Area",
      status: "online",
      type: "onvif",
      url: "http://example.com/camera2",
      lastConnected: new Date().toLocaleString(),
      signalStrength: 90,
      resolution: "1920x1080",
      frameRate: "30fps",
      enabled: true,
    },
    {
      id: "cam-003",
      name: "Factory B – Packing",
      factory: "XYZ Textiles",
      location: "Packing Station",
      status: "offline",
      type: "hls",
      url: "https://example.com/stream3.m3u8",
      lastConnected: "2024-01-09 10:30 AM",
      signalStrength: 0,
      resolution: "1280x720",
      frameRate: "25fps",
      enabled: true,
    },
  ]);

  const [selectedCameras, setSelectedCameras] = useState<string[]>(["cam-001"]);
  const [viewMode, setViewMode] = useState<1 | 2 | 4 | 6>("1");
  const [showCameraManager, setShowCameraManager] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterFactory, setFilterFactory] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [fullScreenCamera, setFullScreenCamera] = useState<string | null>(null);
  const [activeInspection, setActiveInspection] = useState<InspectionInfo | null>({
    id: "INS-001",
    auditorName: "John Smith",
    factoryName: "ABC Garments",
    buyer: "Nike",
    supplier: "ABC Garments",
    poNumber: "PO-2024-001",
    styleNumber: "STY-001",
    inspectionStage: "Final Inspection",
    status: "In Progress",
    startTime: new Date(Date.now() - 45 * 60000).toLocaleTimeString(),
    duration: "45 minutes",
  });

  // Check permissions
  const hasAccess = ["admin", "quality-manager"].includes(user?.role || "");

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-600 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Access Denied</h1>
          <p className="text-slate-600">
            You don't have permission to access Live Inspection Monitoring.
          </p>
        </div>
      </div>
    );
  }

  const filteredCameras = cameras.filter((camera) => {
    const matchSearch =
      camera.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      camera.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchFactory = !filterFactory || camera.factory === filterFactory;
    const matchStatus = !filterStatus || camera.status === filterStatus;
    return matchSearch && matchFactory && matchStatus;
  });

  const uniqueFactories = Array.from(
    new Set(cameras.map((c) => c.factory))
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-orange-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <Camera className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Live Inspection Monitoring</h1>
                <p className="text-sm text-slate-600">Real-time camera feeds and inspection tracking</p>
              </div>
            </div>
            <button
              onClick={() => setShowCameraManager(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
            >
              <Settings className="w-4 h-4" /> Manage Cameras
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Controls */}
        <div className="grid lg:grid-cols-4 gap-4 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search cameras..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <select
            value={filterFactory}
            onChange={(e) => setFilterFactory(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">All Factories</option>
            {uniqueFactories.map((factory) => (
              <option key={factory} value={factory}>
                {factory}
              </option>
            ))}
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">All Status</option>
            <option value="online">Online</option>
            <option value="offline">Offline</option>
            <option value="reconnecting">Reconnecting</option>
            <option value="disabled">Disabled</option>
          </select>

          {/* View Mode */}
          <div className="flex gap-2">
            {[1, 2, 4, 6].map((mode) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode as any)}
                className={`flex-1 py-2 rounded-lg font-medium transition ${
                  viewMode === mode
                    ? "bg-blue-600 text-white"
                    : "bg-white border border-slate-300 text-slate-700 hover:bg-slate-50"
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8 mb-8">
          {/* Live Video Viewer */}
          <div className="lg:col-span-3 space-y-6">
            {/* Camera Selection */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
              <h3 className="font-semibold text-slate-900 mb-3">Select Cameras</h3>
              <div className="grid md:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                {filteredCameras.map((camera) => (
                  <label
                    key={camera.id}
                    className="flex items-center gap-3 p-2 border border-slate-200 rounded-lg hover:bg-blue-50 cursor-pointer transition"
                  >
                    <input
                      type="checkbox"
                      checked={selectedCameras.includes(camera.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedCameras([...selectedCameras, camera.id]);
                        } else {
                          setSelectedCameras(selectedCameras.filter((id) => id !== camera.id));
                        }
                      }}
                      className="w-4 h-4 text-blue-600"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">{camera.name}</p>
                      <p className="text-xs text-slate-600">{camera.factory}</p>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${
                      camera.status === "online" ? "bg-green-500" :
                      camera.status === "offline" ? "bg-red-500" :
                      camera.status === "reconnecting" ? "bg-yellow-500" :
                      "bg-gray-500"
                    }`} />
                  </label>
                ))}
              </div>
            </div>

            {/* Live Video Display */}
            <div className="bg-black rounded-xl overflow-hidden shadow-lg border border-slate-700">
              {selectedCameras.length > 0 ? (
                <LiveVideoViewer
                  cameras={selectedCameras.map((id) => cameras.find((c) => c.id === id)!)}
                  viewMode={viewMode}
                  onFullScreen={(cameraId) => setFullScreenCamera(cameraId)}
                />
              ) : (
                <div className="aspect-video flex items-center justify-center text-slate-400">
                  <div className="text-center">
                    <Camera className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>Select cameras to view live feed</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Inspection Info Panel */}
            {activeInspection && (
              <InspectionInfoPanel inspection={activeInspection} />
            )}

            {/* Camera Status Dashboard */}
            <CameraStatusDashboard cameras={cameras} />
          </div>
        </div>

        {/* Camera Manager Modal */}
        {showCameraManager && (
          <CameraManager
            cameras={cameras}
            onClose={() => setShowCameraManager(false)}
            onSave={(updatedCameras) => {
              setCameras(updatedCameras);
              setShowCameraManager(false);
            }}
          />
        )}
      </main>
    </div>
  );
}
