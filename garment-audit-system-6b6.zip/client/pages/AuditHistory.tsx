import React, { useState, useMemo, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  ArrowLeft,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Factory,
  Zap,
} from "lucide-react";
import { UserProfile } from "@/components/UserProfile";

interface AuditRecord {
  id: string;
  styleNumber: string;
  styleName: string;
  poNumber: string;
  buyerName: string;
  factoryName: string;
  auditorName: string;
  auditDate: string;
  inspectionStage: string;
  result: "pass" | "fail" | "conditional";
  totalDefects: number;
  qualityScore: number;
}

export default function AuditHistory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterBy, setFilterBy] = useState<"all" | "pass" | "fail" | "conditional">("all");
  const [sortBy, setSortBy] = useState<"recent" | "score" | "defects">("recent");
  const [auditRecords, setAuditRecords] = useState<AuditRecord[]>([]);

  // Load audits from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem("audits");
      if (stored) {
        const audits = JSON.parse(stored);
        const formattedAudits: AuditRecord[] = audits.map((audit: any) => ({
          id: audit.id || "",
          styleNumber: audit.styleNumber || "",
          styleName: audit.styleName || "",
          poNumber: audit.poNumber || "",
          buyerName: audit.buyerName || "",
          factoryName: audit.factoryName || "",
          auditorName: audit.auditorName || "",
          auditDate: audit.auditDate || new Date().toISOString().split('T')[0],
          inspectionStage: audit.inspectionStage || "",
          result: (audit.result || "conditional") as "pass" | "fail" | "conditional",
          totalDefects: audit.totalDefects || audit.defects?.length || 0,
          qualityScore: audit.qualityScore || 80,
        }));
        setAuditRecords(formattedAudits);
      }
    } catch (error) {
      console.error("Failed to load audits from localStorage:", error);
      setAuditRecords([]);
    }
  }, []);

  // Filter and search logic
  const filteredRecords = useMemo(() => {
    let results = auditRecords;

    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      results = results.filter(
        (record) =>
          record.styleNumber.toLowerCase().includes(term) ||
          record.styleName.toLowerCase().includes(term) ||
          record.poNumber.toLowerCase().includes(term) ||
          record.buyerName.toLowerCase().includes(term) ||
          record.factoryName.toLowerCase().includes(term) ||
          record.auditorName.toLowerCase().includes(term)
      );
    }

    // Apply result filter
    if (filterBy !== "all") {
      results = results.filter((record) => record.result === filterBy);
    }

    // Apply sorting
    results.sort((a, b) => {
      if (sortBy === "recent") {
        return new Date(b.auditDate).getTime() - new Date(a.auditDate).getTime();
      } else if (sortBy === "score") {
        return b.qualityScore - a.qualityScore;
      } else if (sortBy === "defects") {
        return a.totalDefects - b.totalDefects;
      }
      return 0;
    });

    return results;
  }, [searchTerm, filterBy, sortBy, auditRecords]);

  const stats = {
    total: auditRecords.length,
    passed: auditRecords.filter((r) => r.result === "pass").length,
    failed: auditRecords.filter((r) => r.result === "fail").length,
    conditional: auditRecords.filter((r) => r.result === "conditional").length,
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-blue-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link
                to="/"
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900"
              >
                <ArrowLeft className="w-5 h-5" />
                Dashboard
              </Link>
              <div className="border-l border-blue-300 pl-4">
                <h1 className="text-2xl font-bold text-slate-900">
                  Audit History
                </h1>
                <p className="text-sm text-slate-600">
                  Search and filter previous inspection reports
                </p>
              </div>
            </div>
            <UserProfile />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-32">
        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg p-4 border border-blue-200 shadow-sm">
            <p className="text-sm text-slate-600 mb-1">Total Audits</p>
            <p className="text-3xl font-bold text-blue-600">{stats.total}</p>
          </div>
          <div className="bg-white rounded-lg p-4 border border-green-200 shadow-sm">
            <p className="text-sm text-slate-600 mb-1">Passed</p>
            <p className="text-3xl font-bold text-green-600">{stats.passed}</p>
          </div>
          <div className="bg-white rounded-lg p-4 border border-yellow-200 shadow-sm">
            <p className="text-sm text-slate-600 mb-1">Conditional</p>
            <p className="text-3xl font-bold text-yellow-600">{stats.conditional}</p>
          </div>
          <div className="bg-white rounded-lg p-4 border border-red-200 shadow-sm">
            <p className="text-sm text-slate-600 mb-1">Failed</p>
            <p className="text-3xl font-bold text-red-600">{stats.failed}</p>
          </div>
        </div>

        {/* Search and Filter Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8 border border-blue-200">
          <div className="space-y-4">
            {/* Search Bar */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">
                Search Audits
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by style name, style number, PO number, or buyer name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border-2 border-blue-200 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition"
                />
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Found {filteredRecords.length} results
              </p>
            </div>

            {/* Filters and Sort */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  <Filter className="inline w-4 h-4 mr-2" />
                  Filter by Result
                </label>
                <select
                  value={filterBy}
                  onChange={(e) =>
                    setFilterBy(
                      e.target.value as typeof filterBy
                    )
                  }
                  className="w-full px-4 py-2 border-2 border-blue-200 rounded-lg focus:outline-none focus:border-blue-500 bg-white"
                >
                  <option value="all">All Results</option>
                  <option value="pass">✓ Passed</option>
                  <option value="conditional">⚠ Conditional</option>
                  <option value="fail">✗ Failed</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-900 mb-2">
                  Sort by
                </label>
                <select
                  value={sortBy}
                  onChange={(e) =>
                    setSortBy(e.target.value as typeof sortBy)
                  }
                  className="w-full px-4 py-2 border-2 border-blue-200 rounded-lg focus:outline-none focus:border-blue-500 bg-white"
                >
                  <option value="recent">Most Recent</option>
                  <option value="score">Highest Quality Score</option>
                  <option value="defects">Fewest Defects</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Audit Records List */}
        {filteredRecords.length === 0 ? (
          <div className="bg-white rounded-lg border-2 border-dashed border-slate-300 p-12 text-center">
            <Search className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-slate-900 mb-2">
              {auditRecords.length === 0 ? "No audits yet" : "No audits found"}
            </h2>
            <p className="text-slate-600 mb-6">
              {auditRecords.length === 0 
                ? "Create your first audit to see it here" 
                : "Try adjusting your search or filters"}
            </p>
            {auditRecords.length === 0 ? (
              <Link
                to="/audit/new"
                className="inline-block px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
              >
                Create First Audit
              </Link>
            ) : (
              <button
                onClick={() => {
                  setSearchTerm("");
                  setFilterBy("all");
                }}
                className="inline-block px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredRecords.map((record) => (
              <Link
                key={record.id}
                to={`/audit/report/${record.id}`}
                className="block bg-white rounded-lg border border-blue-200 hover:border-blue-400 hover:shadow-md transition-all p-6"
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  {/* Left Section */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start gap-3 mb-3">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-slate-900 truncate">
                          {record.styleNumber} - {record.styleName}
                        </h3>
                        <p className="text-sm text-slate-600 mt-1">
                          PO: {record.poNumber}
                        </p>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-sm font-semibold whitespace-nowrap ${
                          record.result === "pass"
                            ? "bg-green-100 text-green-800 flex items-center gap-1"
                            : record.result === "fail"
                              ? "bg-red-100 text-red-800 flex items-center gap-1"
                              : "bg-yellow-100 text-yellow-800 flex items-center gap-1"
                        }`}
                      >
                        {record.result === "pass" && (
                          <CheckCircle2 className="w-4 h-4" />
                        )}
                        {record.result === "fail" && (
                          <AlertCircle className="w-4 h-4" />
                        )}
                        {record.result === "conditional" && (
                          <Zap className="w-4 h-4" />
                        )}
                        {record.result === "pass"
                          ? "Passed"
                          : record.result === "fail"
                            ? "Failed"
                            : "Conditional"}
                      </div>
                    </div>

                    {/* Details Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
                      <div>
                        <p className="text-slate-600 text-xs mb-1">Buyer</p>
                        <p className="font-medium text-slate-900">
                          {record.buyerName}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-600 text-xs mb-1">Factory</p>
                        <p className="font-medium text-slate-900 truncate">
                          {record.factoryName}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-600 text-xs mb-1">Auditor</p>
                        <p className="font-medium text-slate-900">
                          {record.auditorName}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-600 text-xs mb-1">Date</p>
                        <p className="font-medium text-slate-900 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(record.auditDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Right Section - Metrics */}
                  <div className="flex items-end gap-6 sm:border-l sm:border-blue-200 sm:pl-6">
                    <div className="text-center">
                      <p className="text-xs text-slate-600 mb-1">
                        Quality Score
                      </p>
                      <p className="text-2xl font-bold text-blue-600">
                        {record.qualityScore}%
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-slate-600 mb-1">Defects</p>
                      <p className="text-2xl font-bold text-purple-600">
                        {record.totalDefects}
                      </p>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
