import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, TrendingUp, Award, Target } from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const auditorStats = [
  { name: "Auditor 1", audits: 45, passRate: 94, defectsFound: 142, avgTime: 2.1 },
  { name: "Auditor 2", audits: 38, passRate: 88, defectsFound: 156, avgTime: 2.4 },
  { name: "Auditor 3", audits: 52, passRate: 91, defectsFound: 168, avgTime: 1.9 },
  { name: "Auditor 4", audits: 41, passRate: 86, defectsFound: 178, avgTime: 2.3 },
  { name: "Auditor 5", audits: 48, passRate: 93, defectsFound: 145, avgTime: 2.0 },
];

const monthlyTrend = [
  { month: "Jan", audits: 12, passRate: 92 },
  { month: "Feb", audits: 15, passRate: 89 },
  { month: "Mar", audits: 18, passRate: 91 },
  { month: "Apr", audits: 14, passRate: 88 },
  { month: "May", audits: 16, passRate: 93 },
];

const defectTrend = [
  { week: "W1", defects: 28, critical: 2, major: 12, minor: 14 },
  { week: "W2", defects: 32, critical: 3, major: 14, minor: 15 },
  { week: "W3", defects: 24, critical: 1, major: 10, minor: 13 },
  { week: "W4", defects: 29, critical: 2, major: 13, minor: 14 },
];

const selectedAuditor = {
  id: 1,
  name: "Auditor 1",
  photo: "👤",
  email: "auditor1@company.com",
  phone: "+91 98765-43210",
  totalInspections: 45,
  totalShipments: 42,
  totalOrders: 156,
  totalPieces: 4250,
  passReports: 40,
  failReports: 5,
  conditionalApprovals: 0,
  totalDefects: 142,
  avgDuration: "2.1 hours",
  passRate: 94,
  failureRate: 6,
  scorecard: {
    volume: 88,
    accuracy: 94,
    compliance: 96,
    timeliness: 92,
    satisfaction: 89,
  },
};

const factoryPerformance = [
  { factory: "Factory A", audits: 12, passRate: 95 },
  { factory: "Factory B", audits: 8, passRate: 88 },
  { factory: "Factory C", audits: 15, passRate: 92 },
  { factory: "Factory D", audits: 10, passRate: 90 },
];

export default function AuditorPerformance() {
  const [selectedAuditorId, setSelectedAuditorId] = useState(1);

  const selectedData = selectedAuditorId === 1 ? selectedAuditor : auditorStats[selectedAuditorId - 1];

  const scoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-blue-600";
    return "text-orange-600";
  };

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-orange-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <Link
              to="/analytics"
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">
              Auditor Performance Dashboard
            </h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Auditor List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg border border-orange-200 p-6 sticky top-24">
              <h2 className="text-lg font-bold text-slate-900 mb-4">
                Auditors Ranking
              </h2>
              <div className="space-y-2">
                {auditorStats.map((auditor, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedAuditorId(idx + 1)}
                    className={`w-full text-left px-4 py-3 rounded-lg transition ${
                      selectedAuditorId === idx + 1
                        ? "bg-blue-600 text-white"
                        : "bg-slate-50 text-slate-700 hover:bg-slate-100"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold">{idx + 1}. {auditor.name}</p>
                        <p className="text-xs opacity-75">{auditor.audits} audits</p>
                      </div>
                      <Award className="w-4 h-4" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Details & Analytics */}
          <div className="lg:col-span-3 space-y-6">
            {/* Auditor Profile */}
            <div className="bg-white rounded-lg border border-orange-200 p-6">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-start gap-4">
                  <div className="text-6xl">👤</div>
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">
                      {selectedData.name}
                    </h2>
                    <p className="text-slate-600">Senior QA Auditor</p>
                    <p className="text-sm text-slate-600 mt-2">
                      📧 auditor@company.com
                    </p>
                    <p className="text-sm text-slate-600">📱 +91 98765-43210</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-blue-600">
                    {selectedData.passRate}%
                  </p>
                  <p className="text-sm text-slate-600">Pass Rate</p>
                </div>
              </div>
            </div>

            {/* Summary Metrics */}
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-300 rounded-lg p-6">
                <p className="text-sm text-blue-700 mb-2">Total Inspections</p>
                <p className="text-3xl font-bold text-blue-900">
                  {selectedData.audits}
                </p>
              </div>
              <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-300 rounded-lg p-6">
                <p className="text-sm text-green-700 mb-2">Defects Found</p>
                <p className="text-3xl font-bold text-green-900">
                  {selectedData.defectsFound}
                </p>
              </div>
              <div className="bg-gradient-to-br from-orange-50 to-orange-100 border border-orange-300 rounded-lg p-6">
                <p className="text-sm text-orange-700 mb-2">Avg Duration</p>
                <p className="text-3xl font-bold text-orange-900">
                  {selectedData.avgTime}h
                </p>
              </div>
            </div>

            {/* Performance Charts */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Monthly Trend */}
              <div className="bg-white rounded-lg border border-orange-200 p-6">
                <h3 className="text-lg font-bold text-slate-900 mb-4">
                  Monthly Audit Trend
                </h3>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={monthlyTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="audits"
                      stroke="#2563eb"
                      strokeWidth={2}
                    />
                    <Line
                      type="monotone"
                      dataKey="passRate"
                      stroke="#10b981"
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Defect Trend */}
              <div className="bg-white rounded-lg border border-orange-200 p-6">
                <h3 className="text-lg font-bold text-slate-900 mb-4">
                  Defect Detection Trend
                </h3>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={defectTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="critical" fill="#dc2626" />
                    <Bar dataKey="major" fill="#f97316" />
                    <Bar dataKey="minor" fill="#f59e0b" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Performance Scorecard */}
            <div className="bg-white rounded-lg border border-orange-200 p-6">
              <h2 className="text-lg font-bold text-slate-900 mb-4">
                Performance Scorecard
              </h2>
              <div className="space-y-4">
                {Object.entries(selectedAuditor.scorecard).map(([key, value]) => (
                  <div key={key}>
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-sm font-medium text-slate-700 capitalize">
                        {key.replace(/([A-Z])/g, " $1")}
                      </label>
                      <span className={`text-lg font-bold ${scoreColor(value)}`}>
                        {value}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-blue-600 to-green-500 h-2 rounded-full"
                        style={{ width: `${value}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Factory Performance */}
            <div className="bg-white rounded-lg border border-orange-200 p-6">
              <h2 className="text-lg font-bold text-slate-900 mb-4">
                Factory-wise Performance
              </h2>
              <div className="space-y-3">
                {factoryPerformance.map((factory, idx) => (
                  <div key={idx} className="p-4 border border-orange-100 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <p className="font-medium text-slate-900">{factory.factory}</p>
                      <span className="text-sm font-bold text-blue-600">
                        {factory.passRate}%
                      </span>
                    </div>
                    <div className="flex gap-2 text-xs text-slate-600">
                      <span>{factory.audits} audits</span>
                      <span>•</span>
                      <span>Pass Rate: {factory.passRate}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
