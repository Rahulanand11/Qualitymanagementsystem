import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { UserProfile } from "@/components/UserProfile";
import {
  Menu,
  X,
  LogOut,
  BarChart3,
  FileText,
  CheckCircle2,
  AlertCircle,
  Clock,
  TrendingUp,
  Package,
  AlertTriangle,
  Eye,
  Download,
  Bell,
} from "lucide-react";

export default function BuyerPortal() {
  const { logout, user } = useAuth();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [notificationCount, setNotificationCount] = useState(3);

  // Mock data - in production, fetch from API
  const buyerStats = {
    totalPOs: 24,
    activeOrders: 8,
    totalInspections: 156,
    pendingInspections: 5,
    completedInspections: 148,
    approvedReports: 140,
    rejectedReports: 8,
    readyToShip: 12,
    avgQualityScore: 94.2,
    criticalDefects: 3,
    pendingActions: 7,
  };

  const recentInspections = [
    {
      id: "INS-2024-001",
      poNumber: "PO-12345",
      styleNumber: "STY-001",
      factoryName: "Premium Garments",
      inspectionDate: "2024-01-15",
      result: "pass",
      qualityScore: 98,
      shipmentReady: true,
      status: "approved",
    },
    {
      id: "INS-2024-002",
      poNumber: "PO-12346",
      styleNumber: "STY-002",
      factoryName: "Quality Textiles",
      inspectionDate: "2024-01-14",
      result: "conditional",
      qualityScore: 85,
      shipmentReady: false,
      status: "pending_review",
    },
    {
      id: "INS-2024-003",
      poNumber: "PO-12347",
      styleNumber: "STY-003",
      factoryName: "Elite Manufacturing",
      inspectionDate: "2024-01-13",
      result: "pass",
      qualityScore: 96,
      shipmentReady: true,
      status: "approved",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo & Brand */}
            <div className="flex items-center gap-3">
              <img
                src="https://unyxstudio.com/wp-content/uploads/2025/09/UNYX-3-e1757072083992.png"
                alt="UNYX"
                className="h-8"
              />
              <div className="hidden sm:block border-l border-slate-300 pl-3">
                <p className="text-sm font-semibold text-slate-900">Buyer Portal</p>
                <p className="text-xs text-slate-600">{user?.companyName || "Buyer Company"}</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              <Link
                to="/buyer/dashboard"
                className="text-slate-700 hover:text-slate-900 font-medium text-sm"
              >
                Dashboard
              </Link>
              <Link
                to="/buyer/reports"
                className="text-slate-700 hover:text-slate-900 font-medium text-sm"
              >
                Reports
              </Link>
              <Link
                to="/buyer/shipments"
                className="text-slate-700 hover:text-slate-900 font-medium text-sm"
              >
                Shipments
              </Link>
              <Link
                to="/buyer/analytics"
                className="text-slate-700 hover:text-slate-900 font-medium text-sm"
              >
                Analytics
              </Link>
            </div>

            {/* Right Section */}
            <div className="flex items-center gap-4">
              {/* Notifications */}
              <button className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition">
                <Bell className="w-5 h-5" />
                {notificationCount > 0 && (
                  <span className="absolute top-1 right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {notificationCount}
                  </span>
                )}
              </button>

              {/* User Profile */}
              <UserProfile />

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden border-t border-slate-200 py-4 space-y-2">
              <Link
                to="/buyer/dashboard"
                className="block px-4 py-2 text-slate-700 hover:bg-slate-100 rounded-lg"
              >
                Dashboard
              </Link>
              <Link
                to="/buyer/reports"
                className="block px-4 py-2 text-slate-700 hover:bg-slate-100 rounded-lg"
              >
                Reports
              </Link>
              <Link
                to="/buyer/shipments"
                className="block px-4 py-2 text-slate-700 hover:bg-slate-100 rounded-lg"
              >
                Shipments
              </Link>
              <Link
                to="/buyer/analytics"
                className="block px-4 py-2 text-slate-700 hover:bg-slate-100 rounded-lg"
              >
                Analytics
              </Link>
            </div>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-20">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Buyer Dashboard
          </h1>
          <p className="text-slate-600">
            Monitor quality performance across all your purchase orders
          </p>
        </div>

        {/* KPI Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* Total POs */}
          <KPICard
            label="Total Purchase Orders"
            value={buyerStats.totalPOs.toString()}
            icon={<Package className="w-8 h-8" />}
            color="blue"
            trend="+2 this month"
          />

          {/* Active Orders */}
          <KPICard
            label="Active Orders"
            value={buyerStats.activeOrders.toString()}
            icon={<Clock className="w-8 h-8" />}
            color="orange"
            trend="In production"
          />

          {/* Pending Inspections */}
          <KPICard
            label="Pending Inspections"
            value={buyerStats.pendingInspections.toString()}
            icon={<AlertCircle className="w-8 h-8" />}
            color="red"
            trend="Requires attention"
          />

          {/* Ready to Ship */}
          <KPICard
            label="Ready to Ship"
            value={buyerStats.readyToShip.toString()}
            icon={<CheckCircle2 className="w-8 h-8" />}
            color="green"
            trend={`${Math.round((buyerStats.readyToShip / buyerStats.totalPOs) * 100)}% of total`}
          />

          {/* Quality Score */}
          <KPICard
            label="Avg Quality Score"
            value={`${buyerStats.avgQualityScore}%`}
            icon={<TrendingUp className="w-8 h-8" />}
            color="purple"
            trend="Excellent"
          />

          {/* Critical Defects */}
          <KPICard
            label="Critical Defects"
            value={buyerStats.criticalDefects.toString()}
            icon={<AlertTriangle className="w-8 h-8" />}
            color="red"
            trend="Requires immediate action"
          />

          {/* Approved Reports */}
          <KPICard
            label="Approved Reports"
            value={buyerStats.approvedReports.toString()}
            icon={<CheckCircle2 className="w-8 h-8" />}
            color="green"
            trend={`${Math.round((buyerStats.approvedReports / buyerStats.totalInspections) * 100)}% approval rate`}
          />

          {/* Pending Actions */}
          <KPICard
            label="Pending Actions"
            value={buyerStats.pendingActions.toString()}
            icon={<FileText className="w-8 h-8" />}
            color="yellow"
            trend="Corrective actions"
          />
        </div>

        {/* Recent Inspections */}
        <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex justify-between items-center">
            <h2 className="text-xl font-bold text-slate-900">Recent Inspections</h2>
            <Link
              to="/buyer/reports"
              className="text-blue-600 hover:text-blue-700 font-medium text-sm flex items-center gap-2"
            >
              View All <Eye className="w-4 h-4" />
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Report ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    PO Number
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Factory
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Quality Score
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {recentInspections.map((inspection) => (
                  <tr
                    key={inspection.id}
                    className="hover:bg-slate-50 transition"
                  >
                    <td className="px-6 py-4 font-medium text-slate-900">
                      {inspection.id}
                    </td>
                    <td className="px-6 py-4 text-slate-700">
                      {inspection.poNumber}
                    </td>
                    <td className="px-6 py-4 text-slate-700">
                      {inspection.factoryName}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-slate-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              inspection.qualityScore >= 90
                                ? "bg-green-500"
                                : inspection.qualityScore >= 80
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                            style={{
                              width: `${inspection.qualityScore}%`,
                            }}
                          />
                        </div>
                        <span className="font-semibold text-slate-900">
                          {inspection.qualityScore}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          inspection.status === "approved"
                            ? "bg-green-100 text-green-800"
                            : inspection.status === "pending_review"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-slate-100 text-slate-800"
                        }`}
                      >
                        {inspection.status === "approved"
                          ? "✓ Approved"
                          : inspection.status === "pending_review"
                            ? "Pending Review"
                            : "Review"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="text-slate-600 hover:text-slate-900 font-medium text-sm">
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Session Footer */}
      <footer className="fixed bottom-0 left-0 right-0 bg-slate-900 text-white border-t border-slate-700 py-3">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <p className="text-sm text-slate-400">
            Logged in as: <span className="font-semibold">{user?.fullName}</span> (Buyer)
          </p>
          <button
            onClick={() => {
              logout();
              navigate("/login", { replace: true });
            }}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg transition font-medium text-sm"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </footer>
    </div>
  );
}

function KPICard({
  label,
  value,
  icon,
  color,
  trend,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  color: "blue" | "orange" | "red" | "green" | "purple" | "yellow";
  trend: string;
}) {
  const colorClasses = {
    blue: "from-blue-50 to-blue-50 border-blue-200 text-blue-600",
    orange: "from-orange-50 to-orange-50 border-orange-200 text-orange-600",
    red: "from-red-50 to-red-50 border-red-200 text-red-600",
    green: "from-green-50 to-green-50 border-green-200 text-green-600",
    purple: "from-purple-50 to-purple-50 border-purple-200 text-purple-600",
    yellow: "from-yellow-50 to-yellow-50 border-yellow-200 text-yellow-600",
  };

  return (
    <div
      className={`bg-gradient-to-br ${colorClasses[color]} border rounded-lg p-6 shadow-sm hover:shadow-md transition`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="text-3xl font-bold text-slate-900">{value}</div>
        <div className="opacity-50">{icon}</div>
      </div>
      <p className="text-sm font-medium text-slate-700 mb-1">{label}</p>
      <p className="text-xs text-slate-600">{trend}</p>
    </div>
  );
}
