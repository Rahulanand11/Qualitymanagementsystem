import React, { useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Search, Calendar, TrendingUp, Filter } from "lucide-react";
import { UserProfile } from "@/components/UserProfile";
import { AIInspectionSummaryDisplay } from "@/components/AIInspectionSummaryDisplay";
import { AIInspectionSummary } from "@/services/AIInspectionSummary";

interface AnalyzedInspection {
  id: string;
  auditId: string;
  auditorName: string;
  factoryName: string;
  styleNumber: string;
  date: string;
  summary: AIInspectionSummary;
}

export default function AIAssistant() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedInspection, setSelectedInspection] =
    useState<AnalyzedInspection | null>(null);
  const [filterResult, setFilterResult] = useState<
    "all" | "pass" | "conditional" | "fail"
  >("all");

  // Mock data - in production, this would come from an API
  const analyzedInspections: AnalyzedInspection[] = [
    {
      id: "1",
      auditId: "AUD-001",
      auditorName: "John Smith",
      factoryName: "Premium Garments Ltd",
      styleNumber: "STY-2024-001",
      date: "2024-01-15",
      summary: {
        overallResult: "Pass",
        executiveSummary:
          "Final inspection completed successfully. All critical requirements met. Minor defects identified in seaming but within acceptable limits.",
        keyFindings: [
          "All measurements within tolerance",
          "Sewing quality meets standards",
          "Color consistency verified",
          "2 minor defects in packaging",
        ],
        defectAnalysis: {
          critical: { count: 0, description: "No critical defects found" },
          major: { count: 0, description: "No major defects identified" },
          minor: {
            count: 2,
            description:
              "Minor defects found in packaging and labeling",
          },
        },
        measurementAnalysis: {
          checked: 24,
          withinTolerance: 24,
          outsideTolerance: 0,
          largestDeviation: 0.5,
          averageDeviation: 0.15,
        },
        rootCauses: [
          {
            defect: "Packaging defect",
            cause: "Manual handling",
            likelihood: "Low",
          },
        ],
        correctiveActions: [
          {
            action: "Review packaging procedures with warehouse team",
            priority: "Low",
          },
        ],
        shipmentRiskAssessment: {
          riskLevel: "Low",
          confidence: 98,
          reasoning: "All critical parameters within spec",
        },
        qualityScore: {
          score: 98,
          rating: "Excellent",
          breakdown: { defects: 25, measurements: 40, efficiency: 33 },
        },
        generatedAt: new Date().toISOString(),
      },
    },
    {
      id: "2",
      auditId: "AUD-002",
      auditorName: "Sarah Johnson",
      factoryName: "Quality Textiles Inc",
      styleNumber: "STY-2024-002",
      date: "2024-01-14",
      summary: {
        overallResult: "Conditional Pass",
        executiveSummary:
          "Inspection shows acceptable quality with some rework required on color matching. Core structural integrity is sound.",
        keyFindings: [
          "Color variance exceeds tolerance in 3 pieces",
          "Seam strength acceptable",
          "Measurement accuracy good",
          "Rework required on color",
        ],
        defectAnalysis: {
          critical: { count: 0, description: "No critical defects" },
          major: { count: 3, description: "Color matching issues" },
          minor: { count: 5, description: "Minor surface defects" },
        },
        measurementAnalysis: {
          checked: 30,
          withinTolerance: 28,
          outsideTolerance: 2,
          largestDeviation: 1.2,
          averageDeviation: 0.4,
        },
        rootCauses: [
          {
            defect: "Color variance",
            cause: "Dye batch variation",
            likelihood: "High",
          },
        ],
        correctiveActions: [
          {
            action: "Implement stricter color control procedures",
            priority: "High",
          },
          { action: "Rework pieces with color variance", priority: "High" },
        ],
        shipmentRiskAssessment: {
          riskLevel: "Medium",
          confidence: 85,
          reasoning: "Conditional on rework completion",
        },
        qualityScore: {
          score: 82,
          rating: "Good",
          breakdown: { defects: 30, measurements: 35, efficiency: 35 },
        },
        generatedAt: new Date(Date.now() - 86400000).toISOString(),
      },
    },
  ];

  const filteredInspections = useMemo(() => {
    return analyzedInspections.filter((inspection) => {
      const matchesSearch =
        inspection.auditorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inspection.factoryName
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        inspection.styleNumber
          .toLowerCase()
          .includes(searchTerm.toLowerCase());

      const matchesFilter =
        filterResult === "all" ||
        (filterResult === "pass" &&
          inspection.summary.overallResult === "Pass") ||
        (filterResult === "conditional" &&
          inspection.summary.overallResult === "Conditional Pass") ||
        (filterResult === "fail" &&
          inspection.summary.overallResult === "Fail");

      return matchesSearch && matchesFilter;
    });
  }, [searchTerm, filterResult]);

  const stats = {
    totalAnalyzed: analyzedInspections.length,
    passRate: (
      (analyzedInspections.filter(
        (i) => i.summary.overallResult === "Pass"
      ).length /
        analyzedInspections.length) *
      100
    ).toFixed(0),
    avgScore: (
      analyzedInspections.reduce(
        (sum, i) => sum + i.summary.qualityScore.score,
        0
      ) / analyzedInspections.length
    ).toFixed(0),
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-purple-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link
                to="/"
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900"
              >
                <ArrowLeft className="w-5 h-5" />
                Back
              </Link>
              <div className="border-l border-purple-300 pl-4">
                <h1 className="text-lg font-bold text-slate-900">
                  AI Inspection Assistant
                </h1>
                <p className="text-xs text-slate-600">
                  Auto-generated summaries and analysis
                </p>
              </div>
            </div>
            <UserProfile />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {selectedInspection ? (
          // Detail View
          <div>
            <button
              onClick={() => setSelectedInspection(null)}
              className="flex items-center gap-2 text-purple-600 hover:text-purple-700 mb-6 font-medium"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to List
            </button>

            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">
                {selectedInspection.styleNumber}
              </h2>
              <p className="text-slate-600">
                {selectedInspection.factoryName} • {selectedInspection.auditorName}
              </p>
            </div>

            <AIInspectionSummaryDisplay
              summary={selectedInspection.summary}
              onExport={(format) => {
                if (format === "pdf") {
                  alert("PDF export would be generated here");
                } else {
                  const json = JSON.stringify(
                    selectedInspection.summary,
                    null,
                    2
                  );
                  const blob = new Blob([json], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = `summary-${selectedInspection.auditId}.json`;
                  a.click();
                }
              }}
            />
          </div>
        ) : (
          // List View
          <div>
            {/* Stats */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="bg-gradient-to-br from-purple-100 to-purple-50 rounded-lg p-6 border border-purple-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-700 font-medium mb-1">
                      Total Analyzed
                    </p>
                    <p className="text-3xl font-bold text-purple-900">
                      {stats.totalAnalyzed}
                    </p>
                  </div>
                  <TrendingUp className="w-12 h-12 text-purple-300" />
                </div>
              </div>

              <div className="bg-gradient-to-br from-green-100 to-green-50 rounded-lg p-6 border border-green-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-700 font-medium mb-1">
                      Pass Rate
                    </p>
                    <p className="text-3xl font-bold text-green-900">
                      {stats.passRate}%
                    </p>
                  </div>
                  <TrendingUp className="w-12 h-12 text-green-300" />
                </div>
              </div>

              <div className="bg-gradient-to-br from-blue-100 to-blue-50 rounded-lg p-6 border border-blue-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-700 font-medium mb-1">
                      Avg Quality Score
                    </p>
                    <p className="text-3xl font-bold text-blue-900">
                      {stats.avgScore}%
                    </p>
                  </div>
                  <TrendingUp className="w-12 h-12 text-blue-300" />
                </div>
              </div>
            </div>

            {/* Search and Filter */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Search
                  </label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search by auditor, factory, or style..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Result
                  </label>
                  <select
                    value={filterResult}
                    onChange={(e) =>
                      setFilterResult(
                        e.target.value as typeof filterResult
                      )
                    }
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="all">All Results</option>
                    <option value="pass">Pass</option>
                    <option value="conditional">Conditional</option>
                    <option value="fail">Fail</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Inspections List */}
            <div className="space-y-4">
              {filteredInspections.length === 0 ? (
                <div className="bg-white rounded-lg p-12 text-center border-2 border-dashed border-gray-300">
                  <p className="text-gray-600">
                    No inspections match your search criteria
                  </p>
                </div>
              ) : (
                filteredInspections.map((inspection) => (
                  <div
                    key={inspection.id}
                    onClick={() => setSelectedInspection(inspection)}
                    className="bg-white rounded-lg shadow-sm hover:shadow-md transition-all cursor-pointer border border-gray-200 p-6"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-slate-900">
                          {inspection.styleNumber}
                        </h3>
                        <p className="text-sm text-slate-600">
                          {inspection.factoryName}
                        </p>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-sm font-semibold ${
                          inspection.summary.overallResult === "Pass"
                            ? "bg-green-100 text-green-800"
                            : inspection.summary.overallResult ===
                                "Conditional Pass"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-red-100 text-red-800"
                        }`}
                      >
                        {inspection.summary.overallResult}
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-gray-600 mb-1">
                          Quality Score
                        </p>
                        <p className="text-xl font-bold text-blue-600">
                          {inspection.summary.qualityScore.score}%
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Defects</p>
                        <p className="text-xl font-bold text-purple-600">
                          {inspection.summary.defectAnalysis.critical.count +
                            inspection.summary.defectAnalysis.major.count +
                            inspection.summary.defectAnalysis.minor.count}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600 mb-1">
                          Auditor
                        </p>
                        <p className="text-sm font-medium text-slate-900">
                          {inspection.auditorName}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Date</p>
                        <p className="text-sm font-medium text-slate-900">
                          {new Date(inspection.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>

                    <p className="text-sm text-slate-600 line-clamp-2">
                      {inspection.summary.executiveSummary}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
