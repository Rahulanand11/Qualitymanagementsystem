import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Download, Share2, CheckCircle2, AlertCircle, MapPin, Clock } from "lucide-react";

export default function AuditReport() {
  const { id } = useParams<{ id: string }>();
  const [auditData, setAuditData] = useState<any>(null);

  useEffect(() => {
    // Fetch audit from localStorage
    if (id) {
      const audits = localStorage.getItem("audits");
      if (audits) {
        const auditsList = JSON.parse(audits);
        const audit = auditsList.find((a: any) => a.id === id);
        if (audit) {
          setAuditData(audit);
        }
      }
    }

    // If not found in localStorage, use sample data
    if (!auditData) {
      setAuditData({
        id: id || "AUDIT-2024-001",
        auditorName: "John Smith",
        auditorEmail: "john.smith@company.com",
        auditorPhone: "+91 98765-43210",
        auditDate: new Date().toISOString().split("T")[0],
        inspectionTime: "10:30 AM - 2:45 PM",
        factoryName: "Factory A - Noida",
        supplierName: "ABC Suppliers",
        styleNumber: "ST-2024-001",
        poNumber: "PO-123456",
        inspectionQuantity: "50",
        passStatus: "PASSED",
        gpsLatitude: "28.5355",
        gpsLongitude: "77.3910",
        verificationStatus: "Verified",
        totalDefects: 3,
        majorDefects: 1,
        minorDefects: 2,
        sessionDuration: "00:45:30",
      });
    }
  }, [id, auditData]);

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-orange-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center mb-4">
            <Link
              to="/"
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
            >
              <ArrowLeft className="w-5 h-5" />
              Back
            </Link>
            <h1 className="text-2xl font-bold text-slate-900">Audit Report</h1>
            <div className="flex gap-2">
              <button className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-100 transition">
                <Download className="w-4 h-4" /> Download PDF
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-100 transition">
                <Share2 className="w-4 h-4" /> Share
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Report Container */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          {/* Header Section */}
          <div className="bg-gradient-to-r from-blue-600 to-orange-500 text-white p-8">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-3xl font-bold">Garment Final Audit Report</h2>
                <p className="text-blue-100 mt-1">Audit ID: {auditData.auditId}</p>
              </div>
              <div className="text-right">
                <div className="inline-block bg-white/20 backdrop-blur px-4 py-2 rounded-lg">
                  <p className="text-sm text-blue-100">Status</p>
                  <p className="text-2xl font-bold">
                    {auditData.passStatus === "PASSED" ? "✓ PASSED" : "✗ FAILED"}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Auditor Verification Section */}
          <div className="border-l-4 border-green-500 bg-green-50 p-8 m-6">
            <div className="flex items-start gap-4 mb-6">
              <CheckCircle2 className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-2xl font-bold text-slate-900 mb-1">
                  Auditor Verification Details
                </h3>
                <p className="text-green-700 font-semibold">
                  ✓ Auditor Identity Verified & GPS Location Confirmed
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
              {/* Auditor Information */}
              <div>
                <h4 className="text-lg font-semibold text-slate-900 mb-4">
                  Auditor Information
                </h4>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-slate-600">Auditor Name</p>
                    <p className="font-semibold text-slate-900">
                      {auditData.auditorName}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Email</p>
                    <p className="font-semibold text-slate-900">
                      {auditData.auditorEmail}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Phone</p>
                    <p className="font-semibold text-slate-900">
                      {auditData.auditorPhone}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Employee ID</p>
                    <p className="font-semibold text-slate-900">EMP-2024-001</p>
                  </div>
                </div>

                {/* Auditor Photo Placeholder */}
                <div className="mt-6 border-2 border-dashed border-slate-300 rounded-lg p-4 aspect-square flex items-center justify-center bg-slate-100">
                  <div className="text-center">
                    <p className="text-sm text-slate-600 font-medium">Auditor Photo</p>
                    <p className="text-xs text-slate-500 mt-1">[Photo Attached]</p>
                  </div>
                </div>
              </div>

              {/* GPS & Location Information */}
              <div>
                <h4 className="text-lg font-semibold text-slate-900 mb-4">
                  GPS & Location Verification
                </h4>
                <div className="space-y-3 mb-6">
                  <div>
                    <p className="text-sm text-slate-600">Inspection Start Time</p>
                    <p className="font-semibold text-slate-900">
                      {auditData.auditDate} - {auditData.inspectionTime.split(" - ")[0]}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Inspection End Time</p>
                    <p className="font-semibold text-slate-900">
                      {auditData.auditDate} - {auditData.inspectionTime.split(" - ")[1]}
                    </p>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="text-sm text-slate-600">Session Duration</p>
                        <p className="font-bold text-blue-600 font-mono text-lg">
                          {auditData.sessionDuration || "N/A"}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Factory Location</p>
                    <p className="font-semibold text-slate-900">
                      {auditData.factoryName}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">GPS Coordinates</p>
                    <p className="font-semibold text-slate-900">
                      <MapPin className="w-4 h-4 inline mr-1" />
                      {auditData.gpsLatitude}, {auditData.gpsLongitude}
                    </p>
                  </div>
                  <div className="pt-3 border-t border-green-200">
                    <p className="text-sm text-slate-600">Verification Status</p>
                    <div className="flex items-center gap-2 mt-1">
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                      <p className="font-semibold text-green-700">
                        {auditData.verificationStatus}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Map Placeholder */}
                <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 aspect-square flex items-center justify-center bg-slate-100">
                  <div className="text-center">
                    <MapPin className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm text-slate-600 font-medium">Map Preview</p>
                    <p className="text-xs text-slate-500 mt-1">[Interactive Map]</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Inspection Details */}
          <div className="p-8 border-t border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">
              Inspection Details
            </h3>
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <div>
                <p className="text-sm text-slate-600 mb-1">Factory Name</p>
                <p className="font-semibold text-slate-900">
                  {auditData.factoryName}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Supplier Name</p>
                <p className="font-semibold text-slate-900">
                  {auditData.supplierName}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Style Number</p>
                <p className="font-semibold text-slate-900">
                  {auditData.styleNumber}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">PO Number</p>
                <p className="font-semibold text-slate-900">
                  {auditData.poNumber}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Pieces Inspected</p>
                <p className="font-semibold text-slate-900">
                  {auditData.inspectionQuantity}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Audit Date</p>
                <p className="font-semibold text-slate-900">
                  {auditData.auditDate}
                </p>
              </div>
            </div>
          </div>

          {/* Defect Summary */}
          <div className="p-8 border-t border-slate-200 bg-orange-50">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">
              Defect Summary
            </h3>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="bg-white rounded-lg p-4 border border-orange-200">
                <p className="text-sm text-slate-600 mb-1">Total Defects</p>
                <p className="text-3xl font-bold text-slate-900">
                  {auditData.totalDefects}
                </p>
              </div>
              <div className="bg-white rounded-lg p-4 border border-red-200">
                <p className="text-sm text-slate-600 mb-1">Major Defects</p>
                <p className="text-3xl font-bold text-red-600">
                  {auditData.majorDefects}
                </p>
              </div>
              <div className="bg-white rounded-lg p-4 border border-yellow-200">
                <p className="text-sm text-slate-600 mb-1">Minor Defects</p>
                <p className="text-3xl font-bold text-yellow-600">
                  {auditData.minorDefects}
                </p>
              </div>
              <div className="bg-white rounded-lg p-4 border border-green-200">
                <p className="text-sm text-slate-600 mb-1">Defect Rate</p>
                <p className="text-3xl font-bold text-green-600">6%</p>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-8 border-t border-slate-200 bg-gradient-to-r from-slate-50 to-orange-50">
            <p className="text-sm text-slate-600 mb-4">
              This report was automatically generated on {new Date().toLocaleDateString()} and
              contains verified auditor information and GPS-confirmed inspection location data.
            </p>
            <div className="flex gap-4">
              <div className="flex-1">
                <p className="text-xs text-slate-600 mb-1">Auditor Signature</p>
                <div className="border-t-2 border-slate-300 pt-2">
                  <p className="text-xs text-slate-600">[Signature Here]</p>
                </div>
              </div>
              <div className="flex-1">
                <p className="text-xs text-slate-600 mb-1">QA Manager Signature</p>
                <div className="border-t-2 border-slate-300 pt-2">
                  <p className="text-xs text-slate-600">[Signature Here]</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
