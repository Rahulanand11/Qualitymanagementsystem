import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface AuthContextType {
  isLoggedIn: boolean;
  user: {
    email: string;
    fullName?: string;
    profilePicture?: string;
    role: "auditor" | "buyer" | "admin" | "manager";
    companyName?: string;
    buyerId?: string;
  } | null;
  login: (email: string, password: string, fullName?: string, role?: string) => void;
  logout: () => void;
  sessionStartTime: number | null;
  sessionDuration: string;
  userRole: "auditor" | "buyer" | "admin" | "manager" | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    try {
      const storedAuth = localStorage.getItem("auth");
      if (storedAuth) {
        const authData = JSON.parse(storedAuth);
        return authData.isLoggedIn || false;
      }
    } catch (error) {
      console.error("Failed to restore auth from localStorage:", error);
    }
    return false;
  });

  const [user, setUser] = useState<{
    email: string;
    fullName?: string;
    role?: "auditor" | "buyer" | "admin" | "manager";
    companyName?: string;
    buyerId?: string;
  } | null>(() => {
    try {
      const storedAuth = localStorage.getItem("auth");
      if (storedAuth) {
        const authData = JSON.parse(storedAuth);
        return authData.user || null;
      }
    } catch (error) {
      console.error("Failed to restore auth from localStorage:", error);
    }
    return null;
  });

  const [sessionStartTime, setSessionStartTime] = useState<number | null>(() => {
    try {
      const storedAuth = localStorage.getItem("auth");
      if (storedAuth) {
        const authData = JSON.parse(storedAuth);
        if (authData.isLoggedIn && authData.sessionStartTime) {
          return authData.sessionStartTime;
        }
      }
    } catch (error) {
      console.error("Failed to restore session time from localStorage:", error);
    }
    return null;
  });

  const [sessionDuration, setSessionDuration] = useState("00:00:00");

  // Update session duration every second
  useEffect(() => {
    if (!isLoggedIn || !sessionStartTime) {
      setSessionDuration("00:00:00");
      return;
    }

    const updateDuration = () => {
      const now = Date.now();
      const elapsedMs = now - sessionStartTime;
      const elapsedSeconds = Math.floor(elapsedMs / 1000);

      const hours = Math.floor(elapsedSeconds / 3600);
      const minutes = Math.floor((elapsedSeconds % 3600) / 60);
      const seconds = elapsedSeconds % 60;

      const formatted = `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
      setSessionDuration(formatted);
    };

    const interval = setInterval(updateDuration, 1000);
    updateDuration(); // Call once immediately

    return () => clearInterval(interval);
  }, [isLoggedIn, sessionStartTime]);

  const login = (email: string, password: string, fullName: string = "User", role: string = "auditor") => {
    const userData = {
      email,
      fullName,
      role: (role as "auditor" | "buyer" | "admin" | "manager") || "auditor",
      companyName: role === "buyer" ? "Buyer Company" : undefined,
      buyerId: role === "buyer" ? `BUYER-${Math.random().toString(36).substr(2, 9)}` : undefined,
    };
    const startTime = Date.now();

    setIsLoggedIn(true);
    setUser(userData);
    setSessionStartTime(startTime);

    localStorage.setItem(
      "auth",
      JSON.stringify({
        isLoggedIn: true,
        user: userData,
        sessionStartTime: startTime,
      })
    );
  };

  const logout = () => {
    setIsLoggedIn(false);
    setUser(null);
    setSessionStartTime(null);
    setSessionDuration("00:00:00");
    localStorage.removeItem("auth");
  };

  return (
    <AuthContext.Provider value={{
      isLoggedIn,
      user,
      login,
      logout,
      sessionStartTime,
      sessionDuration,
      userRole: user?.role || null,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
