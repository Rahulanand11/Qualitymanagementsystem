import { useState, useEffect } from "react";
import { Clock, User, Factory, FileText, CheckCircle2 } from "lucide-react";

interface Inspection {
  id: string;
  auditorName: string;
  factoryName: string;
  buyer: string;
  supplier: string;
  poNumber: string;
  styleNumber: string;
  inspectionStage: string;
  status: string;
  startTime: string;
  duration: string;
}

interface InspectionInfoPanelProps {
  inspection: Inspection;
}

export function InspectionInfoPanel({ inspection }: InspectionInfoPanelProps) {
  const [elapsedTime, setElapsedTime] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedTime((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 bg-gradient-to-r from-blue-500 to-orange-500 text-white border-b border-blue-700">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm">Active Inspection</h3>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-green-300 animate-pulse"></div>
            <span className="text-xs font-semibold">{inspection.status}</span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Inspection ID */}
        <div className="pb-4 border-b border-slate-100">
          <p className="text-xs text-slate-600 mb-1">Inspection ID</p>
          <p className="text-sm font-semibold text-slate-900">{inspection.id}</p>
        </div>

        {/* Auditor */}
        <div className="flex items-start gap-3">
          <User className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-slate-600">Auditor</p>
            <p className="text-sm font-medium text-slate-900">{inspection.auditorName}</p>
          </div>
        </div>

        {/* Factory */}
        <div className="flex items-start gap-3">
          <Factory className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-slate-600">Factory</p>
            <p className="text-sm font-medium text-slate-900">{inspection.factoryName}</p>
          </div>
        </div>

        {/* Buyer & Supplier */}
        <div className="grid grid-cols-2 gap-3 pb-3 border-b border-slate-100">
          <div>
            <p className="text-xs text-slate-600">Buyer</p>
            <p className="text-sm font-medium text-slate-900">{inspection.buyer}</p>
          </div>
          <div>
            <p className="text-xs text-slate-600">Supplier</p>
            <p className="text-sm font-medium text-slate-900">{inspection.supplier}</p>
          </div>
        </div>

        {/* PO & Style */}
        <div className="grid grid-cols-2 gap-3 pb-3 border-b border-slate-100">
          <div>
            <p className="text-xs text-slate-600">PO Number</p>
            <p className="text-sm font-semibold text-slate-900 truncate">{inspection.poNumber}</p>
          </div>
          <div>
            <p className="text-xs text-slate-600">Style Number</p>
            <p className="text-sm font-semibold text-slate-900 truncate">{inspection.styleNumber}</p>
          </div>
        </div>

        {/* Inspection Stage */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-xs text-blue-700 font-semibold mb-1">INSPECTION STAGE</p>
          <p className="text-sm text-blue-900 font-semibold">{inspection.inspectionStage}</p>
        </div>

        {/* Timing */}
        <div className="space-y-2 pb-3 border-b border-slate-100">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600">Start Time</span>
            <span className="font-semibold text-slate-900">{inspection.startTime}</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600 font-medium">Live Duration</span>
            <span className="font-bold text-blue-600 text-sm">
              {formatTime(elapsedTime)}
            </span>
          </div>
        </div>

        {/* Status Badge */}
        <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
          <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
          <span className="text-xs font-medium text-green-700">
            Inspection in progress - Camera monitoring active
          </span>
        </div>
      </div>
    </div>
  );
}
