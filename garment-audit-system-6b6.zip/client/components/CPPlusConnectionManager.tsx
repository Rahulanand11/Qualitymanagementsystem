import { useState } from "react";
import { X, Plus, Trash2, Check, AlertCircle, Zap, Clock } from "lucide-react";

interface NVRDevice {
  id: string;
  deviceName: string;
  ipAddress: string;
  port: number;
  username: string;
  protocol: "onvif" | "rtsp" | "api";
  status: "connected" | "disconnected" | "testing" | "error";
  lastConnected: string;
  totalChannels: number;
  activeChannels: number;
  streamType: "main" | "sub" | "both";
  connectionError?: string;
}

interface CPPlusConnectionManagerProps {
  devices: NVRDevice[];
  onClose: () => void;
  onSave: (devices: NVRDevice[]) => void;
}

export function CPPlusConnectionManager({
  devices,
  onClose,
  onSave,
}: CPPlusConnectionManagerProps) {
  const [formData, setFormData] = useState({
    deviceName: "",
    ipAddress: "",
    port: 8000,
    username: "admin",
    password: "",
    protocol: "onvif" as const,
    streamType: "both" as const,
  });

  const [testingDeviceId, setTestingDeviceId] = useState<string | null>(null);

  const handleTestConnection = async (deviceId: string) => {
    setTestingDeviceId(deviceId);

    // Simulate connection test - In production, this would call an API
    setTimeout(() => {
      const updatedDevices = devices.map((d) =>
        d.id === deviceId
          ? {
              ...d,
              status: "connected" as const,
              lastConnected: new Date().toLocaleString(),
            }
          : d
      );
      onSave(updatedDevices);
      setTestingDeviceId(null);
    }, 2000);
  };

  const handleAddDevice = () => {
    if (formData.deviceName && formData.ipAddress && formData.password) {
      const newDevice: NVRDevice = {
        id: `nvr-${Date.now()}`,
        deviceName: formData.deviceName,
        ipAddress: formData.ipAddress,
        port: formData.port,
        username: formData.username,
        protocol: formData.protocol,
        status: "disconnected",
        lastConnected: "Never",
        totalChannels: 16,
        activeChannels: 0,
        streamType: formData.streamType,
      };

      onSave([...devices, newDevice]);
      setFormData({
        deviceName: "",
        ipAddress: "",
        port: 8000,
        username: "admin",
        password: "",
        protocol: "onvif",
        streamType: "both",
      });
    }
  };

  const handleDeleteDevice = (id: string) => {
    onSave(devices.filter((d) => d.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "connected":
        return "bg-green-100 text-green-800 border-green-300";
      case "testing":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "error":
        return "bg-red-100 text-red-800 border-red-300";
      default:
        return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
        return <Check className="w-4 h-4 text-green-600" />;
      case "testing":
        return <Zap className="w-4 h-4 text-yellow-600 animate-pulse" />;
      case "error":
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Clock className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-slate-200 sticky top-0 bg-white">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">CP Plus NVR/DVR Setup</h2>
            <p className="text-sm text-slate-600 mt-1">
              Configure your CP Plus DVR/NVR devices for live camera streaming
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-600 hover:text-slate-900 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Add Device Form */}
          <div className="border-2 border-dashed border-blue-300 rounded-lg p-6 bg-blue-50">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <Plus className="w-5 h-5" /> Add CP Plus Device
            </h3>

            <div className="space-y-4">
              {/* Device Name */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Device Name
                </label>
                <input
                  type="text"
                  placeholder="e.g., Factory A - Main NVR"
                  value={formData.deviceName}
                  onChange={(e) =>
                    setFormData({ ...formData, deviceName: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* IP & Port */}
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    IP Address
                  </label>
                  <input
                    type="text"
                    placeholder="192.168.1.100"
                    value={formData.ipAddress}
                    onChange={(e) =>
                      setFormData({ ...formData, ipAddress: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Port
                  </label>
                  <input
                    type="number"
                    value={formData.port}
                    onChange={(e) =>
                      setFormData({ ...formData, port: parseInt(e.target.value) })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Protocol
                  </label>
                  <select
                    value={formData.protocol}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        protocol: e.target.value as any,
                      })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="onvif">ONVIF</option>
                    <option value="rtsp">RTSP</option>
                    <option value="api">CP Plus API</option>
                  </select>
                </div>
              </div>

              {/* Credentials */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Username
                  </label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) =>
                      setFormData({ ...formData, username: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) =>
                      setFormData({ ...formData, password: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Stream Type */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Stream Type
                </label>
                <div className="flex gap-4">
                  {["main", "sub", "both"].map((type) => (
                    <label key={type} className="flex items-center gap-2">
                      <input
                        type="radio"
                        checked={formData.streamType === type}
                        onChange={() =>
                          setFormData({
                            ...formData,
                            streamType: type as any,
                          })
                        }
                        className="w-4 h-4 text-blue-600"
                      />
                      <span className="text-sm text-slate-700 capitalize">
                        {type === "main"
                          ? "Main Stream (HD)"
                          : type === "sub"
                          ? "Sub Stream (SD)"
                          : "Both Streams"}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <button
                onClick={handleAddDevice}
                className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition flex items-center gap-2"
              >
                <Plus className="w-4 h-4" /> Add Device
              </button>
            </div>
          </div>

          {/* Device List */}
          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-4">
              Configured Devices ({devices.length})
            </h3>

            <div className="space-y-3">
              {devices.map((device) => (
                <div
                  key={device.id}
                  className="border border-slate-200 rounded-lg p-4 hover:border-slate-300 hover:shadow-md transition bg-white"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-slate-900">
                          {device.deviceName}
                        </h4>
                        <span
                          className={`flex items-center gap-1 px-3 py-1 text-xs rounded-full font-semibold border ${getStatusColor(device.status)}`}
                        >
                          {getStatusIcon(device.status)}
                          {device.status.charAt(0).toUpperCase() +
                            device.status.slice(1)}
                        </span>
                      </div>
                      <p className="text-sm text-slate-600">
                        {device.ipAddress}:{device.port} • {device.protocol.toUpperCase()}
                      </p>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <button
                        onClick={() => handleTestConnection(device.id)}
                        disabled={testingDeviceId === device.id}
                        className="px-4 py-2 text-sm font-medium bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-lg transition disabled:opacity-50"
                      >
                        {testingDeviceId === device.id ? "Testing..." : "Test"}
                      </button>
                      <button
                        onClick={() => handleDeleteDevice(device.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-3 text-xs">
                    <div>
                      <span className="text-slate-600">Stream Type</span>
                      <p className="font-semibold text-slate-900 capitalize">
                        {device.streamType}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-600">Total Channels</span>
                      <p className="font-semibold text-slate-900">
                        {device.totalChannels}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-600">Active</span>
                      <p className="font-semibold text-slate-900">
                        {device.activeChannels}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-600">Last Connected</span>
                      <p className="font-semibold text-slate-900 text-xs">
                        {device.lastConnected}
                      </p>
                    </div>
                  </div>

                  {device.connectionError && (
                    <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded text-xs text-red-700">
                      ⚠️ {device.connectionError}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {devices.length === 0 && (
              <div className="text-center py-8 text-slate-500">
                <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No devices configured yet. Add your first CP Plus device above.</p>
              </div>
            )}
          </div>

          {/* Integration Guide */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-semibold text-blue-900 mb-2">Integration Protocols</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>✓ <strong>ONVIF:</strong> Universal camera protocol (recommended)</li>
              <li>✓ <strong>RTSP:</strong> Real Time Streaming Protocol for live feeds</li>
              <li>✓ <strong>CP Plus API:</strong> Official CP Plus integration</li>
            </ul>
            <p className="text-xs text-blue-700 mt-2">
              Uses official protocols. No iCMOB reverse-engineering required.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 p-6 bg-slate-50 flex justify-end gap-3 sticky bottom-0">
          <button
            onClick={onClose}
            className="px-6 py-2 border border-slate-300 text-slate-700 rounded-lg font-semibold hover:bg-slate-100 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
