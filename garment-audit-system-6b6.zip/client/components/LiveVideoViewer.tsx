import { useState, useRef } from "react";
import {
  Maximize2,
  Minimize2,
  Volume2,
  VolumeX,
  RotateCcw,
  Pause,
  Play,
  Download,
} from "lucide-react";

interface Camera {
  id: string;
  name: string;
  factory: string;
  location: string;
  status: "online" | "offline" | "reconnecting" | "disabled";
  type: string;
  url: string;
}

interface LiveVideoViewerProps {
  cameras: Camera[];
  viewMode: 1 | 2 | 4 | 6;
  onFullScreen: (cameraId: string) => void;
}

export function LiveVideoViewer({
  cameras,
  viewMode,
  onFullScreen,
}: LiveVideoViewerProps) {
  const [isMuted, setIsMuted] = useState(false);
  const [isPaused, setPaused] = useState(false);
  const videoRefs = useRef<Record<string, HTMLVideoElement | null>>({});

  const getGridClass = () => {
    switch (viewMode) {
      case 2:
        return "grid-cols-2";
      case 4:
        return "grid-cols-2 md:grid-cols-2";
      case 6:
        return "grid-cols-2 md:grid-cols-3";
      default:
        return "grid-cols-1";
    }
  };

  const getVisibleCameras = () => {
    return cameras.slice(0, viewMode);
  };

  const handleSnapshot = (cameraId: string) => {
    const video = videoRefs.current[cameraId];
    if (video && video.videoWidth > 0) {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const link = document.createElement("a");
        link.href = canvas.toDataURL("image/jpeg");
        link.download = `snapshot-${cameraId}-${Date.now()}.jpg`;
        link.click();
      }
    }
  };

  const visibleCameras = getVisibleCameras();

  return (
    <div className={`grid ${getGridClass()} gap-2 p-2 bg-black`}>
      {visibleCameras.map((camera) => (
        <div key={camera.id} className="relative bg-black rounded-lg overflow-hidden group">
          {/* Video Container */}
          <div className="relative aspect-video bg-slate-900 flex items-center justify-center">
            {camera.status === "online" ? (
              <>
                {/* Placeholder for actual video stream */}
                <div className="w-full h-full bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center text-slate-400">
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-full border-2 border-blue-500 border-t-transparent animate-spin mx-auto mb-2"></div>
                    <p className="text-sm">Live Stream Ready</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {camera.type.replace(/-/g, " ").toUpperCase()}
                    </p>
                  </div>
                </div>

                {/* Status Badge */}
                <div className="absolute top-2 left-2 bg-green-500 text-white px-2 py-1 rounded text-xs font-semibold flex items-center gap-1">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  LIVE
                </div>

                {/* Camera Name */}
                <div className="absolute bottom-2 left-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs truncate">
                  {camera.name}
                </div>

                {/* Controls - Show on hover */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={() => handleSnapshot(camera.id)}
                    className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full transition"
                    title="Capture Snapshot"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="p-2 bg-slate-700 hover:bg-slate-600 text-white rounded-full transition"
                  >
                    {isMuted ? (
                      <VolumeX className="w-4 h-4" />
                    ) : (
                      <Volume2 className="w-4 h-4" />
                    )}
                  </button>
                  <button
                    onClick={() => setPaused(!isPaused)}
                    className="p-2 bg-slate-700 hover:bg-slate-600 text-white rounded-full transition"
                  >
                    {isPaused ? (
                      <Play className="w-4 h-4" />
                    ) : (
                      <Pause className="w-4 h-4" />
                    )}
                  </button>
                  <button
                    onClick={() => onFullScreen(camera.id)}
                    className="p-2 bg-slate-700 hover:bg-slate-600 text-white rounded-full transition"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
              </>
            ) : (
              <div className="text-center text-slate-400">
                <div className="w-12 h-12 mx-auto mb-2 rounded-full border-2 border-red-500 flex items-center justify-center">
                  <div className="w-6 h-6 rounded-full bg-red-500"></div>
                </div>
                <p className="text-sm font-semibold">
                  {camera.status === "offline"
                    ? "Offline"
                    : camera.status === "disabled"
                    ? "Disabled"
                    : "Reconnecting..."}
                </p>
                <p className="text-xs mt-1">{camera.factory}</p>
              </div>
            )}

            {/* Ref for video element (for snapshot functionality) */}
            <video
              ref={(el) => {
                if (el) videoRefs.current[camera.id] = el;
              }}
              className="hidden"
              muted={isMuted}
              crossOrigin="anonymous"
            />
          </div>
        </div>
      ))}
    </div>
  );
}
