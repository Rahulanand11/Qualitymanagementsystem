import { AlertCircle, CheckCircle2, TrendingDown, Lightbulb } from "lucide-react";

interface InspectionSummaryProps {
  defects: any[];
  checkpoints: any;
  inspectionType: string;
  inspectionStage: string;
  formData: any;
}

export function InspectionSummary({
  defects,
  checkpoints,
  inspectionType,
  inspectionStage,
  formData,
}: InspectionSummaryProps) {
  // Calculate quality score
  let qualityScore = 100;
  let defectCount = defects.length;
  qualityScore = Math.max(0, 100 - defectCount * 5);

  // Determine pass/fail
  const isPassed = qualityScore >= 85;

  // Find major defects
  const majorDefects = defects.filter((d) => d.severity === "major");
  const criticalDefects = defects.filter((d) => d.severity === "critical");

  // Generate observations
  const observations: string[] = [];
  if (criticalDefects.length > 0) {
    observations.push(
      `${criticalDefects.length} critical defect(s) found that require immediate attention`
    );
  }
  if (majorDefects.length > 0) {
    observations.push(
      `${majorDefects.length} major defect(s) identified that may affect product quality`
    );
  }
  if (defects.length === 0) {
    observations.push("No defects identified in this inspection");
  }

  // Generate recommendations
  const recommendations: string[] = [];
  if (criticalDefects.length > 0) {
    recommendations.push("Halt production immediately and review manufacturing process");
    recommendations.push("Conduct root cause analysis on critical defects");
  }
  if (majorDefects.length > 0) {
    recommendations.push("Increase monitoring frequency for affected production line");
    recommendations.push("Provide additional training to quality control team");
  }
  if (defects.length === 0) {
    recommendations.push("Maintain current quality control procedures");
    recommendations.push("Document and share best practices with other facilities");
  }

  return (
    <div className="border border-blue-300 bg-blue-50 rounded-lg p-6 space-y-4">
      <div className="flex items-start gap-3">
        {isPassed ? (
          <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
        ) : (
          <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
        )}
        <div>
          <h3 className="font-bold text-lg text-slate-900">Inspection Summary</h3>
          <p className="text-sm text-slate-600 mt-1">
            Auto-generated intelligent summary for quick review
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {/* Overall Result */}
        <div className="bg-white rounded p-3">
          <p className="text-xs font-medium text-slate-700 mb-1">OVERALL RESULT</p>
          <p
            className={`text-2xl font-bold ${
              isPassed ? "text-green-600" : "text-red-600"
            }`}
          >
            {isPassed ? "✓ PASS" : "✗ FAIL"}
          </p>
          <p className="text-xs text-slate-600 mt-1">
            {inspectionStage && `Stage: ${inspectionStage}`}
          </p>
        </div>

        {/* Quality Score */}
        <div className="bg-white rounded p-3">
          <p className="text-xs font-medium text-slate-700 mb-1">QUALITY SCORE</p>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-bold text-blue-600">{qualityScore}%</p>
            <div className="flex-1 bg-slate-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-blue-600 to-orange-500 h-2 rounded-full"
                style={{ width: `${qualityScore}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid md:grid-cols-3 gap-3 text-sm">
        <div className="bg-white rounded p-3">
          <p className="text-xs font-medium text-slate-700">Defects Found</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{defectCount}</p>
        </div>
        <div className="bg-white rounded p-3">
          <p className="text-xs font-medium text-slate-700">Critical Issues</p>
          <p className="text-xl font-bold text-red-600 mt-1">
            {criticalDefects.length}
          </p>
        </div>
        <div className="bg-white rounded p-3">
          <p className="text-xs font-medium text-slate-700">Inspection Type</p>
          <p className="text-xl font-bold text-slate-900 mt-1">
            {inspectionType === "100"
              ? "100%"
              : inspectionType === "aql15"
              ? "AQL 1.5"
              : "AQL 2.5"}
          </p>
        </div>
      </div>

      {/* Critical Observations */}
      <div className="bg-white rounded p-3">
        <p className="text-xs font-medium text-slate-700 mb-2">
          CRITICAL OBSERVATIONS
        </p>
        <ul className="space-y-1">
          {observations.map((obs, idx) => (
            <li key={idx} className="text-xs text-slate-700 flex gap-2">
              <span className="text-blue-600 flex-shrink-0">•</span>
              {obs}
            </li>
          ))}
        </ul>
      </div>

      {/* Recommended Actions */}
      <div className="bg-white rounded p-3">
        <div className="flex items-center gap-2 mb-2">
          <Lightbulb className="w-4 h-4 text-orange-600" />
          <p className="text-xs font-medium text-slate-700">
            RECOMMENDED CORRECTIVE ACTIONS
          </p>
        </div>
        <ul className="space-y-1">
          {recommendations.map((rec, idx) => (
            <li key={idx} className="text-xs text-slate-700 flex gap-2">
              <span className="text-orange-600 flex-shrink-0">→</span>
              {rec}
            </li>
          ))}
        </ul>
      </div>

      {/* Footer Note */}
      <div className="bg-white rounded p-3 border border-slate-200">
        <p className="text-xs text-slate-600">
          <strong>Note:</strong> This AI-generated summary is based on recorded
          defects and inspection data. Always review the complete inspection
          report before making final decisions.
        </p>
      </div>
    </div>
  );
}
