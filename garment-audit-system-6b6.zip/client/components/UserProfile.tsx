import { useAuth } from "@/contexts/AuthContext";
import { LogOut, User } from "lucide-react";
import { useState } from "react";

export function UserProfile() {
  const { user, logout, userRole } = useAuth();
  const [showDropdown, setShowDropdown] = useState(false);

  if (!user) return null;

  const initials = user.fullName
    ?.split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase() || "U";

  const profilePicture = user.profilePicture || null;
  const roleLabel = userRole ? userRole.charAt(0).toUpperCase() + userRole.slice(1) : "User";

  return (
    <div className="relative">
      <button
        onClick={() => setShowDropdown(!showDropdown)}
        className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-100 transition"
      >
        {profilePicture ? (
          <img
            src={profilePicture}
            alt={user.fullName}
            className="w-8 h-8 rounded-full object-cover"
          />
        ) : (
          <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-semibold">
            {initials}
          </div>
        )}
        <div className="hidden sm:block text-left">
          <p className="text-sm font-medium text-slate-900">{user.fullName}</p>
          <p className="text-xs text-slate-600">{roleLabel}</p>
        </div>
      </button>

      {showDropdown && (
        <div className="absolute right-0 mt-2 w-56 bg-white border border-slate-200 rounded-lg shadow-lg z-50">
          <div className="p-4 border-b border-slate-200">
            <div className="flex items-center gap-3 mb-2">
              {profilePicture ? (
                <img
                  src={profilePicture}
                  alt={user.fullName}
                  className="w-12 h-12 rounded-full object-cover"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center font-semibold">
                  {initials}
                </div>
              )}
              <div>
                <p className="font-medium text-slate-900">{user.fullName}</p>
                <p className="text-xs text-slate-600">{user.email}</p>
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              logout();
              setShowDropdown(false);
            }}
            className="w-full px-4 py-3 flex items-center gap-2 text-slate-700 hover:bg-slate-50 transition text-sm"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      )}
    </div>
  );
}
