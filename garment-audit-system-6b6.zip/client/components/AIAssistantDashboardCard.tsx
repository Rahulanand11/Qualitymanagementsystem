import React from "react";
import { Link } from "react-router-dom";
import { Sparkles, TrendingUp, Clock } from "lucide-react";

interface AIAssistantStats {
  inspectionsAnalyzed: number;
  averageQualityScore: number;
  timeLastAnalysis: string;
}

interface AIAssistantDashboardCardProps {
  stats?: AIAssistantStats;
  isLoading?: boolean;
}

export function AIAssistantDashboardCard({
  stats = {
    inspectionsAnalyzed: 0,
    averageQualityScore: 0,
    timeLastAnalysis: "Never",
  },
  isLoading = false,
}: AIAssistantDashboardCardProps) {
  return (
    <Link
      to="/ai-assistant"
      className="group bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-purple-300 rounded-2xl p-6 hover:shadow-lg hover:border-purple-400 transition-all duration-300 transform hover:scale-105"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-blue-500 rounded-xl flex items-center justify-center transform group-hover:scale-110 transition">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
        <span className="px-3 py-1 bg-purple-100 text-purple-700 text-xs font-semibold rounded-full">
          AI-Powered
        </span>
      </div>

      <h2 className="text-xl font-bold text-slate-900 mb-2">
        AI Inspection Assistant
      </h2>
      <p className="text-slate-600 mb-4 text-sm">
        Auto-analyze inspections and generate smart summaries
      </p>

      {isLoading ? (
        <div className="space-y-2">
          <div className="h-8 bg-gradient-to-r from-purple-200 to-blue-200 rounded animate-pulse" />
          <div className="h-4 bg-gray-200 rounded w-3/4 animate-pulse" />
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="bg-white rounded-lg p-3">
            <p className="text-xs text-gray-600 uppercase tracking-wide">
              Analyzed
            </p>
            <p className="text-2xl font-bold text-purple-600">
              {stats.inspectionsAnalyzed}
            </p>
          </div>
          <div className="bg-white rounded-lg p-3">
            <p className="text-xs text-gray-600 uppercase tracking-wide">
              Avg Score
            </p>
            <p className="text-2xl font-bold text-blue-600">
              {stats.averageQualityScore.toFixed(0)}%
            </p>
          </div>
        </div>
      )}

      <div className="flex items-center gap-2 text-xs text-gray-600 mt-4 pt-4 border-t border-purple-200">
        <Clock className="w-4 h-4" />
        <span>Last: {stats.timeLastAnalysis}</span>
      </div>

      <div className="flex items-center justify-between mt-4 pt-3 border-t border-purple-200/50">
        <span className="text-xs font-semibold text-purple-700">
          View Details
        </span>
        <TrendingUp className="w-4 h-4 text-purple-600 group-hover:translate-x-1 transition" />
      </div>
    </Link>
  );
}
