import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

export function RoleBasedRedirect() {
  const { userRole, isLoggedIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!isLoggedIn) return;

    // If buyer tries to access auditor/admin routes, redirect to buyer portal
    if (userRole === "buyer") {
      const buyerOnlyRoutes = ["/buyer"];
      const isBuyerRoute = location.pathname.startsWith("/buyer");

      // If on auditor-only route, redirect to buyer dashboard
      if (
        !isBuyerRoute &&
        location.pathname !== "/login" &&
        location.pathname !== "/" // Allow home page for now
      ) {
        // Don't redirect from / as it might be a valid landing page
        // but for other auditor routes, redirect to buyer dashboard
        if (
          location.pathname.startsWith("/audit/") ||
          location.pathname.startsWith("/analytics") ||
          location.pathname.startsWith("/monitoring") ||
          location.pathname.startsWith("/admin") ||
          location.pathname.startsWith("/reports") ||
          location.pathname.startsWith("/users") ||
          location.pathname.startsWith("/settings") ||
          location.pathname.startsWith("/onboarding")
        ) {
          navigate("/buyer/dashboard", { replace: true });
        }
      }
    }
  }, [userRole, location.pathname, isLoggedIn, navigate]);

  return null;
}
