import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

interface BuyerRouteProps {
  element: React.ReactElement;
}

export function BuyerRoute({ element }: BuyerRouteProps) {
  const { isLoggedIn, userRole } = useAuth();

  if (!isLoggedIn) {
    return <Navigate to="/login" replace />;
  }

  if (userRole !== "buyer") {
    return <Navigate to="/" replace />;
  }

  return element;
}
