import React, { useState } from "react";
import {
  ChevronDown,
  CheckCircle2,
  AlertCircle,
  TrendingDown,
  Copy,
  Download,
  Printer,
} from "lucide-react";
import { AIInspectionSummary } from "../services/AIInspectionSummary";

interface AIInspectionSummaryDisplayProps {
  summary: AIInspectionSummary;
  onExport?: (format: "json" | "pdf") => void;
}

export function AIInspectionSummaryDisplay({
  summary,
  onExport,
}: AIInspectionSummaryDisplayProps) {
  const [expandedSections, setExpandedSections] = useState<
    Record<string, boolean>
  >({
    findings: true,
    defects: true,
    measurements: true,
    actions: true,
  });

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const resultColor =
    summary.overallResult === "Pass"
      ? "bg-green-50 border-green-200"
      : summary.overallResult === "Conditional Pass"
        ? "bg-yellow-50 border-yellow-200"
        : "bg-red-50 border-red-200";

  const resultTextColor =
    summary.overallResult === "Pass"
      ? "text-green-900"
      : summary.overallResult === "Conditional Pass"
        ? "text-yellow-900"
        : "text-red-900";

  const resultIcon =
    summary.overallResult === "Pass" ||
    summary.overallResult === "Conditional Pass" ? (
      <CheckCircle2 className="w-6 h-6 text-green-600" />
    ) : (
      <AlertCircle className="w-6 h-6 text-red-600" />
    );

  const copyToClipboard = () => {
    const text = `
AI Inspection Summary
=====================
Result: ${summary.overallResult}
Quality Score: ${summary.qualityScore.score}% (${summary.qualityScore.rating})
Generated: ${new Date(summary.generatedAt).toLocaleString()}

Executive Summary:
${summary.executiveSummary}

Key Findings:
${summary.keyFindings.map((f) => `- ${f}`).join("\n")}

Defect Analysis:
Critical: ${summary.defectAnalysis.critical.count}
Major: ${summary.defectAnalysis.major.count}
Minor: ${summary.defectAnalysis.minor.count}

Corrective Actions:
${summary.correctiveActions.map((a) => `- ${a.action}: ${a.priority}`).join("\n")}

Shipment Risk: ${summary.shipmentRiskAssessment.riskLevel}
`;
    navigator.clipboard.writeText(text);
  };

  return (
    <div className={`border-2 rounded-lg p-6 ${resultColor}`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-4 flex-1">
          {resultIcon}
          <div>
            <h3 className={`text-2xl font-bold ${resultTextColor}`}>
              {summary.overallResult}
            </h3>
            <p className={`text-sm ${resultTextColor.replace("900", "700")}`}>
              AI-Generated Inspection Summary
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={copyToClipboard}
            className="p-2 hover:bg-white/50 rounded-lg transition"
            title="Copy to clipboard"
          >
            <Copy className="w-5 h-5" />
          </button>
          <button
            onClick={() => onExport?.("json")}
            className="p-2 hover:bg-white/50 rounded-lg transition"
            title="Export as JSON"
          >
            <Download className="w-5 h-5" />
          </button>
          <button
            onClick={() => onExport?.("pdf")}
            className="p-2 hover:bg-white/50 rounded-lg transition"
            title="Print"
          >
            <Printer className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Quality Score Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-lg p-4">
          <p className="text-xs text-gray-600 uppercase tracking-wide mb-1">
            Quality Score
          </p>
          <p className="text-3xl font-bold text-blue-600">
            {summary.qualityScore.score}%
          </p>
          <p className="text-sm text-gray-700 mt-1">
            {summary.qualityScore.rating}
          </p>
        </div>

        <div className="bg-white rounded-lg p-4">
          <p className="text-xs text-gray-600 uppercase tracking-wide mb-1">
            Defects Found
          </p>
          <p className="text-3xl font-bold text-purple-600">
            {summary.defectAnalysis.critical.count +
              summary.defectAnalysis.major.count +
              summary.defectAnalysis.minor.count}
          </p>
          <p className="text-xs text-gray-600 mt-1">
            {summary.defectAnalysis.critical.count} critical,{" "}
            {summary.defectAnalysis.major.count} major,{" "}
            {summary.defectAnalysis.minor.count} minor
          </p>
        </div>

        <div className="bg-white rounded-lg p-4">
          <p className="text-xs text-gray-600 uppercase tracking-wide mb-1">
            Shipment Risk
          </p>
          <p
            className={`text-2xl font-bold ${
              summary.shipmentRiskAssessment.riskLevel === "Low"
                ? "text-green-600"
                : summary.shipmentRiskAssessment.riskLevel === "Medium"
                  ? "text-yellow-600"
                  : "text-red-600"
            }`}
          >
            {summary.shipmentRiskAssessment.riskLevel}
          </p>
          <p className="text-xs text-gray-600 mt-1">
            {summary.shipmentRiskAssessment.confidence}% confidence
          </p>
        </div>
      </div>

      {/* Executive Summary */}
      <div className="bg-white rounded-lg p-4 mb-4">
        <h4 className="font-semibold text-gray-900 mb-2">Executive Summary</h4>
        <p className="text-sm text-gray-700 leading-relaxed">
          {summary.executiveSummary}
        </p>
      </div>

      {/* Collapsible Sections */}

      {/* Key Findings */}
      <div className="bg-white rounded-lg mb-4 overflow-hidden">
        <button
          onClick={() => toggleSection("findings")}
          className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition"
        >
          <h4 className="font-semibold text-gray-900">Key Findings</h4>
          <ChevronDown
            className={`w-5 h-5 transition ${
              expandedSections.findings ? "rotate-180" : ""
            }`}
          />
        </button>
        {expandedSections.findings && (
          <div className="px-4 pb-4 border-t">
            <ul className="space-y-2">
              {summary.keyFindings.map((finding, idx) => (
                <li key={idx} className="flex gap-2 text-sm text-gray-700">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>{finding}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Defect Analysis */}
      <div className="bg-white rounded-lg mb-4 overflow-hidden">
        <button
          onClick={() => toggleSection("defects")}
          className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition"
        >
          <h4 className="font-semibold text-gray-900">Defect Analysis</h4>
          <ChevronDown
            className={`w-5 h-5 transition ${
              expandedSections.defects ? "rotate-180" : ""
            }`}
          />
        </button>
        {expandedSections.defects && (
          <div className="px-4 pb-4 border-t space-y-3">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-red-900">
                  Critical Defects
                </p>
                <p className="text-xs text-gray-600">
                  {summary.defectAnalysis.critical.description}
                </p>
              </div>
              <p className="text-2xl font-bold text-red-600">
                {summary.defectAnalysis.critical.count}
              </p>
            </div>
            <div className="h-px bg-gray-200" />
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-orange-900">
                  Major Defects
                </p>
                <p className="text-xs text-gray-600">
                  {summary.defectAnalysis.major.description}
                </p>
              </div>
              <p className="text-2xl font-bold text-orange-600">
                {summary.defectAnalysis.major.count}
              </p>
            </div>
            <div className="h-px bg-gray-200" />
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-yellow-900">
                  Minor Defects
                </p>
                <p className="text-xs text-gray-600">
                  {summary.defectAnalysis.minor.description}
                </p>
              </div>
              <p className="text-2xl font-bold text-yellow-600">
                {summary.defectAnalysis.minor.count}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Measurement Analysis */}
      {summary.measurementAnalysis.checked > 0 && (
        <div className="bg-white rounded-lg mb-4 overflow-hidden">
          <button
            onClick={() => toggleSection("measurements")}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition"
          >
            <h4 className="font-semibold text-gray-900">Measurement Analysis</h4>
            <ChevronDown
              className={`w-5 h-5 transition ${
                expandedSections.measurements ? "rotate-180" : ""
              }`}
            />
          </button>
          {expandedSections.measurements && (
            <div className="px-4 pb-4 border-t">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Total Checked</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {summary.measurementAnalysis.checked}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Within Tolerance</p>
                  <p className="text-2xl font-bold text-green-600">
                    {summary.measurementAnalysis.withinTolerance}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Outside Tolerance</p>
                  <p className="text-2xl font-bold text-red-600">
                    {summary.measurementAnalysis.outsideTolerance}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Avg Deviation</p>
                  <p className="text-2xl font-bold text-orange-600">
                    {summary.measurementAnalysis.averageDeviation.toFixed(2)}mm
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Corrective Actions */}
      {summary.correctiveActions.length > 0 && (
        <div className="bg-white rounded-lg overflow-hidden">
          <button
            onClick={() => toggleSection("actions")}
            className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition"
          >
            <h4 className="font-semibold text-gray-900">
              Corrective Actions ({summary.correctiveActions.length})
            </h4>
            <ChevronDown
              className={`w-5 h-5 transition ${
                expandedSections.actions ? "rotate-180" : ""
              }`}
            />
          </button>
          {expandedSections.actions && (
            <div className="px-4 pb-4 border-t space-y-3">
              {summary.correctiveActions.map((action, idx) => (
                <div
                  key={idx}
                  className="flex gap-3 pb-3 border-b last:border-b-0"
                >
                  <div className="flex-shrink-0">
                    <span
                      className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold text-white ${
                        action.priority === "High"
                          ? "bg-red-500"
                          : action.priority === "Medium"
                            ? "bg-orange-500"
                            : "bg-yellow-500"
                      }`}
                    >
                      {idx + 1}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">
                      {action.action}
                    </p>
                    <p className="text-xs text-gray-600 mt-1">
                      Priority: <span className="font-semibold">{action.priority}</span>
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Generated Timestamp */}
      <p className="text-xs text-gray-500 mt-6 text-center">
        Generated on {new Date(summary.generatedAt).toLocaleString()}
      </p>
    </div>
  );
}
