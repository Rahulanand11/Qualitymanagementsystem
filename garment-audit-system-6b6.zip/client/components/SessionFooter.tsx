import React from "react";
import { useNavigate } from "react-router-dom";
import { Clock, LogOut } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export function SessionFooter() {
  try {
    const navigate = useNavigate();
    const { isLoggedIn, sessionDuration, logout, user, userRole } = useAuth();

    if (!isLoggedIn) {
      return null;
    }

    return (
      <footer className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-slate-800 to-slate-900 text-white border-t-2 border-blue-500 shadow-2xl z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center justify-between">
            {/* Left - Session Info */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-400 animate-pulse" />
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-wide">
                    Session Duration
                  </p>
                  <p className="text-2xl font-bold text-blue-400 font-mono">
                    {sessionDuration}
                  </p>
                </div>
              </div>
            </div>

            {/* Center - Auditor Info */}
            <div className="text-center hidden sm:block">
              <p className="text-xs text-slate-400 uppercase tracking-wide">
                Logged In As
              </p>
              <p className="font-semibold text-white">{user?.fullName || "User"}</p>
            </div>

            {/* Right - Logout Button */}
            <button
              onClick={() => {
                logout();
                navigate("/login", { replace: true });
              }}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg transition-colors font-medium text-sm"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error("SessionFooter error:", error);
    return null;
  }
}
