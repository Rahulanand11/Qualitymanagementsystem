import { Activity, Signal, Monitor } from "lucide-react";

interface Camera {
  id: string;
  name: string;
  factory: string;
  location: string;
  status: "online" | "offline" | "reconnecting" | "disabled";
  type: string;
  lastConnected: string;
  signalStrength?: number;
  resolution?: string;
  frameRate?: string;
  enabled: boolean;
}

interface CameraStatusDashboardProps {
  cameras: Camera[];
}

export function CameraStatusDashboard({ cameras }: CameraStatusDashboardProps) {
  const onlineCount = cameras.filter((c) => c.status === "online").length;
  const offlineCount = cameras.filter((c) => c.status === "offline").length;
  const avgSignal = Math.round(
    cameras.reduce((sum, c) => sum + (c.signalStrength || 0), 0) / cameras.length
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-green-100 text-green-800 border-green-300";
      case "offline":
        return "bg-red-100 text-red-800 border-red-300";
      case "reconnecting":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      default:
        return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  const getStatusDot = (status: string) => {
    switch (status) {
      case "online":
        return "bg-green-500";
      case "offline":
        return "bg-red-500";
      case "reconnecting":
        return "bg-yellow-500";
      default:
        return "bg-gray-500";
    }
  };

  return (
    <div className="space-y-4">
      {/* Summary Stats */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
        <h3 className="font-semibold text-slate-900 mb-3">System Status</h3>
        <div className="space-y-2">
          <div className="flex items-center justify-between p-2 bg-green-50 rounded border border-green-200">
            <span className="text-sm font-medium text-green-900">Online</span>
            <span className="text-lg font-bold text-green-700">{onlineCount}</span>
          </div>
          <div className="flex items-center justify-between p-2 bg-red-50 rounded border border-red-200">
            <span className="text-sm font-medium text-red-900">Offline</span>
            <span className="text-lg font-bold text-red-700">{offlineCount}</span>
          </div>
          <div className="flex items-center justify-between p-2 bg-blue-50 rounded border border-blue-200">
            <span className="text-sm font-medium text-blue-900">Avg Signal</span>
            <span className="text-lg font-bold text-blue-700">{avgSignal}%</span>
          </div>
        </div>
      </div>

      {/* Camera Details */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200 bg-slate-50">
          <h3 className="font-semibold text-slate-900 text-sm">Camera Details</h3>
        </div>
        <div className="max-h-96 overflow-y-auto">
          {cameras.map((camera) => (
            <div key={camera.id} className="px-4 py-3 border-b border-slate-100 hover:bg-slate-50 transition">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="text-sm font-medium text-slate-900 truncate">{camera.name}</p>
                  <p className="text-xs text-slate-600">{camera.location}</p>
                </div>
                <div className={`flex items-center gap-1 px-2 py-1 rounded border text-xs font-semibold ${getStatusColor(camera.status)}`}>
                  <div className={`w-2 h-2 rounded-full ${getStatusDot(camera.status)}`} />
                  {camera.status.charAt(0).toUpperCase() + camera.status.slice(1)}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                {camera.signalStrength !== undefined && (
                  <div className="flex items-center gap-1 text-slate-600">
                    <Signal className="w-3 h-3" />
                    {camera.signalStrength}%
                  </div>
                )}
                {camera.resolution && (
                  <div className="flex items-center gap-1 text-slate-600">
                    <Monitor className="w-3 h-3" />
                    {camera.resolution}
                  </div>
                )}
              </div>

              <p className="text-xs text-slate-500 mt-1">
                Last: {camera.lastConnected}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Status Legend */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
        <h3 className="font-semibold text-slate-900 mb-3 text-sm">Status Legend</h3>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-xs text-slate-700">Online</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <span className="text-xs text-slate-700">Offline</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500 animate-pulse"></div>
            <span className="text-xs text-slate-700">Reconnecting</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-gray-500"></div>
            <span className="text-xs text-slate-700">Disabled</span>
          </div>
        </div>
      </div>
    </div>
  );
}
