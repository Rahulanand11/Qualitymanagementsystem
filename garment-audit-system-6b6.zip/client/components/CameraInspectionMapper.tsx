import { useState } from "react";
import { X, Plus, Trash2, Link2, Unlink2 } from "lucide-react";

interface CameraMapping {
  id: string;
  cameraId: string;
  cameraName: string;
  factory: string;
  supplier: string;
  productionLine: string;
  inspectionArea: string;
  linkedInspections: string[];
  lastUsed: string;
}

interface CameraInspectionMapperProps {
  mappings: CameraMapping[];
  onClose: () => void;
  onSave: (mappings: CameraMapping[]) => void;
}

export function CameraInspectionMapper({
  mappings,
  onClose,
  onSave,
}: CameraInspectionMapperProps) {
  const [formData, setFormData] = useState({
    cameraId: "",
    factory: "",
    supplier: "",
    productionLine: "",
    inspectionArea: "",
  });

  const inspectionAreas = [
    "Sewing Line",
    "Finishing Area",
    "Packing Area",
    "Inspection Station",
    "QC Check Point",
    "Final Audit Area",
  ];

  const productionLines = [
    "Line 1",
    "Line 2",
    "Line 3",
    "Line 4",
    "Line 5",
    "Line 6",
  ];

  const handleAddMapping = () => {
    if (
      formData.cameraId &&
      formData.factory &&
      formData.productionLine &&
      formData.inspectionArea
    ) {
      const newMapping: CameraMapping = {
        id: `map-${Date.now()}`,
        cameraId: formData.cameraId,
        cameraName: `Camera ${formData.cameraId}`,
        factory: formData.factory,
        supplier: formData.supplier,
        productionLine: formData.productionLine,
        inspectionArea: formData.inspectionArea,
        linkedInspections: [],
        lastUsed: "Never",
      };

      onSave([...mappings, newMapping]);
      setFormData({
        cameraId: "",
        factory: "",
        supplier: "",
        productionLine: "",
        inspectionArea: "",
      });
    }
  };

  const handleDeleteMapping = (id: string) => {
    onSave(mappings.filter((m) => m.id !== id));
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-slate-200 sticky top-0 bg-white">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">
              Camera to Inspection Mapping
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Link cameras to factories and inspection areas for automatic display during audits
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-600 hover:text-slate-900 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Mapping Form */}
          <div className="border-2 border-dashed border-green-300 rounded-lg p-6 bg-green-50">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <Link2 className="w-5 h-5" /> Create Camera Mapping
            </h3>

            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Camera ID / Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., CAM-001"
                    value={formData.cameraId}
                    onChange={(e) =>
                      setFormData({ ...formData, cameraId: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Factory Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., ABC Garments"
                    value={formData.factory}
                    onChange={(e) =>
                      setFormData({ ...formData, factory: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Supplier Name (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g., Supplier XYZ"
                  value={formData.supplier}
                  onChange={(e) =>
                    setFormData({ ...formData, supplier: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Production Line
                  </label>
                  <select
                    value={formData.productionLine}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        productionLine: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select Production Line</option>
                    {productionLines.map((line) => (
                      <option key={line} value={line}>
                        {line}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Inspection Area
                  </label>
                  <select
                    value={formData.inspectionArea}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        inspectionArea: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select Inspection Area</option>
                    {inspectionAreas.map((area) => (
                      <option key={area} value={area}>
                        {area}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                onClick={handleAddMapping}
                className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition flex items-center gap-2"
              >
                <Plus className="w-4 h-4" /> Create Mapping
              </button>
            </div>
          </div>

          {/* Mappings List */}
          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-4">
              Active Mappings ({mappings.length})
            </h3>

            <div className="space-y-3">
              {mappings.map((mapping) => (
                <div
                  key={mapping.id}
                  className="border border-slate-200 rounded-lg p-4 bg-white hover:border-slate-300 hover:shadow-md transition"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-slate-900">
                          {mapping.factory} • {mapping.productionLine}
                        </h4>
                        <span className="px-2 py-1 text-xs font-semibold bg-green-100 text-green-800 rounded-full">
                          Active
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 flex items-center gap-2">
                        <Link2 className="w-4 h-4" />
                        {mapping.inspectionArea}
                      </p>
                    </div>
                    <button
                      onClick={() => handleDeleteMapping(mapping.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-xs">
                    <div>
                      <span className="text-slate-600">Camera</span>
                      <p className="font-semibold text-slate-900">
                        {mapping.cameraId}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-600">Supplier</span>
                      <p className="font-semibold text-slate-900">
                        {mapping.supplier || "N/A"}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-600">Last Used</span>
                      <p className="font-semibold text-slate-900">
                        {mapping.lastUsed}
                      </p>
                    </div>
                  </div>

                  {mapping.linkedInspections.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-slate-100">
                      <p className="text-xs text-slate-600">
                        Currently linked to {mapping.linkedInspections.length} active inspection(s)
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {mappings.length === 0 && (
              <div className="text-center py-8 text-slate-500">
                <Link2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No mappings configured yet. Create your first mapping above.</p>
              </div>
            )}
          </div>

          {/* Info Box */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-semibold text-blue-900 mb-2">How It Works</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>
                ✓ When an auditor starts an inspection at a factory/line, the linked camera automatically displays
              </li>
              <li>
                ✓ Multiple cameras can be linked to the same factory or production line
              </li>
              <li>
                ✓ Snapshots from linked cameras are saved to the inspection record
              </li>
              <li>
                ✓ Last used timestamp tracks which inspections used which cameras
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 p-6 bg-slate-50 flex justify-end gap-3 sticky bottom-0">
          <button
            onClick={onClose}
            className="px-6 py-2 border border-slate-300 text-slate-700 rounded-lg font-semibold hover:bg-slate-100 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
