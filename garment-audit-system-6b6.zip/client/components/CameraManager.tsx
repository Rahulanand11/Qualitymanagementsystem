import { useState } from "react";
import { X, Plus, Trash2, Edit2 } from "lucide-react";

interface Camera {
  id: string;
  name: string;
  factory: string;
  location: string;
  status: "online" | "offline" | "reconnecting" | "disabled";
  type: "ip-rtsp" | "onvif" | "usb" | "network" | "hls" | "webrtc";
  url: string;
  lastConnected: string;
  signalStrength?: number;
  resolution?: string;
  frameRate?: string;
  enabled: boolean;
  linkedInspection?: string;
}

interface CameraManagerProps {
  cameras: Camera[];
  onClose: () => void;
  onSave: (cameras: Camera[]) => void;
}

export function CameraManager({ cameras, onClose, onSave }: CameraManagerProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Camera>>({
    name: "",
    factory: "",
    location: "",
    type: "ip-rtsp",
    url: "",
    enabled: true,
  });

  const handleAddCamera = () => {
    if (formData.name && formData.factory && formData.location && formData.url) {
      const newCamera: Camera = {
        id: `cam-${Date.now()}`,
        name: formData.name,
        factory: formData.factory,
        location: formData.location,
        type: (formData.type as Camera["type"]) || "ip-rtsp",
        url: formData.url,
        status: "online",
        lastConnected: new Date().toLocaleString(),
        signalStrength: 85,
        resolution: "1920x1080",
        frameRate: "30fps",
        enabled: formData.enabled || true,
      };

      onSave([...cameras, newCamera]);
      setFormData({
        name: "",
        factory: "",
        location: "",
        type: "ip-rtsp",
        url: "",
        enabled: true,
      });
    }
  };

  const handleDeleteCamera = (id: string) => {
    onSave(cameras.filter((c) => c.id !== id));
  };

  const handleToggleCamera = (id: string) => {
    onSave(
      cameras.map((c) =>
        c.id === id ? { ...c, enabled: !c.enabled } : c
      )
    );
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-slate-200 sticky top-0 bg-white">
          <h2 className="text-2xl font-bold text-slate-900">Camera Management</h2>
          <button
            onClick={onClose}
            className="text-slate-600 hover:text-slate-900 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Add Camera Form */}
          <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 bg-slate-50">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <Plus className="w-5 h-5" /> Add New Camera
            </h3>

            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <input
                type="text"
                placeholder="Camera Name (e.g., Factory A – Sewing Line 1)"
                value={formData.name || ""}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="text"
                placeholder="Factory Name"
                value={formData.factory || ""}
                onChange={(e) => setFormData({ ...formData, factory: e.target.value })}
                className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="text"
                placeholder="Location (e.g., Final Inspection Area)"
                value={formData.location || ""}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <select
                value={formData.type || "ip-rtsp"}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    type: e.target.value as Camera["type"],
                  })
                }
                className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="ip-rtsp">IP Camera (RTSP)</option>
                <option value="onvif">ONVIF Compatible</option>
                <option value="usb">USB Camera</option>
                <option value="network">Network Camera</option>
                <option value="hls">HLS Stream</option>
                <option value="webrtc">WebRTC</option>
              </select>
              <input
                type="text"
                placeholder="Camera URL or Stream Path"
                value={formData.url || ""}
                onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 md:col-span-2"
              />
            </div>

            <label className="flex items-center gap-2 mb-4">
              <input
                type="checkbox"
                checked={formData.enabled || true}
                onChange={(e) => setFormData({ ...formData, enabled: e.target.checked })}
                className="w-4 h-4 text-blue-600"
              />
              <span className="text-sm text-slate-700">Enable camera</span>
            </label>

            <button
              onClick={handleAddCamera}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition flex items-center gap-2"
            >
              <Plus className="w-4 h-4" /> Add Camera
            </button>
          </div>

          {/* Camera List */}
          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-4">
              Connected Cameras ({cameras.length})
            </h3>

            <div className="space-y-3">
              {cameras.map((camera) => (
                <div
                  key={camera.id}
                  className="border border-slate-200 rounded-lg p-4 hover:border-slate-300 hover:shadow-md transition"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-slate-900">{camera.name}</h4>
                        <span
                          className={`px-2 py-1 text-xs rounded font-semibold ${
                            camera.enabled
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {camera.enabled ? "Enabled" : "Disabled"}
                        </span>
                      </div>
                      <p className="text-sm text-slate-600">
                        {camera.factory} • {camera.location}
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        Type: {camera.type.replace(/-/g, " ").toUpperCase()} | URL:{" "}
                        <span className="font-mono text-slate-600 truncate">
                          {camera.url}
                        </span>
                      </p>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <button
                        onClick={() => handleToggleCamera(camera.id)}
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition"
                        title={camera.enabled ? "Disable" : "Enable"}
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteCamera(camera.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-3 text-xs">
                    <div>
                      <span className="text-slate-600">Status</span>
                      <p className="font-semibold text-slate-900 capitalize">
                        {camera.status}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-600">Resolution</span>
                      <p className="font-semibold text-slate-900">
                        {camera.resolution || "N/A"}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-600">Signal</span>
                      <p className="font-semibold text-slate-900">
                        {camera.signalStrength || "N/A"}%
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-600">Last Connected</span>
                      <p className="font-semibold text-slate-900 text-xs">
                        {camera.lastConnected}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {cameras.length === 0 && (
              <div className="text-center py-8 text-slate-500">
                <p>No cameras configured yet. Add one to get started!</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 p-6 bg-slate-50 flex justify-end gap-3 sticky bottom-0">
          <button
            onClick={onClose}
            className="px-6 py-2 border border-slate-300 text-slate-700 rounded-lg font-semibold hover:bg-slate-100 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
