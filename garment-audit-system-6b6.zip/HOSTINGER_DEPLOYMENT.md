# Hostinger Cloud Deployment Guide

## Prerequisites
- Hostinger Cloud Hosting account
- Node.js 18+ enabled
- SSH/Git access configured
- Domain connected

## Option A: Deploy to Hostinger Cloud (Full Stack)

### Step 1: Connect Your Git Repository
```bash
# In Hostinger control panel, go to Deployments
# Select GitHub and authorize
# Choose repository: BuilderIO/fusion-starter
# Branch: ai_main_5fd67ac90f4f4a7fb9fe
```

### Step 2: Configure Environment
In Hostinger Dashboard → Environment Variables:
```
NODE_ENV=production
VITE_PUBLIC_BUILDER_KEY=__BUILDER_PUBLIC_KEY__
```

### Step 3: Build Settings
- **Build Command**: `npm run build`
- **Start Command**: `npm start` or `node dist/server/node-build.mjs`
- **Node Version**: 18 or higher
- **Root Directory**: `/`

### Step 4: Deploy
- Click "Deploy" in Hostinger panel
- Wait for build to complete (~2-3 min)
- Get your live URL

## Option B: Deploy Frontend Only to Hostinger, Keep Backend Separate

### Step 1: Build Static Files
```bash
npm run build:client
# Output: dist/spa/
```

### Step 2: Upload to Hostinger
- FTP/SFTP the `dist/spa/` folder contents to `public_html/`
- Or use Hostinger's File Manager

### Step 3: Configure .htaccess
Create `.htaccess` in public_html:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

## Recommended: Keep Using Netlify for Frontend

Since Netlify is already configured and working:
- **Frontend**: Netlify (free, auto-deploys)
- **Domain**: Point to Netlify nameservers or use custom domain
- **Backend**: Can add Node.js API on Hostinger VPS later

## Verification
After deployment, test:
```
✓ Homepage loads
✓ Auditor signup works (/signup/auditor)
✓ Buyer signup works (/signup/buyer)
✓ Login functions
✓ Dashboard displays after login
✓ View Audits loads
```

## Troubleshooting

**Issue: Blank page after deployment**
- Check browser console for errors
- Verify `index.html` exists in root
- Clear browser cache (Ctrl+Shift+Delete)

**Issue: Routes not working**
- Ensure `.htaccess` is in place
- Check `public_html/` structure

**Issue: Environment variables not loading**
- Verify in Hostinger Environment Variables panel
- Restart deployment after adding env vars

## Contact Support
If issues persist:
- Check Hostinger deployment logs
- Review GitHub Actions build logs
- Test locally: `npm run dev`
